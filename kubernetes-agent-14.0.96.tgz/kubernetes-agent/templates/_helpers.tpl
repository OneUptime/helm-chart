{{/*
Expand the name of the chart.
*/}}
{{- define "kubernetes-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
The cluster name, refusing to render if it is missing.

This is not merely a label. OneUptime folds `k8s.cluster.name` into the identity
of every Kubernetes entity it derives, so it is the only thing separating this
cluster's `worker-1` and `default` namespace from every other cluster's. Ship
without it and two clusters reporting into one project silently become one
estate -- nodes, namespaces, pods and deployments merged pairwise by name, with
no error anywhere to say so.

`required` is deliberate: values.schema.json already lists clusterName in its
`required` set, but JSON Schema `required` only checks that the key is PRESENT,
and the chart's default value is the empty string, so it passes. Failing at
render is the only place this can be caught before the data is wrong.
*/}}
{{- define "kubernetes-agent.clusterName" -}}
{{- required "clusterName is required: it identifies this cluster's nodes, namespaces, pods and deployments in OneUptime, and two clusters installed without it will be merged into one. Set it with --set clusterName=<name>." (.Values.clusterName | trim) -}}
{{- end }}

{{/*
The Secret the operator created for the ingestion key (oneuptime.existingSecretName),
or nothing when the chart keeps oneuptime.apiKey in a Secret of its own
(templates/secret.yaml, which renders only then).

Setting both is refused rather than resolved: a Secret of your own is there to
keep the key out of the release's values, and a key left in apiKey would stay
in every revision Helm stores.
*/}}
{{- define "kubernetes-agent.existingSecretName" -}}
{{- $oneuptime := .Values.oneuptime | default dict -}}
{{- $existing := toString ($oneuptime.existingSecretName | default "") | trim -}}
{{- if and $existing (toString ($oneuptime.apiKey | default "") | trim) -}}
{{- fail (printf "oneuptime.apiKey and oneuptime.existingSecretName are both set. Set one of them: to read the ingestion key from the Secret %s, clear apiKey (--set oneuptime.apiKey=\"\")." $existing) -}}
{{- end -}}
{{- $existing -}}
{{- end }}

{{/*
The Secret every workload reads the ingestion key from, under `api-key`.
Usage: secretKeyRef: { name: {{ include "kubernetes-agent.apiKeySecretName" . }}, key: api-key }
*/}}
{{- define "kubernetes-agent.apiKeySecretName" -}}
{{- include "kubernetes-agent.existingSecretName" . | default (include "kubernetes-agent.fullname" .) -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kubernetes-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubernetes-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels

managed-by is written out, as Helm itself would always fill it in ("Helm"):
Amazon EKS renders this chart as an add-on too (HelmChart/Marketplace), and
refuses a chart that reads any Release object but .Name and .Namespace.
*/}}
{{- define "kubernetes-agent.labels" -}}
helm.sh/chart: {{ include "kubernetes-agent.chart" . }}
{{ include "kubernetes-agent.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: Helm
app.kubernetes.io/part-of: oneuptime
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubernetes-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubernetes-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "kubernetes-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- include "kubernetes-agent.fullname" . }}
{{- end }}
{{- end }}

{{/*
Pod nodeSelector with the Linux-only pin merged in.

Every image this chart deploys — the OTel collectors, OBI, the profiler,
OpenCost, Prometheus, kube-state-metrics, the cost and log agents — is built
for linux only. On mixed-OS clusters (e.g. AKS with Windows node pools) an
unpinned pod spec can be scheduled onto a Windows node, where the image pull
can never succeed and the pod sits in ImagePullBackOff forever; the
DaemonSets are guaranteed to hit this because they tolerate every taint.
The kubelet labels every node with kubernetes.io/os (stable since
Kubernetes 1.14), so requiring "linux" is always safe.

Takes the workload's user-configured nodeSelector map (or an empty dict when
the workload has no such knob). User-supplied keys win on conflict.

Usage (the include is nindent-ed under the `nodeSelector:` key):
  nodeSelector:
    {{`{{- include "kubernetes-agent.nodeSelector" .Values.ebpf.nodeSelector | nindent 8 }}`}}
*/}}
{{- define "kubernetes-agent.nodeSelector" -}}
{{- /* mergeOverwrite, not merge: sprig merge won't let a zero value ("")
     in the user map displace the pin, breaking last-writer-wins. The
     dest dict is a fresh literal, so .Values is never mutated. */ -}}
{{- toYaml (mergeOverwrite (dict "kubernetes.io/os" "linux") (. | default dict)) -}}
{{- end }}

{{/*
Build the OTEL_EBPF_METRICS_FEATURES env var value from .Values.ebpf.features
toggles. Returns a comma-separated string of the OBI feature names that are
currently enabled. (An empty string does NOT mean "no metrics": OBI falls back
to its default, `application`.) Current OBI (since v0.11) refuses to start on a token it does
not know, so every token here must exist in the pinned version.
*/}}
{{- define "kubernetes-agent.ebpfMetricsFeatures" -}}
{{- $features := list -}}
{{- if .Values.ebpf.features.httpMetrics -}}{{- $features = append $features "application" -}}{{- end -}}
{{- /* `application_span_otel`, not OBI's deprecated `application_span`: the
     same spans, attributes and buckets, named traces.span.metrics.calls and
     traces.span.metrics.duration (seconds) instead of
     traces_spanmetrics_calls_total and traces_spanmetrics_latency. Every OBI
     release has it, so it needs no version gate; OBI warns about the old name
     since v0.12.2, and refuses the two together. */ -}}
{{- if .Values.ebpf.features.spanMetrics -}}{{- $features = append $features "application_span_otel" -}}{{- end -}}
{{- if .Values.ebpf.features.serviceGraph -}}{{- $features = append $features "application_service_graph" -}}{{- end -}}
{{- /* ebpf.features.hostMetrics is ignored on purpose: its `application_host`
     feature is gone in OBI v0.14, and an unknown token stops OBI starting. */ -}}
{{- if .Values.ebpf.features.networkMetrics -}}{{- $features = append $features "network" -}}{{- end -}}
{{- if .Values.ebpf.features.networkInterZoneMetrics -}}{{- $features = append $features "network_inter_zone" -}}{{- end -}}
{{- /* Not `stats`: in current OBI that also turns on stats_tcp_io, a probe on
     every TCP send and receive — far more events than the three
     close/failure/retransmit counters tcpStats describes. */ -}}
{{- if .Values.ebpf.features.tcpStats -}}{{- $features = concat $features (list "stats_tcp_rtt" "stats_tcp_failed_connections" "stats_tcp_retransmits") -}}{{- end -}}
{{- join "," $features -}}
{{- end }}

{{/*
Split a comma-separated glob list (ebpf.autoTargetExe, ebpf.excludeExePaths)
into a JSON array: entries trimmed, blanks and duplicates dropped, order kept.

OBI compiles each `exe_path` selector as ONE gobwas glob, in which a comma is
a literal character, so the sh and bash globs handed over joined by a comma
match no executable at all. Each entry has to become its own selector.
(No glob examples in this comment: a star followed by a slash would end it.)
Usage: {{ include "kubernetes-agent.globList" .Values.ebpf.excludeExePaths | fromJsonArray }}
*/}}
{{- define "kubernetes-agent.globList" -}}
{{- /* Split on commas outside braces only: a brace alternative such as
     python-or-java inside one pattern is one glob to OBI (and was one entry
     when the whole string went to OTEL_EBPF_AUTO_TARGET_EXE), so cutting it
     at its comma would leave two broken halves that match far less. */ -}}
{{- $out := list -}}
{{- $current := "" -}}
{{- $depth := 0 -}}
{{- range (splitList "" ((. | default "") | toString)) -}}
{{- if and (eq . ",") (eq (int $depth) 0) -}}
{{- $glob := trim $current -}}
{{- if and $glob (not (has $glob $out)) -}}
{{- $out = append $out $glob -}}
{{- end -}}
{{- $current = "" -}}
{{- else -}}
{{- if eq . "{" -}}
{{- $depth = add1 $depth -}}
{{- else if and (eq . "}") (gt (int $depth) 0) -}}
{{- $depth = sub $depth 1 -}}
{{- end -}}
{{- $current = printf "%s%s" $current . -}}
{{- end -}}
{{- end -}}
{{- $glob := trim $current -}}
{{- if and $glob (not (has $glob $out)) -}}
{{- $out = append $out $glob -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}

{{/*
The OBI configuration file (templates/configmap-ebpf.yaml, mounted at
/etc/obi/obi-config.yaml and named by OTEL_EBPF_CONFIG_PATH).

Process selection lives here because OBI has no environment variable for it:
the chart used to set OTEL_EBPF_EXCLUDE_AUTO_TARGET_EXE,
OTEL_EBPF_DISCOVERY_NAMESPACE and OTEL_EBPF_DISCOVERY_EXCLUDE_NAMESPACE, none
of which any OBI release reads, so excludeExePaths and the ebpfDiscovery
namespace rules silently did nothing.

  discovery.instrument — one selector per autoTargetExe glob, each also
    requiring a Kubernetes namespace: `k8s_namespace: "*"`, or with namespace
    include rules one selector per (glob, namespace) pair. The namespace
    requirement keeps node daemons (kubelet, containerd, sshd — processes with
    no pod) out, which OBI v0.10+ otherwise matches, and holds back a pod's
    process until OBI knows its pod, so a namespace exclusion cannot be
    skipped by a process seen before its pod metadata arrived.
    OTEL_EBPF_AUTO_TARGET_EXE must NOT be set alongside: OBI ORs it in as one
    more selector, which would widen discovery back to every namespace.
  discovery.exclude_instrument — one selector per excludeExePaths glob and
    per excluded namespace. OBI still appends its built-in exclusions (itself,
    OTel collectors, the system namespaces) after these.
  discovery.disabled_route_harvesters, discovery.route_harvester_timeout —
    from ebpf.routes.disabledHarvesters and ebpf.routes.harvestTimeout: the
    languages OBI does not harvest route templates for (Node.js by default),
    and how long it waits for one process's. Blank languages are dropped, and
    neither key is written when unset or empty, so OBI's defaults (every
    language, 10s) apply.
  attributes.select.traces.include — the span attributes OBI exports; see
    kubernetes-agent.obiSpanAttributes.

OBI decodes this file on top of its defaults, so anything not written here
keeps OBI's default.
*/}}
{{- define "kubernetes-agent.obiConfig" -}}
{{- $targets := include "kubernetes-agent.globList" .Values.ebpf.autoTargetExe | fromJsonArray -}}
{{- if not $targets -}}
{{- /* An empty selector is a config error that stops OBI from starting. */ -}}
{{- $targets = list "*" -}}
{{- end -}}
{{- $excludes := include "kubernetes-agent.globList" .Values.ebpf.excludeExePaths | fromJsonArray -}}
{{- $nsInclude := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "ebpfDiscovery") | fromJsonArray -}}
{{- $nsExclude := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "ebpfDiscovery") | fromJsonArray -}}
{{- $routes := .Values.ebpf.routes | default dict -}}
discovery:
  instrument:
{{- if $nsInclude }}
{{- range $ns := $nsInclude }}
{{- range $exe := $targets }}
    - exe_path: {{ $exe | quote }}
      k8s_namespace: {{ $ns | quote }}
{{- end }}
{{- end }}
{{- else }}
{{- range $exe := $targets }}
    - exe_path: {{ $exe | quote }}
      k8s_namespace: "*"
{{- end }}
{{- end }}
{{- if or $excludes $nsExclude }}
  exclude_instrument:
{{- range $excludes }}
    - exe_path: {{ . | quote }}
{{- end }}
{{- range $nsExclude }}
    - k8s_namespace: {{ . | quote }}
{{- end }}
{{- end }}
{{- /* Blanks dropped: `--set ebpf.routes.disabledHarvesters={}` gives [""]. */}}
{{- $harvestersOff := list }}
{{- range ($routes.disabledHarvesters | default list) }}
{{- if . }}
{{- $harvestersOff = append $harvestersOff . }}
{{- end }}
{{- end }}
{{- with $harvestersOff }}
  disabled_route_harvesters:
{{- range . }}
    - {{ . | quote }}
{{- end }}
{{- end }}
{{- with $routes.harvestTimeout }}
  route_harvester_timeout: {{ . | quote }}
{{- end }}
{{- if or $routes.patterns $routes.unmatched }}
routes:
{{- with $routes.unmatched }}
  unmatched: {{ . | quote }}
{{- end }}
{{- with $routes.patterns }}
  patterns:
{{- range . }}
    - {{ . | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- $selectSpanAttributes := eq (include "kubernetes-agent.obiSelectsSpanAttributes" .) "true" }}
{{- $serviceNameLabels := include "kubernetes-agent.serviceNameLabels" . | fromJsonArray }}
{{- if $selectSpanAttributes }}
# Span attributes. A list here replaces OBI's default set rather than adding
# to it, so it repeats those defaults; service.peer.name is opt-in since v0.14.
{{- end }}
{{- if or $selectSpanAttributes $serviceNameLabels }}
attributes:
{{- end }}
{{- if $selectSpanAttributes }}
  select:
    traces:
      include:
{{- range (include "kubernetes-agent.obiSpanAttributes" . | fromJsonArray) }}
        - {{ . | quote }}
{{- end }}
{{- end }}
{{- if $serviceNameLabels }}
  # The pod labels a service is named after, first one set wins
  # (ebpf.serviceNameLabels). OBI keeps its own lists for service.namespace
  # and service.version.
  kubernetes:
    resource_labels:
      service.name:
{{- range $serviceNameLabels }}
        - {{ . | quote }}
{{- end }}
{{- end }}
{{- if .Values.ebpf.logToTraceCorrelation }}
# The log enricher's process selector has no env var equivalent either.
ebpf:
  log_enricher:
    services:
{{ toYaml .Values.ebpf.logEnricher.services | indent 6 }}
{{- if eq (include "kubernetes-agent.logEnricherPlainText" .) "true" }}
    # Plain-text lines too (ebpf.logEnricher.plainText): OBI appends
    # " trace_id=… span_id=…" to every line of a non-JSON write, and the node
    # collector lifts it into the record's trace context and strips it from
    # the body. The line in the container's log file keeps it.
    plain_text:
      enabled: true
      placement: suffix
      multiline: each_line
{{- else }}
    # JSON lines only, as documented on ebpf.logToTraceCorrelation. Since
    # v0.11 OBI also appends " trace_id=… span_id=…" to plain-text lines by
    # default, which changes every non-JSON log line the app writes; the node
    # collector parses it only with ebpf.logEnricher.plainText.
    plain_text:
      enabled: false
{{- end }}
{{- end }}
{{- end }}

{{/*
The span attributes OBI is told to export (attributes.select.traces.include in
the OBI config file), as a JSON array: OBI's nine default span attributes,
then service.peer.name, then ebpf.extraSpanAttributes, trimmed, with blanks,
repeats and a bare "*" dropped.

service.peer.name: OBI v0.14 made it opt-in, together with the HTTP body
sizes and obi.http.response.observed (OBI #3559). OneUptime's service map
names the service a client call went to from it (ServiceDependencyDiscovery);
without it those calls fall back to server.address, which re-keys the remote
services the map already shows and so duplicates their nodes.

Why the defaults are repeated: a non-empty include list REPLACES OBI's
default set instead of adding to it (AttrSelector.For in
pkg/export/attributes/attr_selector.go falls back to the defaults only when
the include list is empty). Asking for service.peer.name alone would drop
error.type, network.peer.address and the rest. The nine are the `true`
entries of Traces.Section in pkg/export/attributes/attr_defs.go of the pinned
OBI; re-check them whenever ebpf.image.tag moves. The list is v0.14's, so it
is only rendered for v0.14 and later (kubernetes-agent.obiSelectsSpanAttributes):
an older OBI has other defaults (v0.9 kept url.query off, so the list would
start exporting query strings) and sends service.peer.name anyway.

Why "*" is refused: OBI matches each entry as a glob, and a bare star opts in
to every optional span attribute, among them db.query.text (the full SQL or
Redis command, with whatever literal values it carries) and the gen_ai
prompt, completion and system-instruction payloads. Those stay opt-in by
name.
*/}}
{{- define "kubernetes-agent.obiSpanAttributes" -}}
{{- /* See the comment above. */ -}}
{{- $attrs := list "dns.question.name" "url.query" "error.type" "http.request.method_original" "db.query.summary" "user_agent.original" "network.peer.address" "network.peer.port" "network.protocol.version" "service.peer.name" -}}
{{- range (.Values.ebpf.extraSpanAttributes | default list) -}}
{{- $name := trim (toString .) -}}
{{- if and $name (ne $name "*") (not (has $name $attrs)) -}}
{{- $attrs = append $attrs $name -}}
{{- end -}}
{{- end -}}
{{- toJson $attrs -}}
{{- end }}

{{/*
ebpf.serviceNameLabels as a JSON array of pod label keys, trimmed, with
blanks and repeats dropped. Empty (the default, or a values file without the
key) leaves OBI's own order, written as attributes.kubernetes.resource_labels
only when there is something to write. OBI decodes resource_labels onto its
defaults key by key (pkg/kube/store.go DefaultResourceLabels), so setting
service.name keeps its service.namespace and service.version lists.
*/}}
{{- define "kubernetes-agent.serviceNameLabels" -}}
{{- $labels := list -}}
{{- range (.Values.ebpf.serviceNameLabels | default list) -}}
{{- $label := trim (toString .) -}}
{{- if and $label (not (has $label $labels)) -}}
{{- $labels = append $labels $label -}}
{{- end -}}
{{- end -}}
{{- toJson $labels -}}
{{- end }}

{{/*
Whether OBI's log enricher annotates plain-text lines too, and the node
collector parses that annotation (ebpf.logEnricher.plainText): only with
ebpf.logToTraceCorrelation on, and only when explicitly true — it changes the
line every non-JSON write leaves in the container's log file.
*/}}
{{- define "kubernetes-agent.logEnricherPlainText" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") .Values.ebpf.logToTraceCorrelation (eq (toString ((.Values.ebpf.logEnricher | default dict).plainText)) "true") -}}
{{- end }}

{{/*
Base OTTL span condition for `filter/ebpf-unlinked-db`: an eBPF (OBI) span
with a database system. See ebpf.dropDatabaseServerSpans and
ebpf.dropUnlinkedDatabaseCalls.

  - telemetry.distro.name scopes it to OBI. The receiver also takes spans
    that applications push from their own SDKs, and those are none of this
    filter's business.
  - db.system.name is the current semantic-convention key and what OBI
    emits; db.system is the older one, kept so an OBI that still emits it is
    covered too.
  - The calls condition adds parent_span_id == SpanID(0x0000000000000000),
    "no parent" in a form both the pinned collector (0.161.0) and 0.96.0,
    which a --reuse-values upgrade keeps, understand; IsRootSpan() is newer
    than 0.96.0.
*/}}
{{/*
Whether to drop each kind of unlinked eBPF database span in
`filter/ebpf-unlinked-db` (ebpf.dropDatabaseServerSpans,
ebpf.dropUnlinkedDatabaseCalls). Only with eBPF on (the traces pipeline exists
only then), and on unless explicitly set to false: an upgrade with
--reuse-values keeps the old release's values, which do not have these keys,
and a default-on fix should not silently stay off for those clusters.
Usage: {{- if eq (include "kubernetes-agent.ebpfDatabaseFilterEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.dropDatabaseServerSpans" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString .Values.ebpf.dropDatabaseServerSpans) "false") -}}
{{- end -}}

{{- define "kubernetes-agent.dropUnlinkedDatabaseCalls" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString .Values.ebpf.dropUnlinkedDatabaseCalls) "false") -}}
{{- end -}}

{{/*
Database proxies (ebpf.databaseProxyNames, ebpf.dropDatabaseProxySpans).

A proxy or connection pooler (PgBouncer, ProxySQL, mongos, ...) is both a
database server and a database client: OBI records a SERVER span for each
command an application sends it and a CLIENT span, hung under that server
span, for the command it passes on. dropDatabaseServerSpans drops the server
span, so without this every passed-on command reaches OneUptime pointing at a
parent that was never sent — a one-span trace marked "1 span missing a
parent". On the test cluster that was three quarters of all one-span traces.

kubernetes-agent.defaultDatabaseProxyNames is the list a values file without
ebpf.databaseProxyNames gets (a release upgraded with --reuse-values); keep it
equal to values.yaml.
*/}}
{{- define "kubernetes-agent.defaultDatabaseProxyNames" -}}
{{- toJson (list "pgbouncer" "pgcat" "pgdog" "odyssey" "pgpool" "supavisor" "connection-pooler" "proxysql" "maxscale" "mysqlrouter" "mysql-router" "vtgate" "mongos" "twemproxy" "nutcracker" "predixy") -}}
{{- end -}}

{{/*
ebpf.databaseProxyNames as a JSON array: trimmed, blanks and repeats dropped.
A missing key (nil) gets the default list; an explicit [] turns proxy
detection off.
*/}}
{{- define "kubernetes-agent.databaseProxyNames" -}}
{{- $raw := .Values.ebpf.databaseProxyNames -}}
{{- if kindIs "invalid" $raw -}}
{{- $raw = include "kubernetes-agent.defaultDatabaseProxyNames" . | fromJsonArray -}}
{{- end -}}
{{- $names := list -}}
{{- range $raw -}}
{{- $name := trim (toString .) -}}
{{- if and $name (not (has $name $names)) -}}
{{- $names = append $names $name -}}
{{- end -}}
{{- end -}}
{{- toJson $names -}}
{{- end -}}

{{/*
The OTTL condition that a span comes from a database proxy, or "" with no
names: the container, the service name OBI gives the process, or its
Deployment / StatefulSet / DaemonSet name contains one of the names as a word,
case-insensitively — "pgbouncer" matches `oneuptime-pgbouncer` and
`pgbouncer-0`, not `mypgbouncer`. OBI sets all of these on its resource.
Each attribute is checked for nil before IsMatch, so a span without one
(a process OBI saw outside a Deployment) is still judged on the others.
A name is regex-quoted, then its backslashes and quotes are escaped once more
for the OTTL string literal, which reads `\\` as one backslash.
*/}}
{{- define "kubernetes-agent.databaseProxyCondition" -}}
{{- $names := include "kubernetes-agent.databaseProxyNames" . | fromJsonArray -}}
{{- if $names -}}
{{- $quoted := list -}}
{{- range $names -}}
{{- $quoted = append $quoted (regexQuoteMeta . | replace "\\" "\\\\" | replace "\"" "\\\"") -}}
{{- end -}}
{{- $pattern := printf "(?i)(^|[^a-z0-9])(%s)([^a-z0-9]|$)" (join "|" $quoted) -}}
{{- $checks := list -}}
{{- range (list "k8s.container.name" "service.name" "k8s.deployment.name" "k8s.statefulset.name" "k8s.daemonset.name") -}}
{{- $checks = append $checks (printf "(resource.attributes[\"%s\"] != nil and IsMatch(resource.attributes[\"%s\"], \"%s\"))" . . $pattern) -}}
{{- end -}}
{{- printf "(%s)" (join " or " $checks) -}}
{{- end -}}
{{- end -}}

{{/*
Whether to drop every eBPF database span of a database proxy
(ebpf.dropDatabaseProxySpans): with eBPF on, names to match, and on unless
explicitly false, for the same --reuse-values reason as the switches above.
*/}}
{{- define "kubernetes-agent.dropDatabaseProxySpans" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString .Values.ebpf.dropDatabaseProxySpans) "false") (ne (include "kubernetes-agent.databaseProxyCondition" .) "") -}}
{{- end -}}

{{- define "kubernetes-agent.ebpfDatabaseFilterEnabled" -}}
{{- or (eq (include "kubernetes-agent.dropDatabaseServerSpans" .) "true") (eq (include "kubernetes-agent.dropUnlinkedDatabaseCalls" .) "true") (eq (include "kubernetes-agent.dropDatabaseProxySpans" .) "true") -}}
{{- end -}}

{{/*
The OTTL span conditions of `filter/ebpf-unlinked-db`, as a JSON array: one
per enabled switch, all on the base below.

  - server (ebpf.dropDatabaseServerSpans): `kind == SPAN_KIND_SERVER`, with
    or without a parent. It is the span OBI records inside the database
    server, and it duplicates the caller's client span either way: unlinked
    it is a one-span trace, and linked (OBI links the two ends of a
    connection when the caller runs on the same node) it doubles every
    database call in the request trace. Keeping the linked ones would also
    leave them pointing at a missing parent whenever the calls switch drops
    the client span they hang from. With ebpf.dropDatabaseProxySpans off, a
    proxy's server spans are exempt (`not` the proxy condition): they are
    the parents of the commands it passes on, which are kept.
  - calls (ebpf.dropUnlinkedDatabaseCalls): `kind != SPAN_KIND_SERVER` and no
    parent — the application's own call, outside any trace.
  - proxies (ebpf.dropDatabaseProxySpans): every database span of a
    database proxy, server and client alike, so none is left pointing at a
    dropped parent.
*/}}
{{- define "kubernetes-agent.ebpfUnlinkedDatabaseSpanConditions" -}}
{{- $base := include "kubernetes-agent.ebpfDatabaseSpanCondition" . -}}
{{- $proxy := include "kubernetes-agent.databaseProxyCondition" . -}}
{{- $dropProxies := eq (include "kubernetes-agent.dropDatabaseProxySpans" .) "true" -}}
{{- $conds := list -}}
{{- if eq (include "kubernetes-agent.dropDatabaseServerSpans" .) "true" -}}
{{- if and $proxy (not $dropProxies) -}}
{{- $conds = append $conds (printf "%s and kind == SPAN_KIND_SERVER and not %s" $base $proxy) -}}
{{- else -}}
{{- $conds = append $conds (printf "%s and kind == SPAN_KIND_SERVER" $base) -}}
{{- end -}}
{{- end -}}
{{- if eq (include "kubernetes-agent.dropUnlinkedDatabaseCalls" .) "true" -}}
{{- $conds = append $conds (printf "%s and parent_span_id == SpanID(0x0000000000000000) and kind != SPAN_KIND_SERVER" $base) -}}
{{- end -}}
{{- if $dropProxies -}}
{{- $conds = append $conds (printf "%s and %s" $base $proxy) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{- define "kubernetes-agent.ebpfDatabaseSpanCondition" -}}
resource.attributes["telemetry.distro.name"] == "opentelemetry-ebpf-instrumentation" and (attributes["db.system.name"] != nil or attributes["db.system"] != nil)
{{- end }}

{{/*
Whether to drop OBI's other client calls that belong to no trace in
`filter/ebpf-unlinked-client` (ebpf.dropUnlinkedClientCalls). Only with eBPF
on, and OFF unless explicitly set to true — the opposite of the database
switches above. A stateless filter cannot tell a one-span call from the root
of a trace: when the callee is traced by OBI on the same node (on any node
with ebpf.contextPropagation, which also hands the call's context to a callee
running its own OpenTelemetry SDK), its request hangs under the call, and
dropping the call leaves that trace without its root (see the value for what
else it costs). So a release upgraded with --reuse-values, whose values
predate the key, keeps every span as before.
*/}}
{{- define "kubernetes-agent.dropUnlinkedClientCalls" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (eq (toString .Values.ebpf.dropUnlinkedClientCalls) "true") -}}
{{- end -}}

{{/*
OTTL span condition of `filter/ebpf-unlinked-client`: an OBI CLIENT span with
no parent that is none of the calls other features read from spans.

  - telemetry.distro.name and the "no parent" form as for the database
    condition above (parent_span_id == SpanID(0x0000000000000000) is what
    both the pinned collector, 0.161.0, and 0.96.0 understand).
  - kind == SPAN_KIND_CLIENT only: PRODUCER and CONSUMER spans are messaging
    and always kept, as are SERVER spans (a request is a trace's root) and
    INTERNAL ones.
  - Database calls (db.system.name / db.system) are left to
    filter/ebpf-unlinked-db, so the two filters never match the same span and
    ebpf.dropUnlinkedDatabaseCalls=false keeps them whatever this switch says.
  - Messaging calls (messaging.system): OBI v0.14 types a receive or settle
    as CLIENT, and OneUptime's queue discovery reads every messaging span
    that is not SERVER.
  - GenAI calls (gen_ai.operation.name, which OBI v0.14 sets on every call
    to a model provider; gen_ai.system for an OBI on the older semantic
    conventions): OneUptime's LLM cost and token figures come from these
    spans, and it turns to the GenAI metrics only when there are none at
    all, so dropping a batch job's calls would under-count them, not hand
    them to the metrics.
  - MCP calls (mcp.method.name, on every MCP span OBI v0.14 records): it sets
    gen_ai.operation.name only on tools/call, yet a prompts/get still carries
    gen_ai.prompt.name, and OneUptime counts any span with a gen_ai.* key as
    an LLM span.
*/}}
{{- define "kubernetes-agent.ebpfUnlinkedClientSpanCondition" -}}
resource.attributes["telemetry.distro.name"] == "opentelemetry-ebpf-instrumentation" and kind == SPAN_KIND_CLIENT and parent_span_id == SpanID(0x0000000000000000) and attributes["db.system.name"] == nil and attributes["db.system"] == nil and attributes["messaging.system"] == nil and attributes["gen_ai.operation.name"] == nil and attributes["gen_ai.system"] == nil and attributes["mcp.method.name"] == nil
{{- end }}

{{/*
Whether to drop OBI's HTTP server metrics for its own Node.js inspector
requests in `filter/ebpf-node-inspector` (ebpf.dropNodeInspectorMetrics).
Only with eBPF on (OBI is what sends them) and its Node.js agent on (with
ebpf.nodejs.enabled=false OBI never injects, so the filter could only drop an
app's own datapoints), and on unless explicitly set to false, for the same
--reuse-values reason as the database switches above.
*/}}
{{- define "kubernetes-agent.dropNodeInspectorMetrics" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString ((.Values.ebpf.nodejs | default dict).enabled)) "false") (ne (toString .Values.ebpf.dropNodeInspectorMetrics) "false") -}}
{{- end -}}

{{/*
OTTL datapoint condition of `filter/ebpf-node-inspector`. OBI v0.14 injects
its Node.js agent through the app's inspector after it has started tracing
the process, so its own GET /json/list (GET /json/version too, when the
inspector was already open) and the WebSocket upgrade that follows, on
127.0.0.1:9229, count in the app's http.server.* metrics under the routes
/json/list, /json/version and /* (answered 101).

  - telemetry.distro.name scopes it to OBI: the receiver also takes what
    applications push from their own SDKs.
  - A datapoint has no client address, so this cannot tell OBI's requests
    from anyone else's on port 9229: an app's own GET /json/list or
    /json/version there, and its own WebSocket upgrades there that OBI names
    /* (no route template), lose their datapoints too. OneUptime drops the
    matching spans on ingest, where the client address is known.
  - http.route, not url.path: OBI's metrics carry only the route. These are
    the names OBI gives those requests with the default route naming
    (ebpf.routes.unmatched heuristic); with another ebpf.routes.unmatched,
    or an ebpf.routes.patterns entry that matches them, some or all of the
    injection's datapoints are kept.
  - Only http.server.*. OBI's span metrics (ebpf.features.spanMetrics) carry
    neither the port nor the HTTP status, only the span name, so they still
    count a GET /json/list call per injection (and a GET /json/version for
    an app started with --inspect) and add the upgrade to the app's GET /*.
    Dropping span.name "GET /json/list" would also drop a real DevTools
    endpoint's (a headless Chrome or browserless service), so they are left
    alone.
*/}}
{{- define "kubernetes-agent.ebpfNodeInspectorMetricCondition" -}}
resource.attributes["telemetry.distro.name"] == "opentelemetry-ebpf-instrumentation" and IsMatch(metric.name, "^http\\.server\\.") and attributes["server.port"] == 9229 and attributes["http.request.method"] == "GET" and (attributes["http.route"] == "/json/list" or attributes["http.route"] == "/json/version" or (attributes["http.route"] == "/*" and attributes["http.response.status_code"] == 101))
{{- end }}

{{/*
Whether the pinned OBI takes the span-attribute list in
kubernetes-agent.obiSpanAttributes: v0.14 or later, or a tag that is not a
version at all (a branch build or a digest), which is assumed current.
*/}}
{{- define "kubernetes-agent.obiSelectsSpanAttributes" -}}
{{- $tag := toString ((.Values.ebpf.image | default dict).tag) -}}
{{- $version := regexFind "^v?[0-9]+\\.[0-9]+\\.[0-9]+" $tag -}}
{{- if $version -}}
{{- semverCompare ">=0.14.0-0" $version -}}
{{- else -}}
true
{{- end -}}
{{- end }}

{{/*
Render .Values.oneuptime.labels as OTel resource-processor attribute entries.

The OneUptime ingest pipeline promotes any resource attribute prefixed with
`oneuptime.label.` into a project Label of the form `<key>:<value>` and
attaches it to the cluster/service/host that emitted the record — see
Common/Server/Utils/Telemetry/OneuptimeLabel.ts.

Pass the action ("insert" or "upsert") so the caller can match the surrounding
processor's existing semantics:
  - "insert" — only set if the attribute is absent (use in pipelines that
    forward telemetry the in-cluster collector didn't originate, e.g. OBI
    traces passing through the metrics Deployment).
  - "upsert" — always set, overwriting any upstream value.

Usage:
  {{- include "kubernetes-agent.oneuptimeLabels" (dict "labels" .Values.oneuptime.labels "action" "insert") | nindent 10 }}
*/}}
{{- define "kubernetes-agent.oneuptimeLabels" -}}
{{- $action := .action | default "insert" -}}
{{- range $key, $value := .labels }}
- key: oneuptime.label.{{ $key }}
  value: {{ $value | quote }}
  action: {{ $action }}
{{- end }}
{{- end }}

{{/*
Parse a Kubernetes memory quantity into an integer number of mebibytes (MiB),
rounded down. Supports the binary (Ki/Mi/Gi/Ti) and decimal (k/K/M/G/T)
suffixes Kubernetes accepts, plus a plain byte count with no suffix. Arithmetic
goes through sprig's float helpers (mulf/divf coerce their string args to
float64), so fractional quantities like "1.5Gi" parse correctly.

  {{ include "kubernetes-agent.memToMib" "512Mi" }}  -> 512
  {{ include "kubernetes-agent.memToMib" "4Gi" }}    -> 4096
*/}}
{{- define "kubernetes-agent.memToMib" -}}
{{- $q := . | toString | trim -}}
{{- $mib := 0.0 -}}
{{- if hasSuffix "Gi" $q -}}
{{- $mib = mulf (trimSuffix "Gi" $q) 1024 -}}
{{- else if hasSuffix "Mi" $q -}}
{{- $mib = mulf (trimSuffix "Mi" $q) 1 -}}
{{- else if hasSuffix "Ki" $q -}}
{{- $mib = divf (trimSuffix "Ki" $q) 1024 -}}
{{- else if hasSuffix "Ti" $q -}}
{{- $mib = mulf (trimSuffix "Ti" $q) 1048576 -}}
{{- else if hasSuffix "G" $q -}}
{{- $mib = divf (mulf (trimSuffix "G" $q) 1000000000) 1048576 -}}
{{- else if hasSuffix "M" $q -}}
{{- $mib = divf (mulf (trimSuffix "M" $q) 1000000) 1048576 -}}
{{- else if hasSuffix "K" $q -}}
{{- $mib = divf (mulf (trimSuffix "K" $q) 1000) 1048576 -}}
{{- else if hasSuffix "k" $q -}}
{{- $mib = divf (mulf (trimSuffix "k" $q) 1000) 1048576 -}}
{{- else -}}
{{- $mib = divf $q 1048576 -}}
{{- end -}}
{{- $mib | floor | int -}}
{{- end }}

{{/*
limit_mib for the OTel memory_limiter: 80% of a container memory limit, in MiB.
Shared by the memory_limiter processor config and the GOMEMLIMIT env var so the
two are derived from the same number and can never drift from the cgroup limit.
Argument: the container memory limit quantity (e.g. "512Mi", "4Gi").
*/}}
{{- define "kubernetes-agent.memLimitMib" -}}
{{- mulf (include "kubernetes-agent.memToMib" .) 0.8 | floor | int -}}
{{- end }}

{{/*
Render the OTel `memory_limiter` processor body (check_interval / limit_mib /
spike_limit_mib) derived from a container memory limit, so limit_mib always
sits *below* the cgroup limit. If the limiter were set above the container
limit the kernel would OOMKill the pod before the limiter could shed load —
which is exactly the failure this avoids. Follows OTel guidance: limit_mib ≈
80% of the container limit, spike_limit_mib ≈ 20% of limit_mib.

Usage (the include is nindent-ed under the `memory_limiter:` key):
  memory_limiter:
    {{`{{- include "kubernetes-agent.memoryLimiter" "512Mi" | nindent 8 }}`}}
*/}}
{{- define "kubernetes-agent.memoryLimiter" -}}
{{- $hard := include "kubernetes-agent.memLimitMib" . | int -}}
check_interval: 5s
limit_mib: {{ $hard }}
spike_limit_mib: {{ mulf $hard 0.2 | floor | int }}
{{- end }}

{{/*
GOMEMLIMIT value (the Go runtime soft memory limit) for a collector container:
80% of the container memory limit, with the MiB suffix the Go runtime expects.
Matches the memory_limiter's limit_mib so the Go GC starts reclaiming at the
same threshold the limiter begins shedding load, keeping total RSS under the
cgroup limit. Argument: the container memory limit quantity.
*/}}
{{- define "kubernetes-agent.gomemlimit" -}}
{{- printf "%dMiB" (include "kubernetes-agent.memLimitMib" . | int) -}}
{{- end }}

{{/*
Debug sidecar container. Rendered into the metrics Deployment and logs
DaemonSet when .Values.debug.enabled is true.

The agent's collector images are distroless (built FROM scratch) — they ship
only the collector binary, so they have no /bin/sh, bash, or curl and cannot be
`kubectl exec`-ed into. This parks a shell + network-tooling container (default:
nicolaka/netshoot) next to the collector. Combined with the pod's shared
network namespace (every container in a pod shares one), a curl from here
follows the exact egress path — NetworkPolicy, DNS, proxy, TLS — the collector
uses. See values.yaml (debug.*) for the rationale and security trade-offs.

  kubectl exec -it <agent-pod> -c debug -- bash
  curl -v "$ONEUPTIME_URL/otlp/v1/metrics"

Usage (nindent to the `containers:` list-item column):
  {{- include "kubernetes-agent.debugContainer" . | nindent 8 }}
*/}}
{{- define "kubernetes-agent.debugContainer" -}}
- name: debug
  image: "{{ .Values.debug.image.repository }}:{{ .Values.debug.image.tag }}"
  imagePullPolicy: {{ .Values.debug.image.pullPolicy }}
  {{- with .Values.debug.command }}
  # netshoot's default entrypoint is an interactive shell, which exits
  # immediately (CrashLoop) in a pod with no TTY — so park it on a no-op.
  command:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.debug.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  resources:
    {{- toYaml .Values.debug.resources | nindent 4 }}
  {{- with .Values.oneuptime.url }}
  env:
    # Convenience for `curl "$ONEUPTIME_URL/otlp/v1/metrics"`.
    - name: ONEUPTIME_URL
      value: {{ . | quote }}
  {{- end }}
{{- end }}

{{/*
Effective log collection mode.

Resolution order:
  1. Explicit .Values.logs.mode ("daemonset" | "api" | "disabled") always wins.
  2. Otherwise .Values.preset decides:
       "gke-autopilot" / "eks-fargate" -> api
       "standard" / "" / unset         -> daemonset
  3. Anything else falls back to "daemonset".
*/}}
{{- define "kubernetes-agent.logMode" -}}
{{- $explicit := default "" .Values.logs.mode -}}
{{- if $explicit -}}
{{- $explicit -}}
{{- else -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "gke-autopilot") (eq $preset "eks-fargate") -}}
api
{{- else -}}
daemonset
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Hybrid log collection for mixed-OS clusters. The DaemonSet collector is
pinned to Linux nodes (its images are linux-only), so in daemonset log mode
pods on Windows nodes have no log collection at all. When
`logs.windowsPods.enabled` is set, the API log tailer runs ALONGSIDE the
DaemonSet, restricted via NODE_OS_INCLUDE=windows to exactly the pods the
DaemonSet cannot reach — the two collectors partition pods by node OS, so no
log line ships twice. Only meaningful in daemonset mode: full api mode
already tails every pod, and disabled mode collects nothing.
Usage: {{- if eq (include "kubernetes-agent.windowsPodLogsEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.windowsPodLogsEnabled" -}}
{{- if and .Values.logs.enabled (((.Values.logs).windowsPods).enabled) (eq (include "kubernetes-agent.logMode" .) "daemonset") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the log-tailer Deployment exists at all — full api mode, or the
Windows-only hybrid above. The pods/log RBAC grant is keyed on this same
helper so the tailer and its permissions can never drift apart.
*/}}
{{- define "kubernetes-agent.logTailerEnabled" -}}
{{- if and .Values.logs.enabled (or (eq (include "kubernetes-agent.logMode" .) "api") (eq (include "kubernetes-agent.windowsPodLogsEnabled" .) "true")) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the collector the agent runs (image.tag) is at least a given version,
for the few config keys a release added: the collector refuses a config with
a key it does not know, and `helm upgrade --reuse-values` keeps the previous
release's image.tag (0.96.0 on a release from before 0.161.0, see
_stale-defaults.tpl), so a key newer than the image it renders for would stop
the agent. The version is read from the front of the tag (`0.161.0`,
`v0.161.0`, `0.161.0@sha256:...`); a tag that names no version (`latest`, a
mirror's own name) counts as this chart's default.
Usage: {{- if eq (include "kubernetes-agent.collectorAtLeast" (dict "root" . "version" "0.157.0")) "true" }}
*/}}
{{- define "kubernetes-agent.collectorAtLeast" -}}
{{- $tag := toString ((.root.Values.image | default dict).tag | default "") -}}
{{- $version := regexFind "^[0-9]+\\.[0-9]+\\.[0-9]+" (trimPrefix "v" $tag) | default (include "kubernetes-agent.defaultCollectorImageTag" .root) -}}
{{- semverCompare (printf ">=%s" .version) $version -}}
{{- end -}}

{{/*
Platform capabilities, derived from the preset.

hostPath is what separates the presets: GKE Autopilot and EKS Fargate reject it,
which is why they collect pod logs through the Kubernetes API instead. But only
SOME of the node collector needs hostPath — filelog needs /var/log/pods and
hostmetrics needs /proc and /sys, while kubeletstats and the cAdvisor scrape
just talk to the kubelet over the network. Modelling the capability instead of
the log mode is what lets those clusters keep their node metrics.
Usage: {{- if eq (include "kubernetes-agent.hostPathAvailable" .) "true" }}
*/}}
{{- define "kubernetes-agent.hostPathAvailable" -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "gke-autopilot") (eq $preset "eks-fargate") -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Whether a DaemonSet can run at all. EKS Fargate schedules each pod onto its own
micro-VM and has no notion of a node you can place one pod per — DaemonSets are
silently never scheduled there. Everywhere else, including Autopilot, they run.
*/}}
{{- define "kubernetes-agent.daemonSetSchedulable" -}}
{{- if eq (default "" .Values.preset) "eks-fargate" -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Whether the platform runs a privileged pod. The eBPF instrumentation (OBI) and
the continuous profiler each need one, with the host's PID namespace, to load
eBPF programs into the kernel. GKE Autopilot refuses privileged pods: its
admission rejects them, and the whole install with them. EKS Fargate runs
neither privileged containers nor DaemonSets, so the two would sit there never
scheduling. Like hostPath, this is decided by the preset.
Usage: {{- if eq (include "kubernetes-agent.privilegedPodsAllowed" .) "true" }}
*/}}
{{- define "kubernetes-agent.privilegedPodsAllowed" -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "gke-autopilot") (eq $preset "eks-fargate") -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Whether the eBPF instrumentation runs: ebpf.enabled, on a platform that runs
its privileged DaemonSet. Every template reads ebpf.enabled through this - the
DaemonSet, its ConfigMap, the collector's OTLP Service, ports, receiver and
traces pipeline, the trace filters and sampler, the log enricher's parsing and
the notes - so a preset that turns it off leaves no half of it behind. An
explicit ebpf.enabled=false is still honoured everywhere.
Usage: {{- if eq (include "kubernetes-agent.ebpfEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.ebpfEnabled" -}}
{{- if and ((.Values.ebpf | default dict).enabled) (eq (include "kubernetes-agent.privilegedPodsAllowed" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the continuous profiler runs: profiling.enabled, on a platform that
runs its privileged DaemonSet (see privilegedPodsAllowed). The profiler's
DaemonSet, its ConfigMap, the eBPF DaemonSet's trace-context switch and the
notes read profiling.enabled through this.
Usage: {{- if eq (include "kubernetes-agent.profilingEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.profilingEnabled" -}}
{{- if and ((.Values.profiling | default dict).enabled) (eq (include "kubernetes-agent.privilegedPodsAllowed" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Does the node collector DaemonSet need to exist?

It carries two independent jobs, and either one is reason enough to run it:
  - pod logs, when logs are on AND the resolved mode is daemonset, and
  - node metrics: kubeletstats (no off switch), the cAdvisor scrape, hostmetrics.

These used to share one gate keyed on logs alone, so `logs.enabled=false` — or
any preset that resolved the log mode to `api` — silently took every node, pod
and container metric with it, along with the OOM-kill, CPU-throttling and
PVC-low-disk monitors.
*/}}
{{- define "kubernetes-agent.daemonSetLogsEnabled" -}}
{{- if and .Values.logs.enabled (eq (include "kubernetes-agent.logMode" .) "daemonset") (eq (include "kubernetes-agent.hostPathAvailable" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Node metrics are wanted whenever a DaemonSet can run and at least one node-local
metric source is on. kubeletstats has no enable flag — it is the core node / pod
/ container metric source — so this is true unless the platform cannot schedule
a DaemonSet.
*/}}
{{- define "kubernetes-agent.daemonSetMetricsEnabled" -}}
{{- if eq (include "kubernetes-agent.daemonSetSchedulable" .) "true" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- define "kubernetes-agent.daemonSetEnabled" -}}
{{- if and (eq (include "kubernetes-agent.daemonSetSchedulable" .) "true") (or (eq (include "kubernetes-agent.daemonSetLogsEnabled" .) "true") (eq (include "kubernetes-agent.daemonSetMetricsEnabled" .) "true")) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
hostmetrics reads the host's /proc and /sys through hostPath, so it needs both
the flag and a platform that allows the mount.
*/}}
{{- define "kubernetes-agent.hostMetricsEnabled" -}}
{{- if and .Values.hostMetrics.enabled (eq (include "kubernetes-agent.hostPathAvailable" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Telemetry filters — the OTTL conditions behind the `filter/telemetry` processor.

The filter processor DROPS a record when a condition matches, and its
conditions are OR'ed together. Every helper below is written from that
angle: an allowlist is expressed as `not (<matches>)`, a denylist as
`<matches>` directly. Because they OR, listing an include condition and
an exclude condition together yields "drop unless included, and also drop
if excluded" — i.e. exclude wins, which is the precedence documented by
`namespaceFilters.rules`.

Every namespace condition is guarded with `!= nil`. Node- and
cluster-level series carry no namespace at all, and in OTTL
`nil != "production"` is TRUE — so an unguarded allowlist would silently
delete every node metric. The guard also decides the tie-break for
records we cannot classify: they are KEPT, never dropped.

Metric name matching is written for the pinned otel-collector-contrib
(.Values.image.tag, 0.161.0) and for 0.96.0, which a --reuse-values upgrade
keeps: `IsMatch`, the `metric` / `datapoint` OTTL contexts and paths with no
context prefix (`name`, not `metric.name`) exist in both. Keep it that way.
*/}}

{{/*
OTTL disjunction over metric names: `name == "a" or IsMatch(name, "b")`.
%q emits a Go-quoted string, so a regexp written as `^system\.cpu` in
values.yaml reaches RE2 as `\.` (a literal dot) rather than an invalid
OTTL escape.
Args: dict "names" (list) "matchType" ("strict" | "regexp")
*/}}
{{- define "kubernetes-agent.metricNameDisjunction" -}}
{{- $matchType := .matchType | default "strict" -}}
{{- $parts := list -}}
{{- range .names -}}
{{- if eq $matchType "regexp" -}}
{{- $parts = append $parts (printf "IsMatch(name, %q)" .) -}}
{{- else -}}
{{- $parts = append $parts (printf "name == %q" .) -}}
{{- end -}}
{{- end -}}
{{- join " or " $parts -}}
{{- end -}}

{{/*
Collect and de-duplicate namespace patterns for one action/scope pair.
Args: dict "root" $ "action" ("include" | "exclude")
           "scope" ("podLogs" | "ebpfDiscovery" | "metrics" | "traces")
*/}}
{{- define "kubernetes-agent.namespaceRulePatterns" -}}
{{- $root := .root -}}
{{- $action := .action -}}
{{- $scope := .scope -}}
{{- $patterns := list -}}
{{- range (($root.Values.namespaceFilters).rules) | default list -}}
{{- if and (eq (.action | default "") $action) (has $scope (.scopes | default list)) -}}
{{- $patterns = concat $patterns (.namespaces | default list | compact) -}}
{{- end -}}
{{- end -}}
{{- toJson (uniq $patterns) -}}
{{- end -}}

{{/*
OTTL disjunction over namespace patterns at a given path. Namespace patterns
match the full value and use `*` as their only wildcard. Splitting on `*`,
quoting each literal segment, then joining with `.*` gives the collector the
same semantics as filelog, OBI discovery and the API log tailer.
Args: dict "patterns" (list) "path" (OTTL path expression)
*/}}
{{- define "kubernetes-agent.namespacePatternDisjunction" -}}
{{- $path := .path -}}
{{- $parts := list -}}
{{- range .patterns -}}
{{- $segments := list -}}
{{- range (splitList "*" .) -}}
{{- $segments = append $segments (regexQuoteMeta .) -}}
{{- end -}}
{{- $pattern := printf "^(?:%s)$" (join ".*" $segments) -}}
{{- $parts = append $parts (printf "IsMatch(%s, %q)" $path $pattern) -}}
{{- end -}}
{{- join " or " $parts -}}
{{- end -}}

{{/*
Log-record conditions. Severity only — pod logs are already scoped by
namespace at the receiver (filelog path globs / the API tailer), so
re-filtering them here would cost CPU to drop nothing.
*/}}
{{- define "kubernetes-agent.filterLogConditions" -}}
{{- $sev := (((.Values.filters).logs).minSeverity) | default "" -}}
{{- $conds := list -}}
{{- if $sev -}}
{{- $conds = append $conds (printf "severity_number != SEVERITY_NUMBER_UNSPECIFIED and severity_number < SEVERITY_NUMBER_%s" (upper $sev)) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Metric-context conditions: metric-name allow/deny, plus namespace for
receivers that put the namespace on the RESOURCE (kubeletstats,
k8s_cluster).
*/}}
{{- define "kubernetes-agent.filterMetricConditions" -}}
{{- $fm := (.Values.filters).metrics | default dict -}}
{{- $mt := $fm.matchType | default "strict" -}}
{{- $inc := $fm.include | default list | compact -}}
{{- $exc := $fm.exclude | default list | compact -}}
{{- $nsInc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "metrics") | fromJsonArray -}}
{{- $nsExc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "metrics") | fromJsonArray -}}
{{- $conds := list -}}
{{- if $inc -}}
{{- $conds = append $conds (printf "not (%s)" (include "kubernetes-agent.metricNameDisjunction" (dict "names" $inc "matchType" $mt))) -}}
{{- end -}}
{{- if $exc -}}
{{- $conds = append $conds (include "kubernetes-agent.metricNameDisjunction" (dict "names" $exc "matchType" $mt)) -}}
{{- end -}}
{{- $p := "resource.attributes[\"k8s.namespace.name\"]" -}}
{{- if $nsExc -}}
{{- $conds = append $conds (printf "%s != nil and (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsExc "path" $p))) -}}
{{- end -}}
{{- if $nsInc -}}
{{- $conds = append $conds (printf "%s != nil and not (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsInc "path" $p))) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Datapoint-context conditions: namespace only, for Prometheus-scraped
metrics (cAdvisor, kube-state-metrics, CoreDNS, mesh, CSI). Those arrive
under a single scrape-target resource with the namespace as a DATAPOINT
label, so the metric-context conditions above never see them — this is
why namespace filtering needs both contexts to actually cover the cluster.
*/}}
{{- define "kubernetes-agent.filterDatapointConditions" -}}
{{- $nsInc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "metrics") | fromJsonArray -}}
{{- $nsExc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "metrics") | fromJsonArray -}}
{{- $conds := list -}}
{{- $p := "attributes[\"namespace\"]" -}}
{{- if $nsExc -}}
{{- $conds = append $conds (printf "%s != nil and (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsExc "path" $p))) -}}
{{- end -}}
{{- if $nsInc -}}
{{- $conds = append $conds (printf "%s != nil and not (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsInc "path" $p))) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Span-context namespace conditions. These run after metadata enrichment and can
filter both eBPF and application-pushed OTLP spans independently of whether OBI
still instruments the namespace.
*/}}
{{- define "kubernetes-agent.filterSpanConditions" -}}
{{- $nsInc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "traces") | fromJsonArray -}}
{{- $nsExc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "traces") | fromJsonArray -}}
{{- $conds := list -}}
{{- $p := "resource.attributes[\"k8s.namespace.name\"]" -}}
{{- if $nsExc -}}
{{- $conds = append $conds (printf "%s != nil and (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsExc "path" $p))) -}}
{{- end -}}
{{- if $nsInc -}}
{{- $conds = append $conds (printf "%s != nil and not (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsInc "path" $p))) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Per-signal predicates. A pipeline must only reference `filter/telemetry`
when that signal actually has conditions: the filter processor rejects a
config where it is wired into a pipeline whose signal it has no rules for.
Usage: {{- if eq (include "kubernetes-agent.logFiltersEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.logFiltersEnabled" -}}
{{- gt (len (include "kubernetes-agent.filterLogConditions" . | fromJsonArray)) 0 -}}
{{- end -}}

{{- define "kubernetes-agent.metricFiltersEnabled" -}}
{{- or (gt (len (include "kubernetes-agent.filterMetricConditions" . | fromJsonArray)) 0) (gt (len (include "kubernetes-agent.filterDatapointConditions" . | fromJsonArray)) 0) -}}
{{- end -}}

{{- define "kubernetes-agent.traceFiltersEnabled" -}}
{{- gt (len (include "kubernetes-agent.filterSpanConditions" . | fromJsonArray)) 0 -}}
{{- end -}}

{{/*
The `filter/telemetry` processor block itself. Emitted only for the
signals that have conditions AND that the calling collector actually runs
a pipeline for — the DaemonSet has no traces pipeline, so emitting span
rules there would be config that can never fire.
Single-quoted YAML keeps OTTL's own double quotes literal; internal single
quotes are doubled per the YAML spec.
Args: dict "root" $ "signals" (list "logs" "metrics" "traces")
*/}}
{{- define "kubernetes-agent.filterProcessor" -}}
{{- $root := .root -}}
{{- $signals := .signals -}}
{{- $logConds := list -}}
{{- if has "logs" $signals -}}
{{- $logConds = include "kubernetes-agent.filterLogConditions" $root | fromJsonArray -}}
{{- end -}}
{{- $metricConds := list -}}
{{- $dpConds := list -}}
{{- if has "metrics" $signals -}}
{{- $metricConds = include "kubernetes-agent.filterMetricConditions" $root | fromJsonArray -}}
{{- $dpConds = include "kubernetes-agent.filterDatapointConditions" $root | fromJsonArray -}}
{{- end -}}
{{- $spanConds := list -}}
{{- if has "traces" $signals -}}
{{- $spanConds = include "kubernetes-agent.filterSpanConditions" $root | fromJsonArray -}}
{{- end -}}
filter/telemetry:
  # Drops records matching any condition below, before `batch` — so
  # filtered telemetry costs no egress and never reaches OneUptime.
  # Generated from .Values.filters and .Values.namespaceFilters.
  error_mode: ignore
{{- if $logConds }}
  logs:
    log_record:
{{- range $logConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- if or $metricConds $dpConds }}
  metrics:
{{- if $metricConds }}
    metric:
{{- range $metricConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- if $dpConds }}
    datapoint:
{{- range $dpConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- end }}
{{- if $spanConds }}
  traces:
    span:
{{- range $spanConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- end -}}

{{/*
Trace sampling. Reads .Values.sampling.traces.

These deliberately test for nil with `kindIs "invalid"` rather than piping
through `default`: 0 is empty to Go templates, so `percentage | default 100`
would silently rewrite an explicit `percentage: 0` ("keep no traces") into
100 ("keep every trace") — the exact opposite of what was asked for, on the
one setting where being wrong is unrecoverable. Same for `hashSeed: 0`.
*/}}
{{- define "kubernetes-agent.traceSamplingPercentage" -}}
{{- $pct := (((.Values.sampling).traces).percentage) -}}
{{- if kindIs "invalid" $pct -}}
100
{{- else -}}
{{- $pct -}}
{{- end -}}
{{- end -}}

{{- define "kubernetes-agent.traceSamplingHashSeed" -}}
{{- $seed := (((.Values.sampling).traces).hashSeed) -}}
{{- if kindIs "invalid" $seed -}}
22
{{- else -}}
{{- $seed -}}
{{- end -}}
{{- end -}}

{{/*
Whether to emit `probabilistic_sampler` at all.

At 100 the sampler is a no-op, so we leave it out entirely and render the
same config as an install that has never heard of sampling. Gated on
ebpf.enabled too: the traces pipeline only exists there, and a processor
configured but referenced by no pipeline is config the collector can never
run — the same reason `filter/telemetry` is gated this way.
Usage: {{- if eq (include "kubernetes-agent.traceSamplingEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.traceSamplingEnabled" -}}
{{- $pct := float64 (include "kubernetes-agent.traceSamplingPercentage" .) -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (lt $pct 100.0) -}}
{{- end -}}

{{/*
Whether the chart bundles its own cost engine (OpenCost + a minimal
Prometheus). Bundling is the default when cost is enabled; providing
`cost.engine.url` means "use my existing OpenCost / Kubecost" and turns
the bundle off. Usage:
  {{- if eq (include "kubernetes-agent.costEngineBundled" .) "true" }}
*/}}
{{- define "kubernetes-agent.costEngineBundled" -}}
{{- and .Values.cost.enabled (not .Values.cost.engine.url) -}}
{{- end -}}

{{/*
Resolved base URL of the cost engine the poller and the metrics scrape
talk to: the operator-provided external engine when `cost.engine.url` is
set, else the bundled OpenCost Service.
*/}}
{{- define "kubernetes-agent.costEngineUrl" -}}
{{- if .Values.cost.engine.url -}}
{{- .Values.cost.engine.url -}}
{{- else -}}
http://{{ include "kubernetes-agent.fullname" . }}-opencost.{{ .Release.Namespace }}.svc.cluster.local:9003
{{- end -}}
{{- end -}}

{{/*
Resolved Prometheus URL for the cost pipeline, or EMPTY when there is none.

The cost agent reads per-container memory PEAKS from here. The Allocation
API only reports averages over the window, and an hourly mean hides the
burst that OOMKills a container — so a memory right-sizing recommendation
built on the average is actively dangerous. CPU needs no such help
(overshoot throttles rather than kills), which is why this is optional.

Empty is a legitimate, supported answer: an install pointing at an external
cost engine gets no bundled Prometheus, and the agent treats an empty value
as "ship allocations without peaks". Never default this to the bundled
Service name unconditionally — on an external-engine install that name
resolves to nothing and every poll would fail against it.
*/}}
{{- define "kubernetes-agent.costPrometheusUrl" -}}
{{- if .Values.cost.engine.prometheusUrl -}}
{{- .Values.cost.engine.prometheusUrl -}}
{{- else if eq (include "kubernetes-agent.costEngineBundled" .) "true" -}}
http://{{ include "kubernetes-agent.fullname" . }}-cost-prometheus.{{ .Release.Namespace }}.svc.cluster.local:9090
{{- end -}}
{{- end -}}

{{/*
Split a metrics URL into the three things a Prometheus scrape job takes it
as: `scheme`, a bare `host:port` target, and `metrics_path`.

A static target has to be a bare host:port. The prometheus receiver rejects
one with a "/" in it ("... is not a valid hostname"), and it does so while
LOADING the config, so the collector never starts: a stray trailing slash on
one endpoint takes every cluster metric and Kubernetes event down with it.
So the URL cannot be written into `targets` as it is. And cutting it down to
host:port without carrying the rest over scrapes somewhere other than where
the URL points: plain HTTP for an https:// endpoint, /metrics for any other
path.

What a scrape job has no place for is refused here, while the chart renders,
instead of being dropped or left in the target:
  - Credentials (user:password@). In a target they authenticate nothing, the
    scrape never succeeds, and the receiver exports the target, password and
    all, as the `instance` of the job's `up` series.
  - A query string or a fragment, which would be requested as part of the
    path.
  - A "%" in the path, which the receiver encodes a second time, and a "$",
    which the collector expands as a variable.
  - An empty URL or a scheme other than http(s). Either renders a job that
    starts and scrapes nothing.
The error names the setting and never repeats the URL, since the URL may be
what carries the password.

Takes a dict: `url`, and `setting`, the values key the URL came from.
Returns JSON: {"scheme": "http"|"https", "target": "<host:port>", "path": "<path>"}.
`path` is EMPTY when the URL's path is the receiver's default (/metrics, or
no path at all), so a caller writes `metrics_path` only when it has to and an
ordinary http://host:port/metrics endpoint renders the job it always did.
Repeated slashes and a trailing slash are dropped from the path.

Usage:
  {{- $endpoint := include "kubernetes-agent.scrapeEndpoint" (dict "url" $url "setting" "kubeStateMetrics.endpoint") | fromJson }}
*/}}
{{- define "kubernetes-agent.scrapeEndpoint" -}}
{{- $url := .url | default "" | toString | trim -}}
{{- $form := "Write it as http://host:port/path or https://host:port/path (the port and the path are optional)." -}}
{{- $scheme := ternary "https" "http" (regexMatch "(?i)^https://" $url) -}}
{{- $rest := regexReplaceAll "(?i)^https?://" $url "" -}}
{{- /* After the empty URL, in order: another scheme (tcp://, or http://
       written twice); http:/ with one slash, which would otherwise read as a
       host named "http"; anything that is not host[:port] followed by a path
       of plain characters. The host part takes ":" so an unbracketed IPv6
       address and an empty port still pass: the receiver dials both. And a
       scheme is taken to have no dot in it, so a dotted host name with an
       empty port in front of a doubled slash is not mistaken for one. */}}
{{- if not $url -}}
{{- fail (printf "%s is empty, and it is the URL to scrape. %s" .setting $form) -}}
{{- else if or (regexMatch "^[A-Za-z][A-Za-z0-9+-]*://" $rest) (regexMatch "(?i)^https?:(/|$)" $rest) (not (regexMatch `^[\pL\pN._:\[\]%-]+(/[\pL\pN._~!*'()+,;=:@&/-]*)?$` $rest)) -}}
{{- fail (printf "%s is not a URL the agent can scrape. %s Credentials (user:password@), a query string, a fragment, and a %% or $ in the path have no place in a scrape job, so they are refused rather than dropped." .setting $form) -}}
{{- end -}}
{{- $target := regexFind "^[^/]*" $rest -}}
{{- $path := regexReplaceAll "/+" (trimPrefix $target $rest) "/" | trimSuffix "/" -}}
{{- if eq $path "/metrics" -}}
{{- $path = "" -}}
{{- end -}}
{{- toJson (dict "scheme" $scheme "target" $target "path" $path) -}}
{{- end -}}
