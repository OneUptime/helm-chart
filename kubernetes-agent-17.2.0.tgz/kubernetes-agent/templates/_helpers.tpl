{{/*
Expand the name of the chart.
*/}}
{{- define "kubernetes-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
The cluster name, refusing to render if it is missing.

This is not merely a label. OneUptime folds `k8s.cluster.name` into the identity
of every Kubernetes entity it derives, so it is the only thing separating this
cluster's `worker-1` and `default` namespace from every other cluster's. Ship
without it and two clusters reporting into one project silently become one
estate -- nodes, namespaces, pods and deployments merged pairwise by name, with
no error anywhere to say so.

`required` is deliberate: values.schema.json already lists clusterName in its
`required` set, but JSON Schema `required` only checks that the key is PRESENT,
and the chart's default value is the empty string, so it passes. Failing at
render is the only place this can be caught before the data is wrong.

Every template reads the name through this helper, never .Values.clusterName
itself, so each component gets the same name: without the whitespace around it
(a name read from a file keeps its final newline), and refused when missing. A
name with spaces around it once reached the log tailer and the cost agent
untrimmed while the collectors sent it trimmed, so one cluster arrived under
two names (#7336). Write it into YAML with `| quote` (inside printf when it is
part of a longer value), never inside literal quotes, where a '"' or '\' in
the name ends the string or starts an escape.
Tests/Ops/KubernetesAgentClusterName.test.js holds every template to it.
*/}}
{{- define "kubernetes-agent.clusterName" -}}
{{- required "clusterName is required: it identifies this cluster's nodes, namespaces, pods and deployments in OneUptime, and two clusters installed without it will be merged into one. Set it with --set clusterName=<name>." (.Values.clusterName | trim) -}}
{{- end }}

{{/*
The Secret the operator created for the ingestion key (oneuptime.existingSecretName),
or nothing when the chart keeps oneuptime.apiKey in a Secret of its own
(templates/secret.yaml, which renders only then).

Setting both is refused rather than resolved: a Secret of your own is there to
keep the key out of the release's values, and a key left in apiKey would stay
in every revision Helm stores.
*/}}
{{- define "kubernetes-agent.existingSecretName" -}}
{{- $oneuptime := .Values.oneuptime | default dict -}}
{{- $existing := toString ($oneuptime.existingSecretName | default "") | trim -}}
{{- if and $existing (toString ($oneuptime.apiKey | default "") | trim) -}}
{{- fail (printf "oneuptime.apiKey and oneuptime.existingSecretName are both set. Set one of them: to read the ingestion key from the Secret %s, clear apiKey (--set oneuptime.apiKey=\"\")." $existing) -}}
{{- end -}}
{{- $existing -}}
{{- end }}

{{/*
The Secret every workload reads the ingestion key from, under `api-key`.
Usage: secretKeyRef: { name: {{ include "kubernetes-agent.apiKeySecretName" . }}, key: api-key }
*/}}
{{- define "kubernetes-agent.apiKeySecretName" -}}
{{- include "kubernetes-agent.existingSecretName" . | default (include "kubernetes-agent.fullname" .) -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kubernetes-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubernetes-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels

managed-by is written out, as Helm itself would always fill it in ("Helm"):
Amazon EKS renders this chart as an add-on too (HelmChart/Marketplace), and
refuses a chart that reads any Release object but .Name and .Namespace.
*/}}
{{- define "kubernetes-agent.labels" -}}
helm.sh/chart: {{ include "kubernetes-agent.chart" . }}
{{ include "kubernetes-agent.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: Helm
app.kubernetes.io/part-of: oneuptime
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubernetes-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubernetes-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "kubernetes-agent.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- include "kubernetes-agent.fullname" . }}
{{- end }}
{{- end }}

{{/*
Whether the cluster is OpenShift: the openshift preset or the
openshift-restricted one. Either way user and group IDs are OpenShift's to
assign (kubernetes-agent.nonRootPodSecurityContext), and the agent says it is
on OpenShift: the distribution attribute, the openshift resource detector,
the k8sobjects/openshift receiver and the RBAC of those two.

What separates the two presets is whether the chart creates SCCs
(kubernetes-agent.openshiftSccs).
Usage: {{- if eq (include "kubernetes-agent.openshift" .) "true" }}
*/}}
{{- define "kubernetes-agent.openshift" -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "openshift") (eq $preset "openshift-restricted") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the chart creates security context constraints: on the openshift
preset, the recommended one, and not on openshift-restricted.

OpenShift admits a pod only under a security context constraint (SCC) that
its service account may use, and a service account may use restricted-v2
and nothing more until an admin grants it: no hostPath volumes, no privileged
containers, no host PID namespace, and user and group IDs from the
namespace's own range only. So on the openshift preset the chart creates an
SCC for each of the two kinds of node pods that need more
(templates/openshift-scc.yaml), runs them as service accounts of their own,
which alone may use it, and runs the node collector as root with the SELinux
type spc_t.
Usage: {{- if eq (include "kubernetes-agent.openshiftSccs" .) "true" }}
*/}}
{{- define "kubernetes-agent.openshiftSccs" -}}
{{- if eq (default "" .Values.preset) "openshift" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the release runs under restricted-v2 alone, for an admin who will not
add an SCC: the openshift-restricted preset. It works like gke-autopilot:
nothing reads the node's files (kubernetes-agent.hostPathAvailable), nothing
runs privileged (kubernetes-agent.privilegedPodsAllowed), and pod logs come
through the Kubernetes API (kubernetes-agent.logMode). The node collector
still runs, for the kubelet's metrics.

restricted-v2 would fill in what a pod leaves unset, and refuses what it gets
wrong. So here every pod states it: the pods that state nothing on any other
preset (the two collectors, and the debug sidecar) take
kubernetes-agent.nonRootPodSecurityContext and
kubernetes-agent.restrictedContainerSecurityContext.
Usage: {{- if eq (include "kubernetes-agent.openshiftRestricted" .) "true" }}
*/}}
{{- define "kubernetes-agent.openshiftRestricted" -}}
{{- if eq (default "" .Values.preset) "openshift-restricted" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
A container's securityContext that OpenShift's restricted-v2 SCC and the
restricted Pod Security Standard accept as written: no privilege escalation,
every capability dropped.
Usage:
  securityContext:
    {{- include "kubernetes-agent.restrictedContainerSecurityContext" . | nindent 12 }}
*/}}
{{- define "kubernetes-agent.restrictedContainerSecurityContext" -}}
allowPrivilegeEscalation: false
capabilities:
  drop:
    - ALL
{{- end -}}

{{/*
Whether the node pods run as service accounts of their own: when the chart
creates SCCs, so that each can be granted to exactly the pods that need it,
and only when the chart creates service accounts at all. With
serviceAccount.create=false every pod runs as the service account you made,
and both SCCs are granted to it.
*/}}
{{- define "kubernetes-agent.nodeServiceAccounts" -}}
{{- if and (eq (include "kubernetes-agent.openshiftSccs" .) "true") .Values.serviceAccount.create -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
The node collector DaemonSet's service account (templates/daemonset.yaml).
*/}}
{{- define "kubernetes-agent.nodeCollectorServiceAccountName" -}}
{{- if eq (include "kubernetes-agent.nodeServiceAccounts" .) "true" -}}
{{- printf "%s-node-collector" (include "kubernetes-agent.fullname" .) -}}
{{- else -}}
{{- include "kubernetes-agent.serviceAccountName" . -}}
{{- end -}}
{{- end -}}

{{/*
The service account of the eBPF instrumentation and the profiler
(templates/daemonset-ebpf.yaml, templates/daemonset-profiling.yaml).
*/}}
{{- define "kubernetes-agent.ebpfServiceAccountName" -}}
{{- if eq (include "kubernetes-agent.nodeServiceAccounts" .) "true" -}}
{{- printf "%s-ebpf" (include "kubernetes-agent.fullname" .) -}}
{{- else -}}
{{- include "kubernetes-agent.serviceAccountName" . -}}
{{- end -}}
{{- end -}}

{{/*
A node pod's own service account (templates/rbac.yaml), with the labels and
the annotations (serviceAccount.annotations) the main one has.
Usage: {{ include "kubernetes-agent.nodeServiceAccount" (dict "root" . "name" "<name>") }}
*/}}
{{- define "kubernetes-agent.nodeServiceAccount" -}}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .name }}
  namespace: {{ .root.Release.Namespace }}
  labels:
    {{- include "kubernetes-agent.labels" .root | nindent 4 }}
  {{- with .root.Values.serviceAccount.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end -}}

{{/*
The SELinux label the node collector runs with on the openshift preset, and
the one its SCC requires: the type spc_t, which RHCOS's enforcing SELinux
lets read the node's files, as the default container type (container_t)
cannot.
*/}}
{{- define "kubernetes-agent.spcSeLinuxOptions" -}}
user: system_u
role: system_r
type: spc_t
level: s0
{{- end -}}

{{/*
The pod securityContext of a workload that runs as a fixed non-root user:
non-root, the RuntimeDefault seccomp profile, and the user and group IDs its
image is built for. OpenShift refuses IDs outside the namespace's range and
assigns its own, so on the OpenShift presets the IDs are left out and the pod
runs under restricted-v2. Every such workload mounts a writable emptyDir
wherever it writes (its root filesystem is read-only), and an emptyDir is
writable by whatever fsGroup OpenShift gives the pod.
Usage:
  securityContext:
    {{- include "kubernetes-agent.nonRootPodSecurityContext" (dict "root" . "runAsUser" 1000 "runAsGroup" 1000 "fsGroup" 1000) | nindent 8 }}
*/}}
{{- define "kubernetes-agent.nonRootPodSecurityContext" -}}
runAsNonRoot: true
{{- if ne (include "kubernetes-agent.openshift" .root) "true" }}
{{- with .runAsUser }}
runAsUser: {{ . }}
{{- end }}
{{- with .runAsGroup }}
runAsGroup: {{ . }}
{{- end }}
{{- with .fsGroup }}
fsGroup: {{ . }}
{{- end }}
{{- end }}
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{/*
The resource attribute that names the cluster's Kubernetes distribution, for
the collectors' resource processors on the OpenShift presets, next to
oneuptime.agent.version: oneuptime.kubernetes.distribution=openshift. It
tells OneUptime an OpenShift cluster from any other on every platform,
on-premises included; the openshift detector below names only the cloud.
Usage: {{- include "kubernetes-agent.distributionAttribute" (dict "action" "insert") | nindent 10 }}
*/}}
{{- define "kubernetes-agent.distributionAttribute" -}}
- key: oneuptime.kubernetes.distribution
  value: openshift
  action: {{ .action }}
{{- end -}}

{{/*
The collector's openshift resource detector, for the OpenShift presets. It
reads the cloud the cluster runs on from the cluster's Infrastructure object
(config.openshift.io, which templates/rbac.yaml lets the agent read) and sets
cloud.provider and cloud.platform (aws_openshift, azure_openshift,
gcp_openshift, ibm_cloud_openshift); an on-premises cluster gets neither.
Two of its attributes stay off:
  - k8s.cluster.name, which it would set to the infrastructure name, while
    clusterName names the cluster in OneUptime (the resource processor);
  - cloud.region, which before collector 0.165 it sets to Azure's and
    OpenStack's cloud name, not a region.
override: false leaves an attribute a record already carries as it is. Each
pipeline runs it right after the resource processor.
Usage: {{- include "kubernetes-agent.openshiftDetector" . | nindent 6 }}
*/}}
{{/*
The label that says which DeploymentConfig a pod belongs to, for the
k8sattributes processors on the OpenShift presets. A DeploymentConfig's pods
are owned by the ReplicationController of its rollout, which k8sattributes
does not resolve to a workload as it does a Deployment's, so nothing else on
their telemetry names it. OpenShift sets this label on every one of them, and
the DeploymentConfig's Metrics tab filters on it.
Usage: {{- include "kubernetes-agent.deploymentConfigPodLabel" . | nindent 12 }}
*/}}
{{- define "kubernetes-agent.deploymentConfigPodLabel" -}}
- tag_name: k8s.pod.label.deploymentconfig
  key: deploymentconfig
  from: pod
{{- end -}}

{{/*
Whether the cluster collector pulls OpenShift's own objects - Routes,
DeploymentConfigs, ClusterOperators and the ClusterVersion - on the OpenShift
presets, with the other resource specs (resourceSpecs.enabled), for the
Kubernetes pages and the OpenShift alert templates.

They come from a k8sobjects receiver of their own with error_mode: ignore,
which collector 0.125.0 added. A cluster that does not serve one of them
(DeploymentConfigs are an optional capability since OpenShift 4.14) then
skips it, where a missing object would otherwise stop the receiver that sends
the events and every other spec. An older collector (a release upgraded with
--reuse-values keeps its image) leaves them out until it is upgraded.
Usage: {{- if eq (include "kubernetes-agent.openshiftObjectsEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.openshiftObjectsEnabled" -}}
{{- if and (eq (include "kubernetes-agent.openshift" .) "true") .Values.resourceSpecs.enabled (eq (include "kubernetes-agent.collectorAtLeast" (dict "root" . "version" "0.125.0")) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the cluster collector pulls what the CIS Kubernetes Benchmark's policy
controls read, for the cluster's Compliance page: RBAC (Roles, ClusterRoles
and their bindings), ServiceAccounts and NetworkPolicies, read-only, with the
other resource specs (resourceSpecs.enabled). On unless
resourceSpecs.compliance is false: a release upgraded with --reuse-values
keeps the values of the chart it came from, which have no such key, and gets
them too. The Pod Security Standards need none of it: they are scored from
the pods the collector already pulls.

They come from a k8sobjects receiver of their own with error_mode: ignore,
which collector 0.125.0 added, so a cluster that refuses one of them (a
service account of your own, without the rules templates/rbac.yaml grants)
skips it instead of stopping the events and every other spec. An older
collector leaves them out until it is upgraded.
Usage: {{- if eq (include "kubernetes-agent.complianceObjectsEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.complianceObjectsEnabled" -}}
{{- $specs := .Values.resourceSpecs | default dict -}}
{{- if and $specs.enabled (or (not (hasKey $specs "compliance")) $specs.compliance) (eq (include "kubernetes-agent.collectorAtLeast" (dict "root" . "version" "0.125.0")) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
nodes/proxy, which the agent's ClusterRole grants only where nothing narrower
works (#9878). It reaches the whole kubelet API: a GET on it can run commands
in any container of the node, and CIS Kubernetes Benchmark 5.1.10 fails every
binding that grants it - as the cluster's Compliance page says. The kubelet
authorizes each of its paths as a subresource of nodes: /stats/* as
nodes/stats, /metrics/* (cAdvisor's included) as nodes/metrics, /pods as
nodes/pods from Kubernetes 1.33 (KubeletFineGrainedAuthz: beta and on by
default from 1.33, GA from 1.36), and the rest as nodes/proxy.

A setting below is true, false or auto, in any spelling; missing or empty is
auto, which is what a release upgraded with --reuse-values from an older
chart has.
Usage: {{ include "kubernetes-agent.nodesProxySetting" (dict "value" .Values.kubeletstats.nodesProxy "setting" "kubeletstats.nodesProxy" "auto" "...") }}
*/}}
{{- define "kubernetes-agent.nodesProxySetting" -}}
{{- $value := .value -}}
{{- if or (kindIs "invalid" $value) (eq (toString $value | trim) "") -}}
auto
{{- else if has (toString $value | trim | lower) (list "auto" "true" "false") -}}
{{- toString $value | trim | lower -}}
{{- else -}}
{{- fail (printf "%s is %q. Set it to true, false or auto (the default: %s)." .setting (toString $value) .auto) -}}
{{- end -}}
{{- end -}}

{{/*
Whether the ClusterRole grants nodes/proxy for the node collector's kubelet
pod list. kubeletstats reads each node's /pods - each container's ID, each
volume's claim, and the requests and limits its utilization metrics divide
by - and sends nothing from a node whose kubelet refuses it. A kubelet from
1.33 on lets it read the list with nodes/pods, which the ClusterRole always
grants; an older one asks for nodes/proxy.

kubeletstats.nodesProxy: true or false as set. auto grants it while the
Kubernetes version the chart is rendered for is older than 1.36: a kubelet may
be up to three minor versions older than the API server, so only from 1.36
is every kubelet 1.33 or later. Helm reads that version from the cluster on
install and upgrade, Amazon EKS renders the add-on with the cluster's
(--kube-version), and Argo CD and Flux pass it too; a bare `helm template`
assumes its own default. Never without the node collector: the eks-fargate
preset runs none.
Usage: {{- if eq (include "kubernetes-agent.kubeletPodsThroughNodesProxy" .) "true" }}
*/}}
{{- define "kubernetes-agent.kubeletPodsThroughNodesProxy" -}}
{{- $setting := include "kubernetes-agent.nodesProxySetting" (dict "value" (.Values.kubeletstats | default dict).nodesProxy "setting" "kubeletstats.nodesProxy" "auto" "granted while the cluster runs Kubernetes older than 1.36") -}}
{{- if ne (include "kubernetes-agent.daemonSetMetricsEnabled" .) "true" -}}
false
{{- else if eq $setting "auto" -}}
{{- ternary "false" "true" (semverCompare ">=1.36-0" .Capabilities.KubeVersion.Version) -}}
{{- else -}}
{{- $setting -}}
{{- end -}}
{{- end -}}

{{/*
Whether the bundled cost Prometheus reads each node's cAdvisor through the API
server's node proxy (/api/v1/nodes/<node>/proxy/metrics/cadvisor), which needs
nodes/proxy, rather than from the node's own kubelet
(https://<node address>:10250/metrics/cadvisor), which needs only
nodes/metrics - as the node collector's own cAdvisor scrape does.

cost.prometheus.nodesProxy: true or false as set. auto is true only on the
eks-fargate preset: Fargate lets no pod reach a node's kubelet, so there the
API server is the only way to cAdvisor. Never while the chart bundles no
Prometheus (cost off, or an engine of the cluster's own).
Usage: {{- if eq (include "kubernetes-agent.costPrometheusThroughNodesProxy" .) "true" }}
*/}}
{{- define "kubernetes-agent.costPrometheusThroughNodesProxy" -}}
{{- $setting := include "kubernetes-agent.nodesProxySetting" (dict "value" (((.Values.cost | default dict).prometheus) | default dict).nodesProxy "setting" "cost.prometheus.nodesProxy" "auto" "through the API server on the eks-fargate preset only") -}}
{{- if ne (include "kubernetes-agent.costEngineBundled" .) "true" -}}
false
{{- else if eq $setting "auto" -}}
{{- ternary "true" "false" (eq (default "" .Values.preset) "eks-fargate") -}}
{{- else -}}
{{- $setting -}}
{{- end -}}
{{- end -}}

{{/*
Why the ClusterRole grants nodes/proxy, as the value of its
oneuptime.com/nodes-proxy label: kubelet-pods, cost-prometheus, both joined
by a dot, or nothing when it grants none. The cluster's Compliance page reads
the label to say why the agent's own binding fails CIS Kubernetes Benchmark
5.1.10, and how to drop it (KubernetesRbac's NODES_PROXY_REASON_LABEL).
Usage: {{- with include "kubernetes-agent.nodesProxyReasons" . }}
*/}}
{{- define "kubernetes-agent.nodesProxyReasons" -}}
{{- $reasons := list -}}
{{- if eq (include "kubernetes-agent.kubeletPodsThroughNodesProxy" .) "true" -}}
{{- $reasons = append $reasons "kubelet-pods" -}}
{{- end -}}
{{- if eq (include "kubernetes-agent.costPrometheusThroughNodesProxy" .) "true" -}}
{{- $reasons = append $reasons "cost-prometheus" -}}
{{- end -}}
{{- join "." $reasons -}}
{{- end -}}

{{- define "kubernetes-agent.openshiftDetector" -}}
{{ include "kubernetes-agent.componentType" (dict "root" . "type" "resource_detection") }}/openshift:
  detectors: [openshift]
  override: false
  openshift:
    resource_attributes:
      k8s.cluster.name:
        enabled: false
      cloud.region:
        enabled: false
{{- end -}}

{{/*
Pod nodeSelector with the Linux-only pin merged in.

Every image this chart deploys — the OTel collectors, OBI, the profiler,
OpenCost, Prometheus, kube-state-metrics, the cost and log agents — is built
for linux only. On mixed-OS clusters (e.g. AKS with Windows node pools) an
unpinned pod spec can be scheduled onto a Windows node, where the image pull
can never succeed and the pod sits in ImagePullBackOff forever; the
DaemonSets are guaranteed to hit this because they tolerate every taint.
The kubelet labels every node with kubernetes.io/os (stable since
Kubernetes 1.14), so requiring "linux" is always safe.

Takes the workload's user-configured nodeSelector map (or an empty dict when
the workload has no such knob). User-supplied keys win on conflict.

Usage (the include is nindent-ed under the `nodeSelector:` key):
  nodeSelector:
    {{`{{- include "kubernetes-agent.nodeSelector" .Values.ebpf.nodeSelector | nindent 8 }}`}}
*/}}
{{- define "kubernetes-agent.nodeSelector" -}}
{{- /* mergeOverwrite, not merge: sprig merge won't let a zero value ("")
     in the user map displace the pin, breaking last-writer-wins. The
     dest dict is a fresh literal, so .Values is never mutated. */ -}}
{{- toYaml (mergeOverwrite (dict "kubernetes.io/os" "linux") (. | default dict)) -}}
{{- end }}

{{/*
Build the OTEL_EBPF_METRICS_FEATURES env var value from .Values.ebpf.features
toggles. Returns a comma-separated string of the OBI feature names that are
currently enabled. (An empty string does NOT mean "no metrics": OBI falls back
to its default, `application`.) Current OBI (since v0.11) refuses to start on a token it does
not know, so every token here must exist in the pinned version.
*/}}
{{- define "kubernetes-agent.ebpfMetricsFeatures" -}}
{{- $features := list -}}
{{- if .Values.ebpf.features.httpMetrics -}}{{- $features = append $features "application" -}}{{- end -}}
{{- /* `application_span_otel`, not OBI's deprecated `application_span`: the
     same spans, attributes and buckets, named traces.span.metrics.calls and
     traces.span.metrics.duration (seconds) instead of
     traces_spanmetrics_calls_total and traces_spanmetrics_latency. Every OBI
     release has it, so it needs no version gate; OBI warns about the old name
     since v0.12.2, and refuses the two together. */ -}}
{{- if .Values.ebpf.features.spanMetrics -}}{{- $features = append $features "application_span_otel" -}}{{- end -}}
{{- if .Values.ebpf.features.serviceGraph -}}{{- $features = append $features "application_service_graph" -}}{{- end -}}
{{- /* ebpf.features.hostMetrics is ignored on purpose: its `application_host`
     feature is gone in OBI v0.14, and an unknown token stops OBI starting. */ -}}
{{- if .Values.ebpf.features.networkMetrics -}}{{- $features = append $features "network" -}}{{- end -}}
{{- if .Values.ebpf.features.networkInterZoneMetrics -}}{{- $features = append $features "network_inter_zone" -}}{{- end -}}
{{- /* Not `stats`: in current OBI that also turns on stats_tcp_io, a probe on
     every TCP send and receive — far more events than the three
     close/failure/retransmit counters tcpStats describes. */ -}}
{{- if .Values.ebpf.features.tcpStats -}}{{- $features = concat $features (list "stats_tcp_rtt" "stats_tcp_failed_connections" "stats_tcp_retransmits") -}}{{- end -}}
{{- join "," $features -}}
{{- end }}

{{/*
Split a comma-separated glob list (ebpf.autoTargetExe, ebpf.excludeExePaths)
into a JSON array: entries trimmed, blanks and duplicates dropped, order kept.

OBI compiles each `exe_path` selector as ONE gobwas glob, in which a comma is
a literal character, so the sh and bash globs handed over joined by a comma
match no executable at all. Each entry has to become its own selector.
(No glob examples in this comment: a star followed by a slash would end it.)
Usage: {{ include "kubernetes-agent.globList" .Values.ebpf.excludeExePaths | fromJsonArray }}
*/}}
{{- define "kubernetes-agent.globList" -}}
{{- /* Split on commas outside braces only: a brace alternative such as
     python-or-java inside one pattern is one glob to OBI (and was one entry
     when the whole string went to OTEL_EBPF_AUTO_TARGET_EXE), so cutting it
     at its comma would leave two broken halves that match far less. */ -}}
{{- $out := list -}}
{{- $current := "" -}}
{{- $depth := 0 -}}
{{- range (splitList "" ((. | default "") | toString)) -}}
{{- if and (eq . ",") (eq (int $depth) 0) -}}
{{- $glob := trim $current -}}
{{- if and $glob (not (has $glob $out)) -}}
{{- $out = append $out $glob -}}
{{- end -}}
{{- $current = "" -}}
{{- else -}}
{{- if eq . "{" -}}
{{- $depth = add1 $depth -}}
{{- else if and (eq . "}") (gt (int $depth) 0) -}}
{{- $depth = sub $depth 1 -}}
{{- end -}}
{{- $current = printf "%s%s" $current . -}}
{{- end -}}
{{- end -}}
{{- $glob := trim $current -}}
{{- if and $glob (not (has $glob $out)) -}}
{{- $out = append $out $glob -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}

{{/*
The OBI configuration file (templates/configmap-ebpf.yaml, mounted at
/etc/obi/obi-config.yaml and named by OTEL_EBPF_CONFIG_PATH).

Process selection lives here because OBI has no environment variable for it:
the chart used to set OTEL_EBPF_EXCLUDE_AUTO_TARGET_EXE,
OTEL_EBPF_DISCOVERY_NAMESPACE and OTEL_EBPF_DISCOVERY_EXCLUDE_NAMESPACE, none
of which any OBI release reads, so excludeExePaths and the ebpfDiscovery
namespace rules silently did nothing.

  discovery.instrument — one selector per autoTargetExe glob, each also
    requiring a Kubernetes namespace: `k8s_namespace: "*"`, or with namespace
    include rules one selector per (glob, namespace) pair. The namespace
    requirement keeps node daemons (kubelet, containerd, sshd — processes with
    no pod) out, which OBI v0.10+ otherwise matches, and holds back a pod's
    process until OBI knows its pod, so a namespace exclusion cannot be
    skipped by a process seen before its pod metadata arrived.
    OTEL_EBPF_AUTO_TARGET_EXE must NOT be set alongside: OBI ORs it in as one
    more selector, which would widen discovery back to every namespace.
  discovery.exclude_instrument — one selector per excludeExePaths glob and
    per excluded namespace. OBI still appends its built-in exclusions (itself,
    OTel collectors, the system namespaces) after these.
  discovery.disabled_route_harvesters, discovery.route_harvester_timeout —
    from ebpf.routes.disabledHarvesters and ebpf.routes.harvestTimeout: the
    languages OBI does not harvest route templates for (Node.js by default),
    and how long it waits for one process's. Blank languages are dropped, and
    neither key is written when unset or empty, so OBI's defaults (every
    language, 10s) apply.
  attributes.select.traces.include — the span attributes OBI exports; see
    kubernetes-agent.obiSpanAttributes.

OBI decodes this file on top of its defaults, so anything not written here
keeps OBI's default.
*/}}
{{- define "kubernetes-agent.obiConfig" -}}
{{- $targets := include "kubernetes-agent.globList" .Values.ebpf.autoTargetExe | fromJsonArray -}}
{{- if not $targets -}}
{{- /* An empty selector is a config error that stops OBI from starting. */ -}}
{{- $targets = list "*" -}}
{{- end -}}
{{- $excludes := include "kubernetes-agent.globList" .Values.ebpf.excludeExePaths | fromJsonArray -}}
{{- $nsInclude := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "ebpfDiscovery") | fromJsonArray -}}
{{- $nsExclude := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "ebpfDiscovery") | fromJsonArray -}}
{{- $routes := .Values.ebpf.routes | default dict -}}
discovery:
  instrument:
{{- if $nsInclude }}
{{- range $ns := $nsInclude }}
{{- range $exe := $targets }}
    - exe_path: {{ $exe | quote }}
      k8s_namespace: {{ $ns | quote }}
{{- end }}
{{- end }}
{{- else }}
{{- range $exe := $targets }}
    - exe_path: {{ $exe | quote }}
      k8s_namespace: "*"
{{- end }}
{{- end }}
{{- if or $excludes $nsExclude }}
  exclude_instrument:
{{- range $excludes }}
    - exe_path: {{ . | quote }}
{{- end }}
{{- range $nsExclude }}
    - k8s_namespace: {{ . | quote }}
{{- end }}
{{- end }}
{{- /* Blanks dropped: `--set ebpf.routes.disabledHarvesters={}` gives [""]. */}}
{{- $harvestersOff := list }}
{{- range ($routes.disabledHarvesters | default list) }}
{{- if . }}
{{- $harvestersOff = append $harvestersOff . }}
{{- end }}
{{- end }}
{{- with $harvestersOff }}
  disabled_route_harvesters:
{{- range . }}
    - {{ . | quote }}
{{- end }}
{{- end }}
{{- with $routes.harvestTimeout }}
  route_harvester_timeout: {{ . | quote }}
{{- end }}
{{- if or $routes.patterns $routes.unmatched }}
routes:
{{- with $routes.unmatched }}
  unmatched: {{ . | quote }}
{{- end }}
{{- with $routes.patterns }}
  patterns:
{{- range . }}
    - {{ . | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- $selectSpanAttributes := eq (include "kubernetes-agent.obiSelectsSpanAttributes" .) "true" }}
{{- $serviceNameLabels := include "kubernetes-agent.serviceNameLabels" . | fromJsonArray }}
{{- if $selectSpanAttributes }}
# Span attributes. A list here replaces OBI's default set rather than adding
# to it, so it repeats those defaults; service.peer.name is opt-in since v0.14.
{{- end }}
{{- if or $selectSpanAttributes $serviceNameLabels }}
attributes:
{{- end }}
{{- if $selectSpanAttributes }}
  select:
    traces:
      include:
{{- range (include "kubernetes-agent.obiSpanAttributes" . | fromJsonArray) }}
        - {{ . | quote }}
{{- end }}
{{- end }}
{{- if $serviceNameLabels }}
  # The pod labels a service is named after, first one set wins
  # (ebpf.serviceNameLabels). OBI keeps its own lists for service.namespace
  # and service.version.
  kubernetes:
    resource_labels:
      service.name:
{{- range $serviceNameLabels }}
        - {{ . | quote }}
{{- end }}
{{- end }}
{{- if .Values.ebpf.logToTraceCorrelation }}
# The log enricher's process selector has no env var equivalent either.
ebpf:
  log_enricher:
    services:
{{ toYaml .Values.ebpf.logEnricher.services | indent 6 }}
{{- if eq (include "kubernetes-agent.logEnricherPlainText" .) "true" }}
    # Plain-text lines too (ebpf.logEnricher.plainText): OBI appends
    # " trace_id=… span_id=…" to every line of a non-JSON write, and the node
    # collector lifts it into the record's trace context and strips it from
    # the body. The line in the container's log file keeps it.
    plain_text:
      enabled: true
      placement: suffix
      multiline: each_line
{{- else }}
    # JSON lines only, as documented on ebpf.logToTraceCorrelation. Since
    # v0.11 OBI also appends " trace_id=… span_id=…" to plain-text lines by
    # default, which changes every non-JSON log line the app writes; the node
    # collector parses it only with ebpf.logEnricher.plainText.
    plain_text:
      enabled: false
{{- end }}
{{- end }}
{{- end }}

{{/*
The span attributes OBI is told to export (attributes.select.traces.include in
the OBI config file), as a JSON array: OBI's nine default span attributes,
then service.peer.name, then ebpf.extraSpanAttributes, trimmed, with blanks,
repeats and a bare "*" dropped.

service.peer.name: OBI v0.14 made it opt-in, together with the HTTP body
sizes and obi.http.response.observed (OBI #3559). OneUptime's service map
names the service a client call went to from it (ServiceDependencyDiscovery);
without it those calls fall back to server.address, which re-keys the remote
services the map already shows and so duplicates their nodes.

Why the defaults are repeated: a non-empty include list REPLACES OBI's
default set instead of adding to it (AttrSelector.For in
pkg/export/attributes/attr_selector.go falls back to the defaults only when
the include list is empty). Asking for service.peer.name alone would drop
error.type, network.peer.address and the rest. The nine are the `true`
entries of Traces.Section in pkg/export/attributes/attr_defs.go of the pinned
OBI; re-check them whenever ebpf.image.tag moves. The list is v0.14's, so it
is only rendered for v0.14 and later (kubernetes-agent.obiSelectsSpanAttributes):
an older OBI has other defaults (v0.9 kept url.query off, so the list would
start exporting query strings) and sends service.peer.name anyway.

Why "*" is refused: OBI matches each entry as a glob, and a bare star opts in
to every optional span attribute, among them db.query.text (the full SQL or
Redis command, with whatever literal values it carries) and the gen_ai
prompt, completion and system-instruction payloads. Those stay opt-in by
name.
*/}}
{{- define "kubernetes-agent.obiSpanAttributes" -}}
{{- /* See the comment above. */ -}}
{{- $attrs := list "dns.question.name" "url.query" "error.type" "http.request.method_original" "db.query.summary" "user_agent.original" "network.peer.address" "network.peer.port" "network.protocol.version" "service.peer.name" -}}
{{- range (.Values.ebpf.extraSpanAttributes | default list) -}}
{{- $name := trim (toString .) -}}
{{- if and $name (ne $name "*") (not (has $name $attrs)) -}}
{{- $attrs = append $attrs $name -}}
{{- end -}}
{{- end -}}
{{- toJson $attrs -}}
{{- end }}

{{/*
ebpf.serviceNameLabels as a JSON array of pod label keys, trimmed, with
blanks and repeats dropped. Empty (the default, or a values file without the
key) leaves OBI's own order, written as attributes.kubernetes.resource_labels
only when there is something to write. OBI decodes resource_labels onto its
defaults key by key (pkg/kube/store.go DefaultResourceLabels), so setting
service.name keeps its service.namespace and service.version lists.
*/}}
{{- define "kubernetes-agent.serviceNameLabels" -}}
{{- $labels := list -}}
{{- range (.Values.ebpf.serviceNameLabels | default list) -}}
{{- $label := trim (toString .) -}}
{{- if and $label (not (has $label $labels)) -}}
{{- $labels = append $labels $label -}}
{{- end -}}
{{- end -}}
{{- toJson $labels -}}
{{- end }}

{{/*
Whether OBI's log enricher annotates plain-text lines too, and the node
collector parses that annotation (ebpf.logEnricher.plainText): only with
ebpf.logToTraceCorrelation on, and only when explicitly true — it changes the
line every non-JSON write leaves in the container's log file.
*/}}
{{- define "kubernetes-agent.logEnricherPlainText" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") .Values.ebpf.logToTraceCorrelation (eq (toString ((.Values.ebpf.logEnricher | default dict).plainText)) "true") -}}
{{- end }}

{{/*
Base OTTL span condition for `filter/ebpf-unlinked-db`: an eBPF (OBI) span
with a database system. See ebpf.dropDatabaseServerSpans and
ebpf.dropUnlinkedDatabaseCalls.

  - telemetry.distro.name scopes it to OBI. The receiver also takes spans
    that applications push from their own SDKs, and those are none of this
    filter's business.
  - db.system.name is the current semantic-convention key and what OBI
    emits; db.system is the older one, kept so an OBI that still emits it is
    covered too.
  - The calls condition adds parent_span_id == SpanID(0x0000000000000000),
    "no parent" in a form both the pinned collector (0.165.0) and 0.96.0,
    which a --reuse-values upgrade keeps, understand; IsRootSpan() is newer
    than 0.96.0.
*/}}
{{/*
Whether to drop each kind of unlinked eBPF database span in
`filter/ebpf-unlinked-db` (ebpf.dropDatabaseServerSpans,
ebpf.dropUnlinkedDatabaseCalls). Only with eBPF on (the traces pipeline exists
only then), and on unless explicitly set to false: an upgrade with
--reuse-values keeps the old release's values, which do not have these keys,
and a default-on fix should not silently stay off for those clusters.
Usage: {{- if eq (include "kubernetes-agent.ebpfDatabaseFilterEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.dropDatabaseServerSpans" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString .Values.ebpf.dropDatabaseServerSpans) "false") -}}
{{- end -}}

{{- define "kubernetes-agent.dropUnlinkedDatabaseCalls" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString .Values.ebpf.dropUnlinkedDatabaseCalls) "false") -}}
{{- end -}}

{{/*
Database proxies (ebpf.databaseProxyNames, ebpf.dropDatabaseProxySpans).

A proxy or connection pooler (PgBouncer, ProxySQL, mongos, ...) is both a
database server and a database client: OBI records a SERVER span for each
command an application sends it and a CLIENT span, hung under that server
span, for the command it passes on. dropDatabaseServerSpans drops the server
span, so without this every passed-on command reaches OneUptime pointing at a
parent that was never sent — a one-span trace marked "1 span missing a
parent". On the test cluster that was three quarters of all one-span traces.

kubernetes-agent.defaultDatabaseProxyNames is the list a values file without
ebpf.databaseProxyNames gets (a release upgraded with --reuse-values); keep it
equal to values.yaml.
*/}}
{{- define "kubernetes-agent.defaultDatabaseProxyNames" -}}
{{- toJson (list "pgbouncer" "pgcat" "pgdog" "odyssey" "pgpool" "supavisor" "connection-pooler" "proxysql" "maxscale" "mysqlrouter" "mysql-router" "vtgate" "mongos" "twemproxy" "nutcracker" "predixy") -}}
{{- end -}}

{{/*
ebpf.databaseProxyNames as a JSON array: trimmed, blanks and repeats dropped.
A missing key (nil) gets the default list; an explicit [] turns proxy
detection off.
*/}}
{{- define "kubernetes-agent.databaseProxyNames" -}}
{{- $raw := .Values.ebpf.databaseProxyNames -}}
{{- if kindIs "invalid" $raw -}}
{{- $raw = include "kubernetes-agent.defaultDatabaseProxyNames" . | fromJsonArray -}}
{{- end -}}
{{- $names := list -}}
{{- range $raw -}}
{{- $name := trim (toString .) -}}
{{- if and $name (not (has $name $names)) -}}
{{- $names = append $names $name -}}
{{- end -}}
{{- end -}}
{{- toJson $names -}}
{{- end -}}

{{/*
The OTTL condition that a span comes from a database proxy, or "" with no
names: the container, the service name OBI gives the process, or its
Deployment / StatefulSet / DaemonSet name contains one of the names as a word,
case-insensitively — "pgbouncer" matches `oneuptime-pgbouncer` and
`pgbouncer-0`, not `mypgbouncer`. OBI sets all of these on its resource.
Each attribute is checked for nil before IsMatch, so a span without one
(a process OBI saw outside a Deployment) is still judged on the others.
A name is regex-quoted, then its backslashes and quotes are escaped once more
for the OTTL string literal, which reads `\\` as one backslash.
*/}}
{{- define "kubernetes-agent.databaseProxyCondition" -}}
{{- $names := include "kubernetes-agent.databaseProxyNames" . | fromJsonArray -}}
{{- if $names -}}
{{- $quoted := list -}}
{{- range $names -}}
{{- $quoted = append $quoted (regexQuoteMeta . | replace "\\" "\\\\" | replace "\"" "\\\"") -}}
{{- end -}}
{{- $pattern := printf "(?i)(^|[^a-z0-9])(%s)([^a-z0-9]|$)" (join "|" $quoted) -}}
{{- $checks := list -}}
{{- range (list "k8s.container.name" "service.name" "k8s.deployment.name" "k8s.statefulset.name" "k8s.daemonset.name") -}}
{{- $checks = append $checks (printf "(resource.attributes[\"%s\"] != nil and IsMatch(resource.attributes[\"%s\"], \"%s\"))" . . $pattern) -}}
{{- end -}}
{{- printf "(%s)" (join " or " $checks) -}}
{{- end -}}
{{- end -}}

{{/*
Whether to drop every eBPF database span of a database proxy
(ebpf.dropDatabaseProxySpans): with eBPF on, names to match, and on unless
explicitly false, for the same --reuse-values reason as the switches above.
*/}}
{{- define "kubernetes-agent.dropDatabaseProxySpans" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString .Values.ebpf.dropDatabaseProxySpans) "false") (ne (include "kubernetes-agent.databaseProxyCondition" .) "") -}}
{{- end -}}

{{- define "kubernetes-agent.ebpfDatabaseFilterEnabled" -}}
{{- or (eq (include "kubernetes-agent.dropDatabaseServerSpans" .) "true") (eq (include "kubernetes-agent.dropUnlinkedDatabaseCalls" .) "true") (eq (include "kubernetes-agent.dropDatabaseProxySpans" .) "true") -}}
{{- end -}}

{{/*
The OTTL span conditions of `filter/ebpf-unlinked-db`, as a JSON array: one
per enabled switch, all on the base below.

  - server (ebpf.dropDatabaseServerSpans): `kind == SPAN_KIND_SERVER`, with
    or without a parent. It is the span OBI records inside the database
    server, and it duplicates the caller's client span either way: unlinked
    it is a one-span trace, and linked (OBI links the two ends of a
    connection when the caller runs on the same node) it doubles every
    database call in the request trace. Keeping the linked ones would also
    leave them pointing at a missing parent whenever the calls switch drops
    the client span they hang from. With ebpf.dropDatabaseProxySpans off, a
    proxy's server spans are exempt (`not` the proxy condition): they are
    the parents of the commands it passes on, which are kept.
  - calls (ebpf.dropUnlinkedDatabaseCalls): `kind != SPAN_KIND_SERVER` and no
    parent — the application's own call, outside any trace.
  - proxies (ebpf.dropDatabaseProxySpans): every database span of a
    database proxy, server and client alike, so none is left pointing at a
    dropped parent.
*/}}
{{- define "kubernetes-agent.ebpfUnlinkedDatabaseSpanConditions" -}}
{{- $base := include "kubernetes-agent.ebpfDatabaseSpanCondition" . -}}
{{- $proxy := include "kubernetes-agent.databaseProxyCondition" . -}}
{{- $dropProxies := eq (include "kubernetes-agent.dropDatabaseProxySpans" .) "true" -}}
{{- $conds := list -}}
{{- if eq (include "kubernetes-agent.dropDatabaseServerSpans" .) "true" -}}
{{- if and $proxy (not $dropProxies) -}}
{{- $conds = append $conds (printf "%s and kind == SPAN_KIND_SERVER and not %s" $base $proxy) -}}
{{- else -}}
{{- $conds = append $conds (printf "%s and kind == SPAN_KIND_SERVER" $base) -}}
{{- end -}}
{{- end -}}
{{- if eq (include "kubernetes-agent.dropUnlinkedDatabaseCalls" .) "true" -}}
{{- $conds = append $conds (printf "%s and parent_span_id == SpanID(0x0000000000000000) and kind != SPAN_KIND_SERVER" $base) -}}
{{- end -}}
{{- if $dropProxies -}}
{{- $conds = append $conds (printf "%s and %s" $base $proxy) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{- define "kubernetes-agent.ebpfDatabaseSpanCondition" -}}
resource.attributes["telemetry.distro.name"] == "opentelemetry-ebpf-instrumentation" and (attributes["db.system.name"] != nil or attributes["db.system"] != nil)
{{- end }}

{{/*
Whether to drop OBI's other client calls that belong to no trace in
`filter/ebpf-unlinked-client` (ebpf.dropUnlinkedClientCalls). Only with eBPF
on, and OFF unless explicitly set to true — the opposite of the database
switches above. A stateless filter cannot tell a one-span call from the root
of a trace: when the callee is traced by OBI on the same node (on any node
with ebpf.contextPropagation, which also hands the call's context to a callee
running its own OpenTelemetry SDK), its request hangs under the call, and
dropping the call leaves that trace without its root (see the value for what
else it costs). So a release upgraded with --reuse-values, whose values
predate the key, keeps every span as before.
*/}}
{{- define "kubernetes-agent.dropUnlinkedClientCalls" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (eq (toString .Values.ebpf.dropUnlinkedClientCalls) "true") -}}
{{- end -}}

{{/*
OTTL span condition of `filter/ebpf-unlinked-client`: an OBI CLIENT span with
no parent that is none of the calls other features read from spans.

  - telemetry.distro.name and the "no parent" form as for the database
    condition above (parent_span_id == SpanID(0x0000000000000000) is what
    both the pinned collector, 0.165.0, and 0.96.0 understand).
  - kind == SPAN_KIND_CLIENT only: PRODUCER and CONSUMER spans are messaging
    and always kept, as are SERVER spans (a request is a trace's root) and
    INTERNAL ones.
  - Database calls (db.system.name / db.system) are left to
    filter/ebpf-unlinked-db, so the two filters never match the same span and
    ebpf.dropUnlinkedDatabaseCalls=false keeps them whatever this switch says.
  - Messaging calls (messaging.system): OBI v0.14 types a receive or settle
    as CLIENT, and OneUptime's queue discovery reads every messaging span
    that is not SERVER.
  - GenAI calls (gen_ai.operation.name, which OBI v0.14 sets on every call
    to a model provider; gen_ai.system for an OBI on the older semantic
    conventions): OneUptime's LLM cost and token figures come from these
    spans, and it turns to the GenAI metrics only when there are none at
    all, so dropping a batch job's calls would under-count them, not hand
    them to the metrics.
  - MCP calls (mcp.method.name, on every MCP span OBI v0.14 records): it sets
    gen_ai.operation.name only on tools/call, yet a prompts/get still carries
    gen_ai.prompt.name, and OneUptime counts any span with a gen_ai.* key as
    an LLM span.
*/}}
{{- define "kubernetes-agent.ebpfUnlinkedClientSpanCondition" -}}
resource.attributes["telemetry.distro.name"] == "opentelemetry-ebpf-instrumentation" and kind == SPAN_KIND_CLIENT and parent_span_id == SpanID(0x0000000000000000) and attributes["db.system.name"] == nil and attributes["db.system"] == nil and attributes["messaging.system"] == nil and attributes["gen_ai.operation.name"] == nil and attributes["gen_ai.system"] == nil and attributes["mcp.method.name"] == nil
{{- end }}

{{/*
Whether to drop OBI's HTTP server metrics for its own Node.js inspector
requests in `filter/ebpf-node-inspector` (ebpf.dropNodeInspectorMetrics).
Only with eBPF on (OBI is what sends them) and its Node.js agent on (with
ebpf.nodejs.enabled=false OBI never injects, so the filter could only drop an
app's own datapoints), and on unless explicitly set to false, for the same
--reuse-values reason as the database switches above.
*/}}
{{- define "kubernetes-agent.dropNodeInspectorMetrics" -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (ne (toString ((.Values.ebpf.nodejs | default dict).enabled)) "false") (ne (toString .Values.ebpf.dropNodeInspectorMetrics) "false") -}}
{{- end -}}

{{/*
OTTL datapoint condition of `filter/ebpf-node-inspector`. OBI v0.14 injects
its Node.js agent through the app's inspector after it has started tracing
the process, so its own GET /json/list (GET /json/version too, when the
inspector was already open) and the WebSocket upgrade that follows, on
127.0.0.1:9229, count in the app's http.server.* metrics under the routes
/json/list, /json/version and /* (answered 101).

  - telemetry.distro.name scopes it to OBI: the receiver also takes what
    applications push from their own SDKs.
  - A datapoint has no client address, so this cannot tell OBI's requests
    from anyone else's on port 9229: an app's own GET /json/list or
    /json/version there, and its own WebSocket upgrades there that OBI names
    /* (no route template), lose their datapoints too. OneUptime drops the
    matching spans on ingest, where the client address is known.
  - http.route, not url.path: OBI's metrics carry only the route. These are
    the names OBI gives those requests with the default route naming
    (ebpf.routes.unmatched heuristic); with another ebpf.routes.unmatched,
    or an ebpf.routes.patterns entry that matches them, some or all of the
    injection's datapoints are kept.
  - Only http.server.*. OBI's span metrics (ebpf.features.spanMetrics) carry
    neither the port nor the HTTP status, only the span name, so they still
    count a GET /json/list call per injection (and a GET /json/version for
    an app started with --inspect) and add the upgrade to the app's GET /*.
    Dropping span.name "GET /json/list" would also drop a real DevTools
    endpoint's (a headless Chrome or browserless service), so they are left
    alone.
*/}}
{{- define "kubernetes-agent.ebpfNodeInspectorMetricCondition" -}}
resource.attributes["telemetry.distro.name"] == "opentelemetry-ebpf-instrumentation" and IsMatch(metric.name, "^http\\.server\\.") and attributes["server.port"] == 9229 and attributes["http.request.method"] == "GET" and (attributes["http.route"] == "/json/list" or attributes["http.route"] == "/json/version" or (attributes["http.route"] == "/*" and attributes["http.response.status_code"] == 101))
{{- end }}

{{/*
Whether the pinned OBI takes the span-attribute list in
kubernetes-agent.obiSpanAttributes: v0.14 or later, or a tag that is not a
version at all (a branch build or a digest), which is assumed current.
*/}}
{{- define "kubernetes-agent.obiSelectsSpanAttributes" -}}
{{- $tag := toString ((.Values.ebpf.image | default dict).tag) -}}
{{- $version := regexFind "^v?[0-9]+\\.[0-9]+\\.[0-9]+" $tag -}}
{{- if $version -}}
{{- semverCompare ">=0.14.0-0" $version -}}
{{- else -}}
true
{{- end -}}
{{- end }}

{{/*
Render .Values.oneuptime.labels as OTel resource-processor attribute entries.

The OneUptime ingest pipeline promotes any resource attribute prefixed with
`oneuptime.label.` into a project Label of the form `<key>:<value>` and
attaches it to the cluster/service/host that emitted the record — see
Common/Server/Utils/Telemetry/OneuptimeLabel.ts.

Pass the action ("insert" or "upsert") so the caller can match the surrounding
processor's existing semantics:
  - "insert" — only set if the attribute is absent (use in pipelines that
    forward telemetry the in-cluster collector didn't originate, e.g. OBI
    traces passing through the metrics Deployment).
  - "upsert" — always set, overwriting any upstream value.

Usage:
  {{- include "kubernetes-agent.oneuptimeLabels" (dict "labels" .Values.oneuptime.labels "action" "insert") | nindent 10 }}
*/}}
{{- define "kubernetes-agent.oneuptimeLabels" -}}
{{- $action := .action | default "insert" -}}
{{- range $key, $value := .labels }}
- key: oneuptime.label.{{ $key }}
  value: {{ $value | quote }}
  action: {{ $action }}
{{- end }}
{{- end }}

{{/*
Parse a Kubernetes memory quantity into an integer number of mebibytes (MiB),
rounded down. Supports the binary (Ki/Mi/Gi/Ti) and decimal (k/K/M/G/T)
suffixes Kubernetes accepts, plus a plain byte count with no suffix. Arithmetic
goes through sprig's float helpers (mulf/divf coerce their string args to
float64), so fractional quantities like "1.5Gi" parse correctly.

  {{ include "kubernetes-agent.memToMib" "512Mi" }}  -> 512
  {{ include "kubernetes-agent.memToMib" "4Gi" }}    -> 4096
*/}}
{{- define "kubernetes-agent.memToMib" -}}
{{- $q := . | toString | trim -}}
{{- $mib := 0.0 -}}
{{- if hasSuffix "Gi" $q -}}
{{- $mib = mulf (trimSuffix "Gi" $q) 1024 -}}
{{- else if hasSuffix "Mi" $q -}}
{{- $mib = mulf (trimSuffix "Mi" $q) 1 -}}
{{- else if hasSuffix "Ki" $q -}}
{{- $mib = divf (trimSuffix "Ki" $q) 1024 -}}
{{- else if hasSuffix "Ti" $q -}}
{{- $mib = mulf (trimSuffix "Ti" $q) 1048576 -}}
{{- else if hasSuffix "G" $q -}}
{{- $mib = divf (mulf (trimSuffix "G" $q) 1000000000) 1048576 -}}
{{- else if hasSuffix "M" $q -}}
{{- $mib = divf (mulf (trimSuffix "M" $q) 1000000) 1048576 -}}
{{- else if hasSuffix "K" $q -}}
{{- $mib = divf (mulf (trimSuffix "K" $q) 1000) 1048576 -}}
{{- else if hasSuffix "k" $q -}}
{{- $mib = divf (mulf (trimSuffix "k" $q) 1000) 1048576 -}}
{{- else -}}
{{- $mib = divf $q 1048576 -}}
{{- end -}}
{{- $mib | floor | int -}}
{{- end }}

{{/*
limit_mib for the OTel memory_limiter: 80% of a container memory limit, in MiB.
Shared by the memory_limiter processor config and the GOMEMLIMIT env var so the
two are derived from the same number and can never drift from the cgroup limit.
Argument: the container memory limit quantity (e.g. "512Mi", "4Gi").
*/}}
{{- define "kubernetes-agent.memLimitMib" -}}
{{- mulf (include "kubernetes-agent.memToMib" .) 0.8 | floor | int -}}
{{- end }}

{{/*
Render the OTel `memory_limiter` processor body (check_interval / limit_mib /
spike_limit_mib) derived from a container memory limit, so limit_mib always
sits *below* the cgroup limit. If the limiter were set above the container
limit the kernel would OOMKill the pod before the limiter could shed load —
which is exactly the failure this avoids. Follows OTel guidance: limit_mib ≈
80% of the container limit, spike_limit_mib ≈ 20% of limit_mib.

Usage (the include is nindent-ed under the `memory_limiter:` key):
  memory_limiter:
    {{`{{- include "kubernetes-agent.memoryLimiter" "512Mi" | nindent 8 }}`}}
*/}}
{{- define "kubernetes-agent.memoryLimiter" -}}
{{- $hard := include "kubernetes-agent.memLimitMib" . | int -}}
check_interval: 5s
limit_mib: {{ $hard }}
spike_limit_mib: {{ mulf $hard 0.2 | floor | int }}
{{- end }}

{{/*
GOMEMLIMIT value (the Go runtime soft memory limit) for a collector container:
80% of the container memory limit, with the MiB suffix the Go runtime expects.
Matches the memory_limiter's limit_mib so the Go GC starts reclaiming at the
same threshold the limiter begins shedding load, keeping total RSS under the
cgroup limit. Argument: the container memory limit quantity.
*/}}
{{- define "kubernetes-agent.gomemlimit" -}}
{{- printf "%dMiB" (include "kubernetes-agent.memLimitMib" . | int) -}}
{{- end }}

{{/*
Debug sidecar container. Rendered into the metrics Deployment and logs
DaemonSet when .Values.debug.enabled is true.

The agent's collector images are distroless (built FROM scratch) — they ship
only the collector binary, so they have no /bin/sh, bash, or curl and cannot be
`kubectl exec`-ed into. This parks a shell + network-tooling container (default:
nicolaka/netshoot) next to the collector. Combined with the pod's shared
network namespace (every container in a pod shares one), a curl from here
follows the exact egress path — NetworkPolicy, DNS, proxy, TLS — the collector
uses. See values.yaml (debug.*) for the rationale and security trade-offs.

  kubectl exec -it <agent-pod> -c debug -- bash
  curl -v "$ONEUPTIME_URL/otlp/v1/metrics"

Usage (nindent to the `containers:` list-item column):
  {{- include "kubernetes-agent.debugContainer" . | nindent 8 }}
*/}}
{{- define "kubernetes-agent.debugContainer" -}}
- name: debug
  image: "{{ .Values.debug.image.repository }}:{{ .Values.debug.image.tag }}"
  imagePullPolicy: {{ .Values.debug.image.pullPolicy }}
  {{- with .Values.debug.command }}
  # netshoot's default entrypoint is an interactive shell, which exits
  # immediately (CrashLoop) in a pod with no TTY — so park it on a no-op.
  command:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if .Values.debug.securityContext }}
  securityContext:
    {{- toYaml .Values.debug.securityContext | nindent 4 }}
  {{- else if eq (include "kubernetes-agent.openshiftRestricted" .) "true" }}
  securityContext:
    {{- include "kubernetes-agent.restrictedContainerSecurityContext" . | nindent 4 }}
  {{- end }}
  resources:
    {{- toYaml .Values.debug.resources | nindent 4 }}
  {{- with .Values.oneuptime.url }}
  env:
    # Convenience for `curl "$ONEUPTIME_URL/otlp/v1/metrics"`.
    - name: ONEUPTIME_URL
      value: {{ . | quote }}
  {{- end }}
{{- end }}

{{/*
Effective log collection mode.

Resolution order:
  1. Explicit .Values.logs.mode ("daemonset" | "api" | "disabled") always wins.
  2. Otherwise .Values.preset decides:
       "gke-autopilot" / "eks-fargate" / "openshift-restricted" -> api
       "standard" / "" / unset                                  -> daemonset
  3. Anything else falls back to "daemonset".
*/}}
{{- define "kubernetes-agent.logMode" -}}
{{- $explicit := default "" .Values.logs.mode -}}
{{- if $explicit -}}
{{- $explicit -}}
{{- else -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "gke-autopilot") (eq $preset "eks-fargate") (eq $preset "openshift-restricted") -}}
api
{{- else -}}
daemonset
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Hybrid log collection for mixed-OS clusters. The DaemonSet collector is
pinned to Linux nodes (its images are linux-only), so in daemonset log mode
pods on Windows nodes have no log collection at all. When
`logs.windowsPods.enabled` is set, the API log tailer runs ALONGSIDE the
DaemonSet, restricted via NODE_OS_INCLUDE=windows to exactly the pods the
DaemonSet cannot reach — the two collectors partition pods by node OS, so no
log line ships twice. Only meaningful in daemonset mode: full api mode
already tails every pod, and disabled mode collects nothing.
Usage: {{- if eq (include "kubernetes-agent.windowsPodLogsEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.windowsPodLogsEnabled" -}}
{{- if and .Values.logs.enabled (((.Values.logs).windowsPods).enabled) (eq (include "kubernetes-agent.logMode" .) "daemonset") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the log-tailer Deployment exists at all — full api mode, or the
Windows-only hybrid above. The pods/log RBAC grant is keyed on this same
helper so the tailer and its permissions can never drift apart.
*/}}
{{- define "kubernetes-agent.logTailerEnabled" -}}
{{- if and .Values.logs.enabled (or (eq (include "kubernetes-agent.logMode" .) "api") (eq (include "kubernetes-agent.windowsPodLogsEnabled" .) "true")) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the collector the agent runs (image.tag) is at least a given version,
for the few config keys a release added: the collector refuses a config with
a key it does not know, and `helm upgrade --reuse-values` keeps the previous
release's image.tag (0.96.0 on a release from before 0.161.0, see
_stale-defaults.tpl), so a key newer than the image it renders for would stop
the agent. The version is read from the front of the tag (`0.161.0`,
`v0.161.0`, `0.161.0@sha256:...`); a tag that names no version (`latest`, a
mirror's own name) counts as this chart's default.
Usage: {{- if eq (include "kubernetes-agent.collectorAtLeast" (dict "root" . "version" "0.157.0")) "true" }}
*/}}
{{- define "kubernetes-agent.collectorAtLeast" -}}
{{- $tag := toString ((.root.Values.image | default dict).tag | default "") -}}
{{- $version := regexFind "^[0-9]+\\.[0-9]+\\.[0-9]+" (trimPrefix "v" $tag) | default (include "kubernetes-agent.defaultCollectorImageTag" .root) -}}
{{- semverCompare (printf ">=%s" .version) $version -}}
{{- end -}}

{{/*
The renamed collector components the chart's configs use (#9930): each type
as the collector now names it, with the type it went by before and the first
release that has the new one, read from the component's metadata.yaml at that
tag and the one before it:

  otlp_http            otlphttp            0.144.0
  k8s_attributes       k8sattributes       0.146.0
  file_log             filelog             0.149.0
  host_metrics         hostmetrics         0.151.0
  k8s_objects          k8sobjects          0.151.0
  kubelet_stats        kubeletstats        0.152.0
  resource_detection   resourcedetection   0.153.0
  cumulative_to_delta  cumulativetodelta   0.157.0

opentelemetry-collector-contrib, and the collector's own OTLP HTTP exporter,
renamed them to snake_case and kept every old type as a deprecated alias: the
collector warns `"kubeletstats" alias is deprecated; use "kubelet_stats"
instead` on every start, and a later release drops the alias, after which it
refuses the whole config ("unknown type"). A collector older than the rename
knows only the old type and refuses a config that names the new one, and
`helm upgrade --reuse-values` keeps 0.96.0 on a release from before 0.161.0
(_stale-defaults.tpl).
*/}}
{{- define "kubernetes-agent.renamedComponentTypes" -}}
{{- toJson (dict "otlp_http" (list "otlphttp" "0.144.0") "k8s_attributes" (list "k8sattributes" "0.146.0") "file_log" (list "filelog" "0.149.0") "host_metrics" (list "hostmetrics" "0.151.0") "k8s_objects" (list "k8sobjects" "0.151.0") "kubelet_stats" (list "kubeletstats" "0.152.0") "resource_detection" (list "resourcedetection" "0.153.0") "cumulative_to_delta" (list "cumulativetodelta" "0.157.0")) -}}
{{- end -}}

{{/*
The type a renamed component goes by on the collector this renders for
(image.tag): its new type from the release that has it, its old one before.
A component's id is its type and, after a slash, its own name
(file_log/audit): only the type changes.

What a rename does to an upgrade: the collector keys a component's stored
state by its id (a storage extension's file is named after the component's
type and name), so a renamed component would start over from nothing it
stored. Nothing the chart runs stores any: the file_log receivers keep their
offsets in memory (no storage extension), and every other renamed component
holds none. So an upgrade that renames them restarts the collectors as any
upgrade does, and resumes as any restart does.
Usage: {{ include "kubernetes-agent.componentType" (dict "root" . "type" "kubelet_stats") }}
*/}}
{{- define "kubernetes-agent.componentType" -}}
{{- $renamed := get (include "kubernetes-agent.renamedComponentTypes" . | fromJson) .type -}}
{{- if not $renamed -}}
{{- fail (printf "kubernetes-agent.componentType: %q is no renamed component type the chart knows" .type) -}}
{{- end -}}
{{- if eq (include "kubernetes-agent.collectorAtLeast" (dict "root" .root "version" (index $renamed 1))) "true" -}}
{{- .type -}}
{{- else -}}
{{- index $renamed 0 -}}
{{- end -}}
{{- end -}}

{{/*
Platform capabilities, derived from the preset.

hostPath is what separates the presets: GKE Autopilot and EKS Fargate reject it,
and OpenShift's restricted-v2 SCC does too, which is why they collect pod logs
through the Kubernetes API instead. But only SOME of the node collector needs
hostPath — filelog needs /var/log/pods and hostmetrics needs /proc and /sys,
while kubeletstats and the cAdvisor scrape just talk to the kubelet over the
network. Modelling the capability instead of the log mode is what lets those
clusters keep their node metrics.
Usage: {{- if eq (include "kubernetes-agent.hostPathAvailable" .) "true" }}
*/}}
{{- define "kubernetes-agent.hostPathAvailable" -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "gke-autopilot") (eq $preset "eks-fargate") (eq $preset "openshift-restricted") -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Whether a DaemonSet can run at all. EKS Fargate schedules each pod onto its own
micro-VM and has no notion of a node you can place one pod per — DaemonSets are
silently never scheduled there. Everywhere else, including Autopilot, they run.
*/}}
{{- define "kubernetes-agent.daemonSetSchedulable" -}}
{{- if eq (default "" .Values.preset) "eks-fargate" -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Whether the platform runs a privileged pod. The eBPF instrumentation (OBI) and
the continuous profiler each need one, with the host's PID namespace, to load
eBPF programs into the kernel. GKE Autopilot refuses privileged pods: its
admission rejects them, and the whole install with them. EKS Fargate runs
neither privileged containers nor DaemonSets, so the two would sit there never
scheduling, and OpenShift's restricted-v2 SCC refuses them, so they would never
be created. Like hostPath, this is decided by the preset.
Usage: {{- if eq (include "kubernetes-agent.privilegedPodsAllowed" .) "true" }}
*/}}
{{- define "kubernetes-agent.privilegedPodsAllowed" -}}
{{- $preset := default "" .Values.preset -}}
{{- if or (eq $preset "gke-autopilot") (eq $preset "eks-fargate") (eq $preset "openshift-restricted") -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Whether the eBPF instrumentation runs: ebpf.enabled, on a platform that runs
its privileged DaemonSet. Every template reads ebpf.enabled through this - the
DaemonSet, its ConfigMap, the collector's OTLP Service, ports, receiver and
traces pipeline, the trace filters and sampler, the log enricher's parsing and
the notes - so a preset that turns it off leaves no half of it behind. An
explicit ebpf.enabled=false is still honoured everywhere.
Usage: {{- if eq (include "kubernetes-agent.ebpfEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.ebpfEnabled" -}}
{{- if and ((.Values.ebpf | default dict).enabled) (eq (include "kubernetes-agent.privilegedPodsAllowed" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the continuous profiler runs: profiling.enabled, on a platform that
runs its privileged DaemonSet (see privilegedPodsAllowed). The profiler's
DaemonSet, its ConfigMap, the eBPF DaemonSet's trace-context switch and the
notes read profiling.enabled through this.
Usage: {{- if eq (include "kubernetes-agent.profilingEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.profilingEnabled" -}}
{{- if and ((.Values.profiling | default dict).enabled) (eq (include "kubernetes-agent.privilegedPodsAllowed" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether either privileged node pod runs: the eBPF instrumentation or the
profiler. They share a service account and, on OpenShift, an SCC.
Usage: {{- if eq (include "kubernetes-agent.ebpfPodsEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.ebpfPodsEnabled" -}}
{{- if or (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (eq (include "kubernetes-agent.profilingEnabled" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Does the node collector DaemonSet need to exist?

It carries two independent jobs, and either one is reason enough to run it:
  - pod logs, when logs are on AND the resolved mode is daemonset, and
  - node metrics: kubeletstats (no off switch), the cAdvisor scrape, hostmetrics.

These used to share one gate keyed on logs alone, so `logs.enabled=false` — or
any preset that resolved the log mode to `api` — silently took every node, pod
and container metric with it, along with the OOM-kill, CPU-throttling and
PVC-low-disk monitors.
*/}}
{{- define "kubernetes-agent.daemonSetLogsEnabled" -}}
{{- if and .Values.logs.enabled (eq (include "kubernetes-agent.logMode" .) "daemonset") (eq (include "kubernetes-agent.hostPathAvailable" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Node metrics are wanted whenever a DaemonSet can run and at least one node-local
metric source is on. kubeletstats has no enable flag — it is the core node / pod
/ container metric source — so this is true unless the platform cannot schedule
a DaemonSet.
*/}}
{{- define "kubernetes-agent.daemonSetMetricsEnabled" -}}
{{- if eq (include "kubernetes-agent.daemonSetSchedulable" .) "true" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{- define "kubernetes-agent.daemonSetEnabled" -}}
{{- if and (eq (include "kubernetes-agent.daemonSetSchedulable" .) "true") (or (eq (include "kubernetes-agent.daemonSetLogsEnabled" .) "true") (eq (include "kubernetes-agent.daemonSetMetricsEnabled" .) "true")) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
hostmetrics reads the host's /proc and /sys through hostPath, so it needs both
the flag and a platform that allows the mount.
*/}}
{{- define "kubernetes-agent.hostMetricsEnabled" -}}
{{- if and .Values.hostMetrics.enabled (eq (include "kubernetes-agent.hostPathAvailable" .) "true") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Telemetry filters — the OTTL conditions behind the `filter/telemetry` processor.

The filter processor DROPS a record when a condition matches, and its
conditions are OR'ed together. Every helper below is written from that
angle: an allowlist is expressed as `not (<matches>)`, a denylist as
`<matches>` directly. Because they OR, listing an include condition and
an exclude condition together yields "drop unless included, and also drop
if excluded" — i.e. exclude wins, which is the precedence documented by
`namespaceFilters.rules`.

Every namespace condition is guarded with `!= nil`. Node- and
cluster-level series carry no namespace at all, and in OTTL
`nil != "production"` is TRUE — so an unguarded allowlist would silently
delete every node metric. The guard also decides the tie-break for
records we cannot classify: they are KEPT, never dropped.

Metric name matching is written for the pinned otel-collector-contrib
(.Values.image.tag, 0.165.0) and for 0.96.0, which a --reuse-values upgrade
keeps: `IsMatch`, the `metric` / `datapoint` OTTL contexts and paths with no
context prefix (`name`, not `metric.name`) exist in both. Keep it that way.
*/}}

{{/*
OTTL disjunction over metric names: `name == "a" or IsMatch(name, "b")`.
%q emits a Go-quoted string, so a regexp written as `^system\.cpu` in
values.yaml reaches RE2 as `\.` (a literal dot) rather than an invalid
OTTL escape.
Args: dict "names" (list) "matchType" ("strict" | "regexp")
*/}}
{{- define "kubernetes-agent.metricNameDisjunction" -}}
{{- $matchType := .matchType | default "strict" -}}
{{- $parts := list -}}
{{- range .names -}}
{{- if eq $matchType "regexp" -}}
{{- $parts = append $parts (printf "IsMatch(name, %q)" .) -}}
{{- else -}}
{{- $parts = append $parts (printf "name == %q" .) -}}
{{- end -}}
{{- end -}}
{{- join " or " $parts -}}
{{- end -}}

{{/*
Collect and de-duplicate namespace patterns for one action/scope pair.
Args: dict "root" $ "action" ("include" | "exclude")
           "scope" ("podLogs" | "ebpfDiscovery" | "metrics" | "traces")
*/}}
{{- define "kubernetes-agent.namespaceRulePatterns" -}}
{{- $root := .root -}}
{{- $action := .action -}}
{{- $scope := .scope -}}
{{- $patterns := list -}}
{{- range (($root.Values.namespaceFilters).rules) | default list -}}
{{- if and (eq (.action | default "") $action) (has $scope (.scopes | default list)) -}}
{{- $patterns = concat $patterns (.namespaces | default list | compact) -}}
{{- end -}}
{{- end -}}
{{- toJson (uniq $patterns) -}}
{{- end -}}

{{/*
OTTL disjunction over namespace patterns at a given path. Namespace patterns
match the full value and use `*` as their only wildcard. Splitting on `*`,
quoting each literal segment, then joining with `.*` gives the collector the
same semantics as filelog, OBI discovery and the API log tailer.
Args: dict "patterns" (list) "path" (OTTL path expression)
*/}}
{{- define "kubernetes-agent.namespacePatternDisjunction" -}}
{{- $path := .path -}}
{{- $parts := list -}}
{{- range .patterns -}}
{{- $segments := list -}}
{{- range (splitList "*" .) -}}
{{- $segments = append $segments (regexQuoteMeta .) -}}
{{- end -}}
{{- $pattern := printf "^(?:%s)$" (join ".*" $segments) -}}
{{- $parts = append $parts (printf "IsMatch(%s, %q)" $path $pattern) -}}
{{- end -}}
{{- join " or " $parts -}}
{{- end -}}

{{/*
Log-record conditions. Severity only — pod logs are already scoped by
namespace at the receiver (filelog path globs / the API tailer), so
re-filtering them here would cost CPU to drop nothing.
*/}}
{{- define "kubernetes-agent.filterLogConditions" -}}
{{- $sev := (((.Values.filters).logs).minSeverity) | default "" -}}
{{- $conds := list -}}
{{- if $sev -}}
{{- $conds = append $conds (printf "severity_number != SEVERITY_NUMBER_UNSPECIFIED and severity_number < SEVERITY_NUMBER_%s" (upper $sev)) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Metric-context conditions: metric-name allow/deny, plus namespace for
receivers that put the namespace on the RESOURCE (kubeletstats,
k8s_cluster).
*/}}
{{- define "kubernetes-agent.filterMetricConditions" -}}
{{- $fm := (.Values.filters).metrics | default dict -}}
{{- $mt := $fm.matchType | default "strict" -}}
{{- $inc := $fm.include | default list | compact -}}
{{- $exc := $fm.exclude | default list | compact -}}
{{- $nsInc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "metrics") | fromJsonArray -}}
{{- $nsExc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "metrics") | fromJsonArray -}}
{{- $conds := list -}}
{{- if $inc -}}
{{- $conds = append $conds (printf "not (%s)" (include "kubernetes-agent.metricNameDisjunction" (dict "names" $inc "matchType" $mt))) -}}
{{- end -}}
{{- if $exc -}}
{{- $conds = append $conds (include "kubernetes-agent.metricNameDisjunction" (dict "names" $exc "matchType" $mt)) -}}
{{- end -}}
{{- $p := "resource.attributes[\"k8s.namespace.name\"]" -}}
{{- if $nsExc -}}
{{- $conds = append $conds (printf "%s != nil and (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsExc "path" $p))) -}}
{{- end -}}
{{- if $nsInc -}}
{{- $conds = append $conds (printf "%s != nil and not (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsInc "path" $p))) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Datapoint-context conditions: namespace only, for Prometheus-scraped
metrics (cAdvisor, kube-state-metrics, CoreDNS, mesh, CSI). Those arrive
under a single scrape-target resource with the namespace as a DATAPOINT
label, so the metric-context conditions above never see them — this is
why namespace filtering needs both contexts to actually cover the cluster.
*/}}
{{- define "kubernetes-agent.filterDatapointConditions" -}}
{{- $nsInc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "metrics") | fromJsonArray -}}
{{- $nsExc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "metrics") | fromJsonArray -}}
{{- $conds := list -}}
{{- $p := "attributes[\"namespace\"]" -}}
{{- if $nsExc -}}
{{- $conds = append $conds (printf "%s != nil and (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsExc "path" $p))) -}}
{{- end -}}
{{- if $nsInc -}}
{{- $conds = append $conds (printf "%s != nil and not (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsInc "path" $p))) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Span-context namespace conditions. These run after metadata enrichment and can
filter both eBPF and application-pushed OTLP spans independently of whether OBI
still instruments the namespace.
*/}}
{{- define "kubernetes-agent.filterSpanConditions" -}}
{{- $nsInc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "include" "scope" "traces") | fromJsonArray -}}
{{- $nsExc := include "kubernetes-agent.namespaceRulePatterns" (dict "root" . "action" "exclude" "scope" "traces") | fromJsonArray -}}
{{- $conds := list -}}
{{- $p := "resource.attributes[\"k8s.namespace.name\"]" -}}
{{- if $nsExc -}}
{{- $conds = append $conds (printf "%s != nil and (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsExc "path" $p))) -}}
{{- end -}}
{{- if $nsInc -}}
{{- $conds = append $conds (printf "%s != nil and not (%s)" $p (include "kubernetes-agent.namespacePatternDisjunction" (dict "patterns" $nsInc "path" $p))) -}}
{{- end -}}
{{- toJson $conds -}}
{{- end -}}

{{/*
Per-signal predicates. A pipeline must only reference `filter/telemetry`
when that signal actually has conditions: the filter processor rejects a
config where it is wired into a pipeline whose signal it has no rules for.
Usage: {{- if eq (include "kubernetes-agent.logFiltersEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.logFiltersEnabled" -}}
{{- gt (len (include "kubernetes-agent.filterLogConditions" . | fromJsonArray)) 0 -}}
{{- end -}}

{{- define "kubernetes-agent.metricFiltersEnabled" -}}
{{- or (gt (len (include "kubernetes-agent.filterMetricConditions" . | fromJsonArray)) 0) (gt (len (include "kubernetes-agent.filterDatapointConditions" . | fromJsonArray)) 0) -}}
{{- end -}}

{{- define "kubernetes-agent.traceFiltersEnabled" -}}
{{- gt (len (include "kubernetes-agent.filterSpanConditions" . | fromJsonArray)) 0 -}}
{{- end -}}

{{/*
The `filter/telemetry` processor block itself. Emitted only for the
signals that have conditions AND that the calling collector actually runs
a pipeline for — the DaemonSet has no traces pipeline, so emitting span
rules there would be config that can never fire.
Single-quoted YAML keeps OTTL's own double quotes literal; internal single
quotes are doubled per the YAML spec.
Args: dict "root" $ "signals" (list "logs" "metrics" "traces")
*/}}
{{- define "kubernetes-agent.filterProcessor" -}}
{{- $root := .root -}}
{{- $signals := .signals -}}
{{- $logConds := list -}}
{{- if has "logs" $signals -}}
{{- $logConds = include "kubernetes-agent.filterLogConditions" $root | fromJsonArray -}}
{{- end -}}
{{- $metricConds := list -}}
{{- $dpConds := list -}}
{{- if has "metrics" $signals -}}
{{- $metricConds = include "kubernetes-agent.filterMetricConditions" $root | fromJsonArray -}}
{{- $dpConds = include "kubernetes-agent.filterDatapointConditions" $root | fromJsonArray -}}
{{- end -}}
{{- $spanConds := list -}}
{{- if has "traces" $signals -}}
{{- $spanConds = include "kubernetes-agent.filterSpanConditions" $root | fromJsonArray -}}
{{- end -}}
filter/telemetry:
  # Drops records matching any condition below, before `batch` — so
  # filtered telemetry costs no egress and never reaches OneUptime.
  # Generated from .Values.filters and .Values.namespaceFilters.
  error_mode: ignore
{{- if $logConds }}
  logs:
    log_record:
{{- range $logConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- if or $metricConds $dpConds }}
  metrics:
{{- if $metricConds }}
    metric:
{{- range $metricConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- if $dpConds }}
    datapoint:
{{- range $dpConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- end }}
{{- if $spanConds }}
  traces:
    span:
{{- range $spanConds }}
      - '{{ . | replace "'" "''" }}'
{{- end }}
{{- end }}
{{- end -}}

{{/*
Trace sampling. Reads .Values.sampling.traces.

These deliberately test for nil with `kindIs "invalid"` rather than piping
through `default`: 0 is empty to Go templates, so `percentage | default 100`
would silently rewrite an explicit `percentage: 0` ("keep no traces") into
100 ("keep every trace") — the exact opposite of what was asked for, on the
one setting where being wrong is unrecoverable. Same for `hashSeed: 0`.
*/}}
{{- define "kubernetes-agent.traceSamplingPercentage" -}}
{{- $pct := (((.Values.sampling).traces).percentage) -}}
{{- if kindIs "invalid" $pct -}}
100
{{- else -}}
{{- $pct -}}
{{- end -}}
{{- end -}}

{{- define "kubernetes-agent.traceSamplingHashSeed" -}}
{{- $seed := (((.Values.sampling).traces).hashSeed) -}}
{{- if kindIs "invalid" $seed -}}
22
{{- else -}}
{{- $seed -}}
{{- end -}}
{{- end -}}

{{/*
Whether to emit `probabilistic_sampler` at all.

At 100 the sampler is a no-op, so we leave it out entirely and render the
same config as an install that has never heard of sampling. Gated on
ebpf.enabled too: the traces pipeline only exists there, and a processor
configured but referenced by no pipeline is config the collector can never
run — the same reason `filter/telemetry` is gated this way.
Usage: {{- if eq (include "kubernetes-agent.traceSamplingEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.traceSamplingEnabled" -}}
{{- $pct := float64 (include "kubernetes-agent.traceSamplingPercentage" .) -}}
{{- and (eq (include "kubernetes-agent.ebpfEnabled" .) "true") (lt $pct 100.0) -}}
{{- end -}}

{{/*
Whether Kubernetes cost monitoring runs: cost.enabled, read through this by
every template that has a part in it - the cost agent, the bundled OpenCost
and its Prometheus, their RBAC, the collector's cost-engine scrape and the
notes - so a preset that leaves it out leaves no half of it behind.

  true / false - what it says, on every preset.
  auto (the default; also an empty or missing value) - on, except on the
    gke-autopilot and eks-fargate presets. Those platforms bill every pod by
    what it requests, so the three cost pods would add to the bill they
    measure, and OpenCost prices nodes, which is not how either platform
    charges: the figures would be wrong. Turn it on there with true.

A value that is neither is refused while the chart renders (and by
values.schema.json before that), instead of being read as on or off.
Usage: {{- if eq (include "kubernetes-agent.costEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.costEnabled" -}}
{{- $enabled := (.Values.cost | default dict).enabled -}}
{{- $preset := default "" .Values.preset -}}
{{- if kindIs "bool" $enabled -}}
{{- ternary "true" "false" $enabled -}}
{{- else if or (kindIs "invalid" $enabled) (eq (toString $enabled | trim | lower) "auto") (eq (toString $enabled | trim) "") -}}
{{- ternary "false" "true" (or (eq $preset "gke-autopilot") (eq $preset "eks-fargate")) -}}
{{- else if eq (toString $enabled | trim | lower) "true" -}}
true
{{- else if eq (toString $enabled | trim | lower) "false" -}}
false
{{- else -}}
{{- fail (printf "cost.enabled is %q. Set it to true, false or auto (the default: on, except on the gke-autopilot and eks-fargate presets)." (toString $enabled)) -}}
{{- end -}}
{{- end -}}

{{/*
Whether cost.enabled is left to the chart (auto) rather than set to true or
false - for the notes, which say why cost is on or off.
Usage: {{- if eq (include "kubernetes-agent.costAuto" .) "true" }}
*/}}
{{- define "kubernetes-agent.costAuto" -}}
{{- $enabled := (.Values.cost | default dict).enabled -}}
{{- if kindIs "bool" $enabled -}}
false
{{- else if or (kindIs "invalid" $enabled) (eq (toString $enabled | trim | lower) "auto") (eq (toString $enabled | trim) "") -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the deployment collector scrapes the cost engine's metrics:
cost.metrics.enabled, while cost monitoring runs.
Usage: {{- if eq (include "kubernetes-agent.costMetricsEnabled" .) "true" }}
*/}}
{{- define "kubernetes-agent.costMetricsEnabled" -}}
{{- if and (eq (include "kubernetes-agent.costEnabled" .) "true") .Values.cost.metrics.enabled -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the chart bundles its own cost engine (OpenCost + a minimal
Prometheus). Bundling is the default when cost is enabled; providing
`cost.engine.url` means "use my existing OpenCost / Kubecost" and turns
the bundle off. Usage:
  {{- if eq (include "kubernetes-agent.costEngineBundled" .) "true" }}
*/}}
{{- define "kubernetes-agent.costEngineBundled" -}}
{{- if and (eq (include "kubernetes-agent.costEnabled" .) "true") (not .Values.cost.engine.url) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether cost.engine.url is `auto` (#9633): bundle nothing, and let the cost
agent find the OpenCost or Kubecost the cluster already runs, wherever it is,
at run time. The chart cannot look for it itself: it reads no cluster objects
while it renders, since under `helm template`, Argo CD and dry runs there are
none to read, so the same values would render differently depending on the
tool. Any spelling of auto counts.
Usage: {{- if eq (include "kubernetes-agent.costEngineAuto" .) "true" }}
*/}}
{{- define "kubernetes-agent.costEngineAuto" -}}
{{- if eq (toString .Values.cost.engine.url | trim | lower) "auto" -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether the collector's cost-engine job asks the cost agent where to scrape
(#9776, #9852): the agent runs, cost.metrics.endpoint names no endpoint of
its own, and the agent may read an engine the chart did not put there:
cost.engine.url is auto or a URL, or the chart bundles OpenCost and the agent
prefers the cluster's own engine when it finds one
(kubernetes-agent.costEnginePreferExisting).

Where an engine serves its price metrics depends on which engine it is and
which of its Services the URL names (checked against Kubecost 2.8.7, Kubecost
3.3.2 and OpenCost 1.121.4): OpenCost's API and Kubecost 2's cost model at
/metrics; Kubecost 2's frontend and OpenCost's UI answer /metrics with their
web page and proxy the engine's metrics at /model/metrics; Kubecost 3's
frontend has them at no path at all, its finops agent's Service does. The
chart cannot see which while it renders (it reads no cluster objects: under
helm template, Argo CD or a dry run there are none to read), and relabeling
cannot weigh one Service against another. The agent reads the engine, so it
finds the endpoint (agents/KubernetesCostAgent/EngineMetrics.ts) and serves
it at /scrape-targets, which the job reads through http_sd.

With the bundled engine, that is what keeps the dashboard's prices those of
the engine the Costs pages are priced by (#9852): the agent answers with the
bundled OpenCost's until it reads the cluster's own, then with that one's,
and with the bundled one's again if it falls back. A static target would
scrape the bundled OpenCost's prices beside the cluster's own engine's
allocations.

The bundled OpenCost the agent always reads (cost.engine.preferExisting
false, or a rate card of its own) is scraped where the chart put it, an
explicit cost.metrics.endpoint as written, and with the agent off the engine
URL's /metrics as before (the auto job then finds engines itself).
Usage: {{- if eq (include "kubernetes-agent.costMetricsFromAgent" .) "true" }}
*/}}
{{- define "kubernetes-agent.costMetricsFromAgent" -}}
{{- if and (eq (include "kubernetes-agent.costMetricsEnabled" .) "true") .Values.cost.agent.enabled (or (ne (include "kubernetes-agent.costEngineBundled" .) "true") (eq (include "kubernetes-agent.costEnginePreferExisting" .) "true")) (not (.Values.cost.metrics.endpoint | default "" | toString | trim)) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Where the collector asks the cost agent for the engine's price metrics: its
health port, through the Service service-cost-agent.yaml renders while
kubernetes-agent.costMetricsFromAgent is true. The answer is Prometheus http_sd
JSON: a target, its scheme and path, or an empty list.
*/}}
{{- define "kubernetes-agent.costScrapeTargetsUrl" -}}
http://{{ include "kubernetes-agent.fullname" . }}-cost.{{ .Release.Namespace }}.svc.cluster.local:13134/scrape-targets
{{- end -}}

{{/*
Whether the cost agent reads the cluster's own engine instead of the bundled
one when it finds one (#9633): with the bundled engine, unless
cost.engine.preferExisting is false or the bundled engine has a rate card
(cost.opencost.customPricing.enabled), whose rates someone chose. The agent
looks when it starts and hourly, and falls back to the bundled engine.
Usage: {{- if eq (include "kubernetes-agent.costEnginePreferExisting" .) "true" }}
*/}}
{{- define "kubernetes-agent.costEnginePreferExisting" -}}
{{- if and (eq (include "kubernetes-agent.costEngineBundled" .) "true") (ne (toString .Values.cost.engine.preferExisting) "false") (not .Values.cost.opencost.customPricing.enabled) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Resolved base URL of the cost engine the poller and the metrics scrape
talk to: the operator-provided external engine when `cost.engine.url` is
set, else the bundled OpenCost Service. `auto` when cost.engine.url is auto:
the agent then finds the engine, and the scrape finds it the same way
(configmap-deployment.yaml), so neither ever reads the word as a URL.
*/}}
{{- define "kubernetes-agent.costEngineUrl" -}}
{{- if eq (include "kubernetes-agent.costEngineAuto" .) "true" -}}
auto
{{- else if .Values.cost.engine.url -}}
{{- .Values.cost.engine.url -}}
{{- else -}}
http://{{ include "kubernetes-agent.fullname" . }}-opencost.{{ .Release.Namespace }}.svc.cluster.local:9003
{{- end -}}
{{- end -}}

{{/*
Resolved Prometheus URL for the cost pipeline, or EMPTY when there is none.

The cost agent reads per-container memory PEAKS from here. The Allocation
API only reports averages over the window, and an hourly mean hides the
burst that OOMKills a container — so a memory right-sizing recommendation
built on the average is actively dangerous. CPU needs no such help
(overshoot throttles rather than kills), which is why this is optional.

Empty is a legitimate, supported answer: an install pointing at an external
cost engine gets no bundled Prometheus, and the agent treats an empty value
as "ship allocations without peaks". Never default this to the bundled
Service name unconditionally — on an external-engine install that name
resolves to nothing and every poll would fail against it.
*/}}
{{- define "kubernetes-agent.costPrometheusUrl" -}}
{{- if .Values.cost.engine.prometheusUrl -}}
{{- .Values.cost.engine.prometheusUrl -}}
{{- else if eq (include "kubernetes-agent.costEngineBundled" .) "true" -}}
http://{{ include "kubernetes-agent.fullname" . }}-cost-prometheus.{{ .Release.Namespace }}.svc.cluster.local:9090
{{- end -}}
{{- end -}}

{{/*
Whether kubernetes-agent.costPrometheusUrl is the chart's bundled Prometheus
rather than one cost.engine.prometheusUrl names (#9777). The cost agent then
reads it for the bundled engine, and for the cluster's own engine only when
it cannot find the Prometheus that engine reads; one named in
cost.engine.prometheusUrl it reads whatever the engine.
Usage: {{- if eq (include "kubernetes-agent.costPrometheusBundled" .) "true" }}
*/}}
{{- define "kubernetes-agent.costPrometheusBundled" -}}
{{- if and (eq (include "kubernetes-agent.costEngineBundled" .) "true") (not .Values.cost.engine.prometheusUrl) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Split a metrics URL into the three things a Prometheus scrape job takes it
as: `scheme`, a bare `host:port` target, and `metrics_path`.

A static target has to be a bare host:port. The prometheus receiver rejects
one with a "/" in it ("... is not a valid hostname"), and it does so while
LOADING the config, so the collector never starts: a stray trailing slash on
one endpoint takes every cluster metric and Kubernetes event down with it.
So the URL cannot be written into `targets` as it is. And cutting it down to
host:port without carrying the rest over scrapes somewhere other than where
the URL points: plain HTTP for an https:// endpoint, /metrics for any other
path.

What a scrape job has no place for is refused here, while the chart renders,
instead of being dropped or left in the target:
  - Credentials (user:password@). In a target they authenticate nothing, the
    scrape never succeeds, and the receiver exports the target, password and
    all, as the `instance` of the job's `up` series.
  - A query string or a fragment, which would be requested as part of the
    path.
  - A "%" in the path, which the receiver encodes a second time, and a "$",
    which the collector expands as a variable.
  - An empty URL or a scheme other than http(s). Either renders a job that
    starts and scrapes nothing.
The error names the setting and never repeats the URL, since the URL may be
what carries the password.

Takes a dict: `url`, and `setting`, the values key the URL came from.
Returns JSON: {"scheme": "http"|"https", "target": "<host:port>", "path": "<path>"}.
`path` is EMPTY when the URL's path is the receiver's default (/metrics, or
no path at all), so a caller writes `metrics_path` only when it has to and an
ordinary http://host:port/metrics endpoint renders the job it always did.
Repeated slashes and a trailing slash are dropped from the path.

Usage:
  {{- $endpoint := include "kubernetes-agent.scrapeEndpoint" (dict "url" $url "setting" "kubeStateMetrics.endpoint") | fromJson }}
*/}}
{{- define "kubernetes-agent.scrapeEndpoint" -}}
{{- $url := .url | default "" | toString | trim -}}
{{- $form := "Write it as http://host:port/path or https://host:port/path (the port and the path are optional)." -}}
{{- $scheme := ternary "https" "http" (regexMatch "(?i)^https://" $url) -}}
{{- $rest := regexReplaceAll "(?i)^https?://" $url "" -}}
{{- /* After the empty URL, in order: another scheme (tcp://, or http://
       written twice); http:/ with one slash, which would otherwise read as a
       host named "http"; anything that is not host[:port] followed by a path
       of plain characters. The host part takes ":" so an unbracketed IPv6
       address and an empty port still pass: the receiver dials both. And a
       scheme is taken to have no dot in it, so a dotted host name with an
       empty port in front of a doubled slash is not mistaken for one. */}}
{{- if not $url -}}
{{- fail (printf "%s is empty, and it is the URL to scrape. %s" .setting $form) -}}
{{- else if or (regexMatch "^[A-Za-z][A-Za-z0-9+-]*://" $rest) (regexMatch "(?i)^https?:(/|$)" $rest) (not (regexMatch `^[\pL\pN._:\[\]%-]+(/[\pL\pN._~!*'()+,;=:@&/-]*)?$` $rest)) -}}
{{- fail (printf "%s is not a URL the agent can scrape. %s Credentials (user:password@), a query string, a fragment, and a %% or $ in the path have no place in a scrape job, so they are refused rather than dropped." .setting $form) -}}
{{- end -}}
{{- $target := regexFind "^[^/]*" $rest -}}
{{- $path := regexReplaceAll "/+" (trimPrefix $target $rest) "/" | trimSuffix "/" -}}
{{- if eq $path "/metrics" -}}
{{- $path = "" -}}
{{- end -}}
{{- toJson (dict "scheme" $scheme "target" $target "path" $path) -}}
{{- end -}}

{{/*
Whether the control-plane scrape has anything to scrape: controlPlane.enabled
and at least one component with endpoints, or one found through service
discovery. A component with neither (etcd, the scheduler and the controller
manager by default: they answer on the control-plane nodes, which the pod
cannot guess) gets no job, and a prometheus receiver with no job at all refuses
to start, so the receiver is only added when this is "true".

Usage: {{- if eq (include "kubernetes-agent.controlPlaneScrapes" .) "true" }}
*/}}
{{- define "kubernetes-agent.controlPlaneScrapes" -}}
{{- $cp := .Values.controlPlane | default dict -}}
{{- $any := false -}}
{{- if $cp.enabled -}}
{{- range $component := list "etcd" "apiServer" "scheduler" "controllerManager" -}}
{{- if (get $cp $component | default dict).endpoints -}}
{{- $any = true -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq (include "kubernetes-agent.controlPlaneDiscovery" .) "true" -}}
{{- $any = true -}}
{{- end -}}
{{- $any -}}
{{- end -}}

{{/*
Whether a control-plane component's scrape job finds its targets through
service discovery rather than at the endpoints you list.

OpenShift runs the scheduler, the controller manager and etcd as static pods
on the control-plane nodes, one replica on each, behind a Service. A fixed
address would reach whichever replica the Service picks, a different one on
each scrape, so on the OpenShift presets each replica is found in the Service's
EndpointSlices and scraped on its own, as OpenShift's own ServiceMonitors do.

  - The scheduler and the controller manager accept the service account's
    token: they delegate to the API server, and the ClusterRole grants GET on
    /metrics.
  - etcd asks for a client certificate, so it has a job only once
    controlPlane.etcd.clientCertSecret names a Secret that holds one.
  - The API server is not one of them: it answers at kubernetes.default.svc,
    which needs no discovery.

Endpoints you list win: the component keeps its job, at your list. A hosted
control plane (ROSA with HCP, HyperShift) has no such pods in the cluster, so
discovery finds no target there and nothing else changes. On any other preset
these jobs do not render at all.

Takes a dict: `root`, and `component`, a key of controlPlane.
Usage: {{- if eq (include "kubernetes-agent.controlPlaneDiscovered" (dict "root" $ "component" "scheduler")) "true" }}
*/}}
{{- define "kubernetes-agent.controlPlaneDiscovered" -}}
{{- $controlPlane := .root.Values.controlPlane | default dict -}}
{{- $values := get $controlPlane .component | default dict -}}
{{- $discoverable := has .component (list "scheduler" "controllerManager") -}}
{{- if eq .component "etcd" -}}
{{- $discoverable = not (empty $values.clientCertSecret) -}}
{{- end -}}
{{- if and $controlPlane.enabled (eq (include "kubernetes-agent.openshift" .root) "true") $discoverable (not $values.endpoints) -}}
true
{{- else -}}
false
{{- end -}}
{{- end -}}

{{/*
Whether any control-plane job uses service discovery, which is what the
ClusterRole's read of EndpointSlices is for (templates/rbac.yaml) and what the
notes explain.
Usage: {{- if eq (include "kubernetes-agent.controlPlaneDiscovery" .) "true" }}
*/}}
{{- define "kubernetes-agent.controlPlaneDiscovery" -}}
{{- $root := . -}}
{{- $any := false -}}
{{- range $component := list "etcd" "scheduler" "controllerManager" -}}
{{- if eq (include "kubernetes-agent.controlPlaneDiscovered" (dict "root" $root "component" $component)) "true" -}}
{{- $any = true -}}
{{- end -}}
{{- end -}}
{{- $any -}}
{{- end -}}

{{/*
How a scrape job finds a control-plane component's replicas on OpenShift: the
EndpointSlices of one namespace, each of them a target at its own address, kept
only for that Service and for its port with that name. A Service lists several
ports (etcd's lists six), and every endpoint of every port is a target until
relabelling drops it.

Takes a dict: `namespace`, `service` and `port`, the port's name.
Usage: {{- include "kubernetes-agent.controlPlaneDiscoveryConfig" (dict "namespace" "openshift-etcd" "service" "etcd" "port" "etcd-metrics") | nindent 14 }}
*/}}
{{- define "kubernetes-agent.controlPlaneDiscoveryConfig" -}}
kubernetes_sd_configs:
  - role: endpointslice
    namespaces:
      names:
        - {{ .namespace }}
relabel_configs:
  - source_labels: [__meta_kubernetes_service_name]
    action: keep
    regex: {{ .service }}
  - source_labels: [__meta_kubernetes_endpointslice_port_name]
    action: keep
    regex: {{ .port }}
{{- end -}}

{{/*
The scheme of a control-plane component's scrape job. The job reads every
endpoint in its list, and one job has one scheme: http when every endpoint
says http:// (etcd's plain metrics port), https otherwise, a bare host:port
included, since the components serve HTTPS. The scheme used to be https
whatever the endpoint said, so http://...:2381 failed every scrape. A list
that mixes the two is refused while the chart renders, naming the setting.

Takes a dict: `endpoints`, and `setting`, the values key they came from.
Usage: {{ include "kubernetes-agent.controlPlaneScheme" (dict "endpoints" .endpoints "setting" "controlPlane.etcd.endpoints") }}
*/}}
{{- define "kubernetes-agent.controlPlaneScheme" -}}
{{- $http := 0 -}}
{{- range .endpoints -}}
{{- if regexMatch "(?i)^http://" (toString .) -}}
{{- $http = add1 $http -}}
{{- end -}}
{{- end -}}
{{- if eq $http 0 -}}
https
{{- else if eq $http (len .endpoints) -}}
http
{{- else -}}
{{- fail (printf "%s mixes http:// and https:// endpoints. A component is scraped by one job, with one scheme: list its endpoints with the same one." .setting) -}}
{{- end -}}
{{- end -}}

{{/*
A control-plane endpoint as a scrape target: host:port, without the scheme
(the job's scheme says it) and without the path (every component serves
/metrics, the job's metrics_path).

Usage: {{ include "kubernetes-agent.controlPlaneTarget" . | quote }}
*/}}
{{- define "kubernetes-agent.controlPlaneTarget" -}}
{{- regexFind "^[^/]*" (regexReplaceAll "(?i)^https?://" (toString . | trim) "") -}}
{{- end -}}
