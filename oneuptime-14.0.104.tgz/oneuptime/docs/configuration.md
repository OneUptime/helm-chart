# Configuration Reference

Every configurable value in the OneUptime chart, grouped by topic. Set these in
your `values.yaml` (see [Installation](installation.md)). For the full, always
up-to-date list see [`values.yaml`](../values.yaml).

🚨 = you almost always need to change this for a real deployment.

## Core / required

| Parameter          | Description                                                                                     | Default         | Change |
|--------------------|-------------------------------------------------------------------------------------------------|-----------------|:------:|
| `global.storageClass` | Storage class used for all persistent volumes.                                               | `nil`           | 🚨 |
| `host`             | Primary hostname served by OneUptime (used for routing and certificates).                       | `localhost`     | 🚨 |
| `httpProtocol`     | Set to `https` when people reach OneUptime over HTTPS (TLS at the chart's nginx or at a proxy in front of it), otherwise `http`. See [HTTPS](#https). | `http`          | 🚨 |
| `ssl.provision`    | Auto-provision a Let's Encrypt certificate for the primary host (needs public ports 80 & 443).  | `false`         |    |
| `oneuptimeSecret`  | Value used for `ONEUPTIME_SECRET`, the cluster key OneUptime's own services present to each other. Leave it empty for a generated one, or set a long random string. A value the repository ships (`secret`, a `please-change-this` placeholder) is refused. The bundled global Runner never holds it. | `nil`           |    |
| `encryptionSecret` | Value used for `ENCRYPTION_SECRET`. Set to a long random string in production.                   | `nil`           |    |
| `global.clusterDomain` | Kubernetes cluster domain.                                                                   | `cluster.local` |    |
| `nodeEnvironment`  | Node environment. Leave as `production` unless doing local development.                          | `production`    |    |
| `logLevel`         | One of `INFO`, `WARN`, `ERROR`, `DEBUG`.                                                         | `INFO`          |    |

## Application secrets

`ONEUPTIME_SECRET`, `ENCRYPTION_SECRET` and `REGISTER_PROBE_KEY` can be supplied
in three ways, in this order of precedence:

1. Inline, via `oneuptimeSecret` / `encryptionSecret` / `registerProbeKey`.
2. From a Kubernetes Secret you manage yourself, via the `externalSecrets`
   block below. Leave the inline values blank when you use this.
3. Not at all — the chart then generates a random 32-character value into its
   own `<release>-secrets` Secret on install and keeps it across upgrades.

| Parameter                                              | Description                                                       | Default |
|--------------------------------------------------------|-------------------------------------------------------------------|---------|
| `externalSecrets.oneuptimeSecret.existingSecret.name`  | Name of an existing Secret holding `ONEUPTIME_SECRET`.             | `nil`   |
| `externalSecrets.oneuptimeSecret.existingSecret.passwordKey` | Key inside that Secret.                                      | `nil`   |
| `externalSecrets.encryptionSecret.existingSecret.name` | Name of an existing Secret holding `ENCRYPTION_SECRET`.            | `nil`   |
| `externalSecrets.encryptionSecret.existingSecret.passwordKey` | Key inside that Secret.                                     | `nil`   |
| `externalSecrets.registerProbeKey.existingSecret.name` | Name of an existing Secret holding `REGISTER_PROBE_KEY`.           | `nil`   |
| `externalSecrets.registerProbeKey.existingSecret.passwordKey` | Key inside that Secret.                                     | `nil`   |

Keys served by `externalSecrets` are not written into the chart-managed
`<release>-secrets` Secret at all — pods read them straight from your Secret, so
`helm diff` no longer reports them as changing on every render.

If you were already using `externalSecrets` before this change, the copies the
chart used to generate stay behind in the live `<release>-secrets` Secret: Helm
patches the `stringData` field, and the API server has already folded the old
values into `data`, so dropping a key from the template does not delete it from
the object. Nothing reads them, so leaving them is harmless. To clear them out:

```
kubectl patch secret <release>-secrets -n <namespace> --type=json \
  -p '[{"op":"remove","path":"/data/oneuptime-secret"},
       {"op":"remove","path":"/data/encryption-secret"},
       {"op":"remove","path":"/data/register-probe-key"}]'
```

Remove only the keys you actually serve via `externalSecrets`. Deleting them is
not free: if you later drop the `externalSecrets` block, the chart generates a
brand-new value for any key that is no longer in `<release>-secrets`, and a new
`ENCRYPTION_SECRET` means existing encrypted data can no longer be read. Leaving
the old copies in place is the safer default — an install that adopted
`externalSecrets` after running on chart-managed secrets had to copy its
`ENCRYPTION_SECRET` into its own Secret to keep its data readable, so the
retained copy is the same value and switching back picks it up again.

If your install used `externalSecrets` from day one, the retained copies are
values no pod ever read, and neither keeping nor deleting them gives you a
working fallback. Switch back by copying the real values out of your own Secret
first — set them inline as `oneuptimeSecret` / `encryptionSecret` /
`registerProbeKey`, or write them into `<release>-secrets` yourself.

Example:

```yaml
externalSecrets:
  oneuptimeSecret:
    existingSecret:
      name: one-uptime
      passwordKey: one-uptime-secret
  encryptionSecret:
    existingSecret:
      name: one-uptime
      passwordKey: encryption-secret
  registerProbeKey:
    existingSecret:
      name: one-uptime
      passwordKey: register-probe-key
```

### Probe and Runner identity keys

`PROBE_KEY` and the bundled global Runner's key (`GLOBAL_RUNNER_KEY`) are not
shared application secrets — each one is the *identity* of a single probe or of
the global Runner. The server registers a brand-new probe the first time it sees
a key it does not recognise. They are configured per component rather than in
`externalSecrets`, and follow the same three-way precedence:

| Parameter                                    | Description                                                        | Default |
|----------------------------------------------|--------------------------------------------------------------------|---------|
| `probes.<key>.existingSecret.name`           | Name of an existing Secret holding this probe's `PROBE_KEY`.        | `nil`   |
| `probes.<key>.existingSecret.passwordKey`    | Key inside that Secret.                                             | `nil`   |
| `globalRunner.existingSecret.name`           | Name of an existing Secret holding the bundled global Runner's key (`GLOBAL_RUNNER_KEY`). | `nil`   |
| `globalRunner.existingSecret.passwordKey`    | Key inside that Secret.                                             | `nil`   |

An inline `probes.<key>.key` / `globalRunner.key` still wins; with neither set,
the chart generates the value into `<release>-secrets` as before. As with
`externalSecrets`, a key you serve yourself is not written into the
chart-managed Secret at all.

The global Runner's key is the one exception to the orphaning below: the server
keeps the global Runner under a fixed id and takes its key from the same value
the global Runner gets, so a regenerated key rotates it rather than leaving a
second one behind.

**Why this matters for GitOps.** `helm template` — what Argo CD and Flux render
with — always takes the chart's install branch, so a chart-generated key is a new
random value on every reconcile. For an identity key that means a new probe is
registered each time and the previous one is orphaned. Because a monitor's probe
list is fixed when the monitor is created and never back-filled, the monitor keeps
pointing at a probe that no longer runs and **monitoring stops with no error
anywhere**. Point these at Secrets you own to pin the identities.

```yaml
probes:
  one:
    existingSecret:
      name: oneuptime-identities
      passwordKey: probe-one-key
globalRunner:
  existingSecret:
    name: oneuptime-identities
    passwordKey: global-runner-key
```

## Networking & ingress

| Parameter                    | Description                                                          | Default        |
|------------------------------|----------------------------------------------------------------------|----------------|
| `nginx.service.type`         | Service type for the bundled OneUptime ingress gateway.              | `LoadBalancer` |
| `nginx.service.loadBalancerIP` | Load balancer IP for the nginx service.                            | `nil`          |
| `nginx.service.externalTrafficPolicy` | `Local` keeps each visitor's own address on the way to the gateway. Empty keeps Kubernetes' default, `Cluster`. See [Visitor addresses](#visitor-addresses). | `""` |
| `nginx.listenAddress`        | The one address the gateway listens on inside its pod, such as `0.0.0.0:` (IPv4 only). Empty: every IPv4 and IPv6 address it has. | `""` |
| `nginx.listenOptions`        | Options of the gateway's listening socket, such as `backlog=4096`.  | `""`           |
| `statusPage.cnameRecord`     | CNAME record for the status page. See [Custom domains](custom-domains.md). | `nil`    |

## Images

| Parameter             | Description                                                                              | Default              |
|-----------------------|------------------------------------------------------------------------------------------|----------------------|
| `global.imageRegistry` | One registry for every image the chart runs, such as the registry an air-gapped install mirrors into (`registry.example.com`, or with a path). OneUptime's images come from `<imageRegistry>/<image.repository>/<name>` in place of `image.registry`, and the bundled PostgreSQL, ClickHouse, Valkey, PgBouncer, vLLM and kubectl images from `<imageRegistry>/<their repository>`, so mirror them under the same names and tags. A repository that already names a registry, `image.overrides` and `global.azure.images` are used as written; the KEDA, CloudNativePG and Altinity operator subcharts take their registry from their own values. | `""` |
| `image.registry`      | Docker image registry for OneUptime's own images, when `global.imageRegistry` is empty.   | `docker.io`          |
| `image.repository`    | Docker image repository.                                                                 | `oneuptime`          |
| `image.tag`           | Docker image tag. Pin this in production (see [Production checklist](production-checklist.md)). | `release`     |
| `image.pullPolicy`    | Image pull policy.                                                                        | `Always`             |
| `image.type`          | `community-edition` (the Apache-2.0 images, SAML and OIDC single sign-on included) or `enterprise-edition` (the Enterprise Edition images: the same tags with an `enterprise-` prefix, adding the enterprise features (SCIM, audit logs, team compliance, instance health dashboards) under the OneUptime Enterprise License). Production use of the Enterprise Edition requires a subscription under that license; an install with no license, or one holding a license whose expiry was never recorded, runs as a 14-day trial, which is for evaluation. After the trial (or 30 days after a license expires), SCIM and audit logging stop and enterprise configuration becomes read-only until a license is activated; single sign-on does not depend on the license, and core monitoring is never affected. | `community-edition`  |
| `image.restartPolicy` | Image restart policy.                                                                     | `Always`             |
| `imagePullSecrets`    | Pull secrets (a list of `name:` entries) for every pod the chart defines, the bundled PostgreSQL, ClickHouse and Valkey and the operator-run databases included. Set it for a registry that asks for credentials, such as an air-gapped install's mirror. | `nil` |

## Autoscaling & availability

| Parameter                                       | Description                                                                                   | Default |
|-------------------------------------------------|-----------------------------------------------------------------------------------------------|---------|
| `deployment.replicaCount`                       | Number of replicas.                                                                            | `1`     |
| `keda.enabled`                                  | Render the chart's KEDA `ScaledObject`s, so the opted-in tiers scale on queue backlog instead of a plain HorizontalPodAutoscaler. Opt a tier in with `<service>.keda.enabled`. | `false` |
| `keda.install`                                  | Install the bundled KEDA operator. Unset by default, which makes it follow `keda.enabled`; set it to `false` to use a KEDA your platform team already runs. See [KEDA Ops](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Docs/Keda.md). | unset |
| `autoscaling.enabled`                           | Enable autoscaling.                                                                            | `false` |
| `autoscaling.minReplicas`                       | Minimum number of replicas.                                                                    | `1`     |
| `autoscaling.maxReplicas`                       | Maximum number of replicas.                                                                    | `100`   |
| `autoscaling.targetCPUUtilizationPercentage`    | Target CPU utilization percentage.                                                            | `80`    |
| `autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization percentage.                                                        | `80`    |
| `podDisruptionBudget.enabled`                   | Create a PodDisruptionBudget for each stateless deployment (app, worker, nginx, home, probes, pgbouncer) to cap voluntary disruptions during node drains / upgrades. | `false` |
| `podDisruptionBudget.minAvailable`              | Minimum pods that must stay available. Integer or percentage (e.g. `"50%"`). Takes precedence over `maxUnavailable`. Leave empty to use `maxUnavailable`. | `""` |
| `podDisruptionBudget.maxUnavailable`            | Maximum pods that may be unavailable during a voluntary disruption. Integer or percentage.    | `1`     |
| `<service>.podDisruptionBudget`                 | Per-service override of the global block. Omitted keys inherit the global value. `<service>` = app/worker/nginx/home/probes.&lt;key&gt;/pgbouncer. | `{}` (inherit) |
| `deployment.spreadReplicasAcrossNodes`          | Give each stateless service a soft rule that puts its replicas on different nodes, so one node drain or node failure cannot take every replica down. Never blocks scheduling. Any `topologySpreadConstraints` you set replace it. See [Spreading replicas across nodes](#spreading-replicas-across-nodes). | `true` |

## Probes

Configured per probe under `probes.<key>`.

| Parameter                                         | Description                                                            | Default |
|---------------------------------------------------|------------------------------------------------------------------------|---------|
| `probes.<key>.name`                               | Probe name.                                                            | `<key>` |
| `probes.<key>.description`                         | Probe description.                                                     | `nil`   |
| `probes.<key>.key`                                | Probe key. Set to a long random string to secure your probes.         | `nil`   |
| `probes.<key>.existingSecret.name`                | Read this probe's `PROBE_KEY` from a Secret you manage instead. See [Probe and Runner identity keys](#probe-and-runner-identity-keys). | `nil`   |
| `probes.<key>.existingSecret.passwordKey`         | Key inside that Secret.                                               | `nil`   |
| `probes.<key>.monitoringWorkers`                  | Number of parallel processes used to monitor resources.               | `3`     |
| `probes.<key>.monitorFetchLimit`                  | Number of resources monitored in parallel.                            | `10`    |
| `probes.<key>.automountServiceAccountToken`       | Mount a Kubernetes service-account token into Probe pods. Disabled by default because Probes do not require Kubernetes API credentials. | `false` |
| `probes.<key>.allowPrivateNetworkMonitors`        | Let API, Website, External Status Page and Custom JavaScript Code monitors on this probe reach private network addresses (RFC-1918, CGNAT, IPv6 unique-local). Chart probes register as global probes, so this opens those targets to monitors from **every project** on the instance. Loopback, link-local and cloud metadata addresses stay blocked either way. Ignored, with a startup warning, when `billing.enabled` is `true`; deploy a private probe there instead. | `false` |
| `probes.<key>.syntheticMonitorScriptTimeoutInMs`  | Timeout for synthetic monitor scripts in milliseconds (`1`–`2147363647`). The upper bound reserves 120 seconds for browser and worker startup within Node.js's safe timer range. | `60000` |
| `probes.<key>.syntheticMonitorMaxConcurrency`     | Maximum isolated synthetic browser processes per Probe; extra executions queue FIFO. | `4` |
| `probes.<key>.syntheticMonitorMaxProcessTreeRssBytes` | Memory ceiling for each isolated worker and all browser descendants together, measured as their proportional set size (pages the browser's processes share count once). | `1610612736` |
| `probes.<key>.syntheticMonitorMaxDiskBytes` | Writable disk ceiling for each isolated execution, including browser profiles, caches, IndexedDB, and OPFS. | `268435456` |
| `probes.<key>.syntheticMonitorTempStorageSizeLimit` | Pod-level `emptyDir` ceiling for `/tmp`, providing a backstop across all concurrent synthetic executions. Increase this when raising concurrency or the per-run disk ceiling. | `2Gi` |
| `probes.<key>.syntheticMonitorChromiumSandboxEnabled` | Require Chromium's OS sandbox. Enable only after installing a Playwright-compatible Localhost seccomp profile on every Probe node; launch fails closed when the sandbox is unavailable. | `false` |
| `probes.<key>.customCodeMonitorScriptTimeoutInMs` | Timeout for custom code monitor scripts.                              | `60000` |
| `probes.<key>.proxy.httpProxyUrl`                 | HTTP proxy URL for HTTP requests made by the probe (optional).        | `nil`   |
| `probes.<key>.proxy.httpsProxyUrl`                | HTTPS proxy URL for HTTPS requests made by the probe (optional).      | `nil`   |
| `probes.<key>.proxy.noProxy`                      | Comma-separated hosts that bypass the proxy (optional).               | `nil`   |
| `probes.<key>.additionalContainers`              | Additional containers to add to the probe pod.                        | `nil`   |
| `probes.<key>.resources`                          | Pod resources (limits, requests).                                     | `nil`   |
| `probes.<key>.dnsConfig`                          | Per-probe [`dnsConfig`](https://kubernetes.io/docs/concepts/services-networking/dns-pod-service/#pod-dns-config) override. Unset by default — the probe inherits the chart-wide `dnsConfig` (see below). A per-probe value fully replaces the chart-wide default (not merged). | `nil` (inherits chart-wide) |
| `probes.<key>.dnsPolicy`                          | Per-probe `dnsPolicy` override. Unset by default — inherits the chart-wide `dnsPolicy`. | `nil` (inherits chart-wide) |

Synthetic executions always run in short-lived processes and browser workers.
The image's default root Probe supervisor additionally assigns each execution a
unique, low-privilege UID. An explicit non-root Probe override remains supported,
but workers then share the Probe UID and lose that extra UID boundary. The stock
`RuntimeDefault` seccomp profile keeps the chart portable but blocks the
user-namespace calls both browsers' additional OS sandbox layer requires:
Chromium's sandbox must then stay disabled, and Firefox falls back to its
seccomp-only sandbox. To enable that defense in depth, install a
CRI/OCI-compatible profile derived from your container runtime's default with
`clone`, `setns`, `unshare` **and `chroot`** allowed unconditionally in the
kubelet seccomp directory on every Probe node, then configure the matching path.
Firefox and Chromium both call `chroot` inside the user namespace they create.
A profile that allows the namespace but not `chroot` crashes every Firefox
content process (`Sandbox: chroot: EPERM`) and the Chromium zygote
(`Check failed: sys_chroot`), so every synthetic check fails. No capability is
needed for either call, and adding `SYS_CHROOT` does not help when the
profile omits `chroot`.
Do not use `packages/Probe/seccomp_profile.json` verbatim here: it contains
Moby-specific conditional fields for Docker Compose rather than Kubernetes CRI.

```yaml
probes:
  one:
    syntheticMonitorChromiumSandboxEnabled: true
    containerSecurityContext:
      seccompProfile:
        type: Localhost
        localhostProfile: profiles/oneuptime-playwright.json
```

> **Why probes have custom DNS settings.** Probes resolve mostly *external* hostnames. The Kubernetes default (`ndots:5` plus a multi-entry search list) turns every external lookup into ~7 DNS queries funneled through a single upstream resolver, which under load causes intermittent `getaddrinfo EAI_AGAIN` failures and false monitor-down alerts. The chart ships a **chart-wide `dnsConfig` default** (`ndots:1`, which removes the search-domain fan-out, plus public fallback nameservers `8.8.8.8`/`1.1.1.1`); `dnsPolicy` stays `ClusterFirst` so `*.svc.cluster.local` (the OneUptime API the probe calls) still resolves. Each probe inherits this fallback unless it sets its own `probes.<key>.dnsConfig`. On **air-gapped clusters** with no egress to public DNS, drop the chart-wide `nameservers` list (keep the `options` block) or set `dnsConfig: {}`.

> **IPv6 targets.** Chart probes run on the cluster's pod network, so they can reach IPv6 destinations only on a dual-stack or IPv6-only cluster. On an IPv4-only cluster, checks of IPv6 destinations fail on these probes (a Ping monitor's failure reason then says the probe cannot send IPv6 traffic). To check a probe, run `kubectl exec -n <namespace> deploy/<release>-probe-<key> -- ping -6 -c 1 2001:4860:4860::8888`: `1 received` means it has IPv6, and `Network is unreachable` means the pod has no IPv6 route. To monitor IPv6 destinations from an IPv4-only cluster, use a [custom probe](https://oneuptime.com/docs/probe/custom-probe#monitoring-ipv6-destinations) on a machine that has IPv6.

## Global Runner

Every install runs one global Runner of its own, on by default, as it runs its
own global probes. It runs the runbook JavaScript steps of every project that
uses global Runners (every project does, unless it turns them off under
**Runbooks > Runners**), each in an isolated-vm sandbox of its own that can
reach public internet addresses but no private, loopback, link-local or cloud
metadata address, and the AI code fixes of those projects. Bash, SSH and
Kubernetes steps, and a repository's own commands, never run on it: they run on
a Runner a project installs in its own network. See
[Global Runners](https://oneuptime.com/docs/runbooks/agents#global-runners).

The global Runner took over the AI code fixes of the shared Runner, which the
chart no longer runs: nothing under `runner:` is read any more (the schema still
accepts the block, so an old values file keeps upgrading), and its KEDA
settings go under `globalRunner.keda`.

It is the Runner image started with a fixed id and its own key, and it holds
nothing else: no cluster key (`ONEUPTIME_SECRET`), none of the server's
settings, no ServiceAccount token, and never the chart-wide `extraEnv`,
`extraVolumes` or `extraVolumeMounts` (those are written for the server's pods,
and this one runs every project's steps). The app, worker and migrate Job get
the same key as `GLOBAL_RUNNER_KEY` and keep the global Runner's row from it on
every boot.

| Parameter                              | Description                                                                 | Default |
|----------------------------------------|-----------------------------------------------------------------------------|---------|
| `globalRunner.enabled`                 | Run the bundled global Runner. Set to `false` to turn it off: the server then removes it, and projects use the global Runners a master admin adds (Admin Dashboard > Settings > Global Runners) and their own Runners. | `true` |
| `globalRunner.replicaCount`            | How many global Runners run. `0` turns it off, as `enabled: false` does. While KEDA scales it, KEDA decides how many run. | `1`     |
| `globalRunner.concurrency`             | How many steps each global Runner runs at the same time. A project runs at most three of its steps on global Runners at once, whatever this says. | `4` |
| `globalRunner.key`                     | The global Runner's key. Leave empty to have the chart generate one.        | `nil`   |
| `globalRunner.existingSecret.name`     | Read the key from a Secret you manage instead. See [Probe and Runner identity keys](#probe-and-runner-identity-keys). | `nil` |
| `globalRunner.existingSecret.passwordKey` | Key inside that Secret.                                                  | `nil`   |
| `globalRunner.resources`               | Pod resources (limits, requests).                                           | `nil`   |
| `globalRunner.extraEnv`, `globalRunner.extraVolumes`, `globalRunner.extraVolumeMounts` | Extra environment variables and volumes for the global Runner alone, for example `HTTPS_PROXY` when it reaches the internet through a proxy. | `[]` |
| `globalRunner.keda.enabled`            | Scale the global Runner with KEDA on the AI code-fix tasks waiting for a Runner (`oneuptime_ai_agent_queue_size`, read from its own `/metrics/queue-size`). Needs `keda.enabled` too. | `false` |
| `globalRunner.keda.minReplicas`, `globalRunner.keda.maxReplicas` | The fewest and the most global Runners KEDA runs.  | `1`, `100` |
| `globalRunner.keda.queueSizeThreshold` | Waiting tasks per global Runner before KEDA adds one.                       | `5`     |
| `globalRunner.keda.pollingInterval`, `globalRunner.keda.cooldownPeriod` | How often KEDA reads the queue, and how long it waits after scaling, in seconds. | `30`, `300` |
| `globalRunner.keda.fallback`           | Replicas KEDA keeps when it cannot read the queue (`replicas: 0` turns it off). | `{failureThreshold: 3, replicas: 1}` |

## Incidents & alerts

| Parameter                            | Description                                                                          | Default |
|--------------------------------------|--------------------------------------------------------------------------------------|---------|
| `incidents.disableAutomaticCreation` | Disable automatic incident creation (useful during emergencies / alert overload).    | `false` |
| `alerts.disableAutomaticCreation`    | Disable automatic alert creation (useful during emergencies / alert overload).       | `false` |

## Queue dashboard

| Parameter                | Description                                                                                                        | Default |
|--------------------------|--------------------------------------------------------------------------------------------------------------------|---------|
| `queueDashboard.enabled` | Mount the BullMQ (Bull Board) queue inspector UI at `/worker/inspect/queue/<queueDashboard.secret>`. Requires a non-empty `secret`. | `false` |
| `queueDashboard.secret`  | URL path segment used to reach the queue dashboard. Set to a long random string. Not mounted while empty.         | `nil`   |

## Security & scheduling

Refer to the Kubernetes documentation for these. This chart depends on other
Bitnami charts — you will need to set the security context for those as well.

| Parameter                  | Description                | Default |
|----------------------------|----------------------------|---------|
| `podSecurityContext`       | Pod security context.      | `{}`    |
| `containerSecurityContext` | Container security context.| `{}`    |
| `probeContainerSecurityContext` | Probe-only container security defaults, merged beneath chart-wide and per-probe overrides. Keeps the root supervisor able to drop worker UIDs while applying `allowPrivilegeEscalation: false`, reduced capabilities, and `RuntimeDefault` seccomp. | see `values.yaml` |
| `nodeSelector`             | Node selector.             | `{}`    |
| `tolerations`              | Tolerations.               | `[]`    |
| `affinity`                 | Affinity.                  | `{}`    |
| `topologySpreadConstraints` | Topology spread constraints for the stateless services. A constraint without a `labelSelector` is scoped to each service's own pods. | `[]` |
| `<service>.affinity`       | Affinity for one service. Replaces the chart-wide `affinity`. | `{}` |
| `<service>.topologySpreadConstraints` | Topology spread constraints for one service. Replaces the chart-wide list. | `[]` |

`<service>` is any of `app`, `home`, `nginx`, `worker`, `globalRunner`,
`telemetryWriter`, `probes.<name>` or `testServer`. `pgbouncer` takes
`pgbouncer.topologySpreadConstraints` too, but like its `affinity`, `tolerations`
and `nodeSelector` it never inherits the chart-wide value. A service's value
replaces the chart-wide one; the two are not merged.

### Spreading replicas across nodes

Kubernetes only weakly prefers to spread a Deployment's pods across nodes, and
"this node already has the image" usually outweighs it. Two replicas of a
service can end up on one node, and draining that node in a node-pool upgrade,
or losing it, then takes the service down.

`deployment.spreadReplicasAcrossNodes` (on by default) gives every stateless
service a soft rule that spreads its replicas across nodes. For `app` it
renders:

```yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      matchLabels:
        app: oneuptime-app
    matchLabelKeys:
      - pod-template-hash
```

- `whenUnsatisfiable: ScheduleAnyway` makes it a strong preference, not a
  requirement. Pods still schedule on a single-node cluster, or when only one
  node has room, so it never blocks a rollout.
- `matchLabelKeys: [pod-template-hash]` counts each rollout's pods on their own.
  Counted together with the old pods, the second new pod could join the first
  on the node that already pulled the new image. It is added on Kubernetes 1.27
  and later only.
- There is no zone rule by default. A pod that declares spread constraints
  replaces the scheduler's built-in ones, and the scheduler then ignores every
  node that lacks one of the constraints' labels, so a zone rule would turn the
  spreading off on clusters whose nodes have no zone label.

Which rule a service gets: its own `<service>.topologySpreadConstraints`, else
the chart-wide `topologySpreadConstraints` (except for `pgbouncer`), else the
default above. Set `deployment.spreadReplicasAcrossNodes: false` to render no
default. Any of these changes the pod template, so the pods roll once.

A constraint you write without a `labelSelector` gets the service's own one,
and on Kubernetes 1.27 and later also `matchLabelKeys: [pod-template-hash]`
unless it lists `matchLabelKeys` of its own. So one chart-wide entry spreads
every service separately. On a multi-zone cluster, spread across zones as well
(the list replaces the default, so keep the node rule):

```yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: ScheduleAnyway
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: ScheduleAnyway
```

Spreading only protects a service that runs more than one replica. Pair it with
`podDisruptionBudget.enabled: true`, which stops a node drain from evicting
every replica at once.

## Extra environment variables and volumes

Every workload the chart runs takes `extraEnv`, `extraVolumes` and
`extraVolumeMounts`. They are passed through to the pod spec verbatim, so
anything Kubernetes accepts in an `EnvVar`, `Volume` or `VolumeMount` works.
They are empty by default and render nothing at all, so an install that does not
set them is unaffected.

Set them at the top level to apply to every workload, or under a single service
to apply to just that one:

| Parameter                        | Description                                                                      | Default |
|----------------------------------|----------------------------------------------------------------------------------|---------|
| `extraEnv`                       | Extra environment variables added to every workload.                             | `[]`    |
| `extraVolumes`                   | Extra pod volumes added to every workload.                                       | `[]`    |
| `extraVolumeMounts`              | Extra container volume mounts added to every workload.                           | `[]`    |
| `<service>.extraEnv`             | Extra environment variables for one service. Replaces the chart-wide list.        | `[]`    |
| `<service>.extraVolumes`         | Extra pod volumes for one service. Replaces the chart-wide list.                  | `[]`    |
| `<service>.extraVolumeMounts`    | Extra container volume mounts for one service. Replaces the chart-wide list.      | `[]`    |

`<service>` is any of `app`, `worker`, `probes.<name>`, `home`,
`telemetryWriter`, `nginx`, `pgbouncer`, `testServer`, `migrate`, `vllm` or
`cronJobs.e2e`. The bundled global Runner (`globalRunner`) takes only its own
lists, never the chart-wide ones: see [Global Runner](#global-runner).

A service's list **replaces** the chart-wide one — the two are not merged. That
is the precedence the chart already uses for `hostAliases`, `nodeSelector` and
the security contexts, and for volumes it is the only safe one: concatenating
would produce two volumes with the same `name` as soon as you narrowed a
chart-wide volume for one service, and the API server rejects that pod outright.
Setting a service's list to `[]` inherits the chart-wide list rather than
clearing it, so a service cannot opt out of a chart-wide entry — scope the entry
per-service instead of chart-wide when only some services should get it.

`extraEnv` entries are appended after the variables the chart sets itself, so
Kubernetes — which applies the last entry for a repeated name — uses yours. Two
names are worth not repeating: `DISABLE_QUEUE_WORKERS` is what makes a pod a
`worker` rather than an API pod (and the reverse on `telemetryWriter`), so
setting it chart-wide silently changes what those tiers do.

The cache variables are a trap of their own: since 13.0.0 the app reads
`VALKEY_*` and only falls back to `REDIS_*`, so an `extraEnv` entry named
`REDIS_HOST` still wins the `REDIS_HOST` slot and is then **ignored**, because
the chart also sets `VALKEY_HOST` to its own cache. Override `VALKEY_HOST`,
`VALKEY_PORT`, `VALKEY_PASSWORD`, `VALKEY_DB`, `VALKEY_USERNAME`,
`VALKEY_IP_FAMILY` and `VALKEY_TLS_*` instead — or, better, use the
`externalValkey:` block, which is the supported way to point at a cache this
chart does not run. `helm install` warns about chart-wide `REDIS_*` entries it
finds; it cannot see per-service ones.


The bundled databases (`postgresql`, `valkey`, `clickhouse` and the ClickHouse
Keeper) and the `cronJobs.cleanup` jobs deliberately do not take these. The
databases are servers rather than clients, already expose their TLS and tuning
settings as first-class values, and have operator-managed twins whose pods come
from a CR rather than from these templates — so the setting would apply to only
half of an install. The cleanup jobs run `bitnami/kubectl` against the
in-cluster API server, which is trusted through the ServiceAccount CA.

### Example: trust an internal CA

The case these exist for. OneUptime's services are Node.js, so pointing
`NODE_EXTRA_CA_CERTS` at a mounted bundle is enough for every outbound TLS call
— webhooks, SMTP, custom monitors, an internal container registry, an
OIDC provider with a private issuer.

Put the bundle in a ConfigMap first:

```console
kubectl create configmap internal-ca-bundle -n oneuptime --from-file=ca.crt=/path/to/internal-ca.crt
```

Then, in your `values.yaml`:

```yaml
extraVolumes:
  - name: internal-ca
    configMap:
      name: internal-ca-bundle
extraVolumeMounts:
  - name: internal-ca
    mountPath: /etc/ssl/internal
    readOnly: true
extraEnv:
  - name: NODE_EXTRA_CA_CERTS
    value: /etc/ssl/internal/ca.crt
```

That reaches app, worker, every probe, home, telemetry-writer, nginx,
pgbouncer, test-server, the migrate Job and the e2e cron in one setting. The
migrate Job matters here: it talks to Postgres and ClickHouse before any app pod
does, so a CA it cannot see fails the install rather than degrading it. The
bundled global Runner never takes the chart-wide lists: when its JavaScript
steps or AI code fixes need the CA too, set the same three under
`globalRunner.extraVolumes`, `globalRunner.extraVolumeMounts` and
`globalRunner.extraEnv`.

`NODE_EXTRA_CA_CERTS` covers Node.js, which is every outbound call OneUptime's
own code makes. It does **not** reach the Chromium that probes drive for
synthetic browser monitors, or the one the e2e cron uses: Chromium reads the OS
trust store instead. Synthetic monitors against an internally-signed site need
the certificate baked into the image's `/usr/local/share/ca-certificates` and
`update-ca-certificates` run at build time.

Confirm what an upgrade would actually change before you run it:

```console
helm template my-oneuptime oneuptime/oneuptime -f values.yaml | grep -c NODE_EXTRA_CA_CERTS
```

## Migration Job annotations

The Job that runs the database migrations takes annotations of its own, for the
Job and for its pod. Both are empty by default and render nothing.

| Parameter                | Description                           | Default |
|--------------------------|---------------------------------------|---------|
| `migrate.annotations`    | Annotations on the migrate Job.       | `{}`    |
| `migrate.podAnnotations` | Annotations on the migrate Job's pod. | `{}`    |

Annotation values are strings: quote `"false"`, `"true"` and numbers, or
`helm install` refuses the value and names the key.

With `migrate.hook: true` the chart makes the Job a Helm hook and writes its
`helm.sh/hook`, `helm.sh/hook-weight` (`"-5"`) and `helm.sh/hook-delete-policy`
(`before-hook-creation`) annotations. A `helm.sh/hook-weight` or
`helm.sh/hook-delete-policy` in `migrate.annotations` replaces the chart's.
`helm.sh/hook` itself is refused there: set `migrate.hook` instead, which also
decides whether the new pods wait for the Job (see
[New pods and pending schema migrations](../../../Docs/Postgres.md#new-pods-and-pending-schema-migrations)).

**A service mesh.** A sidecar injected into the Job's pod, such as Istio's or
Linkerd's, can keep the pod running after the migrations finish, so the Job
never completes, and its traffic redirection can keep the Job's init container
from reaching Postgres. Keep the mesh out of the Job's pod:

```yaml
migrate:
  podAnnotations:
    sidecar.istio.io/inject: "false" # Linkerd: linkerd.io/inject: disabled
```

**Argo CD.** Argo CD renders the chart with `helm template`, so the Job is
named `<release>-migrate-1` on every sync, and Kubernetes does not let the pod
template of an existing Job change: a sync of a new version fails until the
Job is deleted, `migrate.ttlSecondsAfterFinished` after it finished, and from
then on the application shows OutOfSync until a sync creates the Job again.
Make the Job an Argo CD `Sync` hook instead, which Argo CD deletes and creates
again on each sync:

```yaml
migrate:
  annotations:
    argocd.argoproj.io/hook: Sync
    argocd.argoproj.io/hook-delete-policy: BeforeHookCreation
```

Use `Sync` with `migrate.hook: false` (the default), so the Job runs while the
new pods start and wait for it. A `PreSync` hook runs before anything else is
applied, so on a first sync it starts before the Secrets and the database it
needs exist; a `PostSync` hook runs only once every pod is Healthy, which the
waiting pods are not until the migrations are in.

## Local AI (vLLM)

Run a local, OpenAI-compatible LLM server in-cluster for OneUptime's AI
features. See the full [Local AI with vLLM](ai-vllm.md) guide.

| Parameter                                              | Description                                                                                     | Default |
|--------------------------------------------------------|-------------------------------------------------------------------------------------------------|---------|
| `vllm.enabled`                                         | Deploy a vLLM server (requires NVIDIA GPU nodes).                                                | `false` |
| `vllm.image.repository` / `vllm.image.tag`             | vLLM image to run. The image is ~10GB+, so the first pull can take several minutes.             | `vllm/vllm-openai` / pinned |
| `vllm.model`                                           | HuggingFace model id to serve. The default is small, Apache-2.0 licensed and not gated.         | `Qwen/Qwen2.5-1.5B-Instruct` |
| `vllm.servedModelName`                                 | Optional model alias exposed on `/v1/models`. If empty, use the full model id.                  | `""`    |
| `vllm.toolCalling.enabled` / `vllm.toolCalling.parser` | Enable OpenAI tool/function calling. Required for the AI copilot & agents. Parser is model-family specific (`hermes` for Qwen). | `true` / `hermes` |
| `vllm.apiKey`                                           | Optional API key guarding `/v1/*`. If unset, the server is unauthenticated (in-cluster only).   | `""`    |
| `vllm.huggingFace.token`                               | HuggingFace token for gated models (e.g. `meta-llama/*`). Not needed for the default model.     | `""`    |
| `vllm.persistence.enabled` / `vllm.persistence.size`   | Persistent cache for model weights and compile artifacts (one PVC per replica).                 | `true` / `50Gi` |
| `vllm.resources`                                       | Pod resources. Defaults request one `nvidia.com/gpu`.                                            | see `values.yaml` |
| `vllm.nodeSelector` / `vllm.tolerations`               | Schedule vLLM onto your GPU nodes.                                                               | `{}` / `[]` |

## Telemetry writer tier

Optional fixed-size deployment that owns all telemetry ClickHouse inserts.
When enabled, app/worker pods ship their batched inserts to it over
cluster-key-authenticated HTTP instead of inserting directly, so telemetry
ingest workers can scale out without adding ClickHouse insert concurrency
(which stays at `replicaCount × telemetryFanInMaxConcurrentInserts`). See the
sizing guidance in [production-checklist.md](production-checklist.md).

| Parameter                                            | Description                                                                                          | Default |
|------------------------------------------------------|------------------------------------------------------------------------------------------------------|---------|
| `telemetryWriter.enabled`                            | Deploy the tier and route app/worker telemetry inserts through it.                                   | `false` |
| `telemetryWriter.replicaCount`                       | Fixed pod count — a ClickHouse capacity decision, not a demand one. Never autoscaled on queue depth. | `2` |
| `telemetryWriter.autoscaling.enabled`                | Opt-in CPU/memory HPA (explicit enable only — the global `autoscaling` block never applies here). Requires `resources.requests`. | `false` |
| `telemetryWriter.keda.enabled`                       | Opt-in KEDA scaling on the tier-wide shed rate (429s over ~2 min, Valkey-backed); optional CPU/memory triggers compose. | `false` |
| `telemetryWriter.keda.shedCountThreshold`            | Sheds in the last ~2 minutes per replica before scaling up.                                          | `100` |
| `telemetryWriter.telemetryFanInMaxConcurrentInserts` | Concurrent ClickHouse INSERTs per pod. Cluster-wide = replicas × this.                               | `4` |
| `telemetryWriter.maxInflightRequests`                | Insert requests served concurrently per pod before shedding with 429 (bounds pod memory).            | `100` |
| `telemetryWriter.telemetryFanIn*`                    | Same batching/retry knobs as `worker.telemetryFanIn*`.                                               | see `values.yaml` |
| `telemetryWriter.clickhouseMaxOpenConnections` / `telemetryWriter.clickhouseIngestMaxOpenConnections` | Per-pod ClickHouse pool ceilings.                                    | `100` / inherit |

## Private network access

Two instance-wide gates decide whether outbound requests a project member
configures may reach private ranges (RFC-1918, CGNAT, IPv6 unique-local).
Loopback, link-local and the cloud metadata endpoint stay blocked under both.
They point in opposite directions: webhooks are refused private targets unless
you open them, while data sources, LLM providers, SMTP, OAuth token URLs, OIDC
discovery and runbook HTTP steps are allowed them unless you close them. Probe
monitors have their own per-probe switch, `probes.<key>.allowPrivateNetworkMonitors`
(see [Probes](#probes)). See
[Private Network Access](https://oneuptime.com/docs/self-hosted/private-network-access)
for the full picture.

| Parameter                                 | Description                                                                                                                         | Default |
|-------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------|---------|
| `webhooks.allowPrivateNetwork`            | Let workflows, project webhooks and on-call user webhooks reach private ranges. Status page subscriber webhooks are never covered.   | `false` |
| `webhooks.privateNetworkAllowlist`        | Comma-separated hosts, wildcards, IPs and CIDRs webhooks may reach regardless of range. Never list `169.254.169.254`.                | `""`    |
| `outboundConnections.blockPrivateNetwork` | Refuse private ranges for everything that is not a webhook, too (`DATA_SOURCE_BLOCK_PRIVATE_ADDRESSES`). Always on when `billing.enabled` is `true`. With it on, a refused host name, webhooks included, is reported without saying what it resolved to. | `false` |

## Update check

Once a day the worker asks GitHub which OneUptime version is the latest
release, and which security advisories OneUptime published. Master admins are
shown an "Update available" pill in the footer when a newer release is out, and
a red "Security update" pill and a notice on the Admin Dashboard when a
published advisory affects the version you run; master admins and the Admin
Notification Email are emailed once about each such advisory. Nothing about
your installation is sent, not even the version you run — GitHub sees your
public IP and a `User-Agent` naming OneUptime. An installation with no route to
`api.github.com` does not need to change anything: the request fails, is
logged at debug level, the last answer is kept, and nothing new is shown. See
[Update and Security Checks](https://oneuptime.com/docs/self-hosted/update-checks).

| Parameter                           | Description                                                                                                                                                                                  | Default |
|-------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|
| `updateCheck.disabled`              | Set to `true` to make no outbound call at all.                                                                                                                                                | `false` |
| `updateCheck.url`                   | Point the release check at an internal mirror. Must answer with GitHub's release shape (`tag_name`, `html_url`, `published_at`).                                                             | `""` (GitHub) |
| `updateCheck.securityAdvisoriesUrl` | Point the security advisory check at an internal mirror. Must answer with GitHub's repository security advisory shape (`ghsa_id`, `summary`, `severity`, `html_url`, `published_at`, `vulnerabilities`). | `""` (GitHub) |

## Daily check-in

Once a day the worker tells `oneuptime.com` the installation's URL and the
OneUptime version it runs, so OneUptime knows which installations still run a
release with a security issue and can reach the admins who registered them.
Nothing about your users, projects or monitoring data is sent. An installation
with no route to `oneuptime.com` does not need to change anything: the request
fails and is logged.

| Parameter                  | Description                                    | Default |
|----------------------------|------------------------------------------------|---------|
| `instanceCheckIn.disabled` | Set to `true` to make no call at all.          | `false` |

## Trusted proxies

`X-Forwarded-For` is a list, and each proxy appends the address it accepted the
connection from — so a caller can put whatever they like at the *front* of it.
Only the entries written by a proxy you run mean anything, and those are at the
*end*. `trustedProxyHops` says how far in from that end the real client sits,
and it is what decides which address status page and public dashboard IP
allowlists — and IP rate limits — actually check.

The default of `1` is correct for a stock install: the chart's own nginx
gateway is the only thing that touches the header, and the `LoadBalancer`
Service in front of it is L4 and does not. Whether the address the gateway
writes is the visitor's own is up to that Service: see
[Visitor addresses](#visitor-addresses).

**Raise it if you put your own HTTP proxy in front.** A CDN or WAF that appends
to `X-Forwarded-For` — Cloudflare, an AWS ALB, an ingress-nginx of your own —
makes this `2`, and each further appending proxy adds one.

Getting it wrong is visible in both directions. Set it too low and every
visitor is attributed to your own proxy, so allowlists match nobody. Set it too
high and you read an entry the caller writes, so a visitor can name any address
they like and the allowlist stops meaning anything.

Note that the allowlists assume the app is reachable only *through* those
proxies. Keep the app Service internal; a caller who can open a connection to
it directly is the peer, and no header setting compensates for that. With a
proxy of your own in front (`trustedProxyHops: 2`), keep the gateway's Service
internal as well (`nginx.service.type: ClusterIP`): a visitor who reaches the
gateway around your proxy writes the entry OneUptime would read.

IP rate limits count each client address, and for an IPv6 client its whole
`/64` as well, with room for ten addresses: one host can send from every
address of its `/64`, and an office or a hosting provider can put many people
or servers in one. Both are read from the address `trustedProxyHops` picks.

| Parameter          | Description                                                                                          | Default |
|--------------------|------------------------------------------------------------------------------------------------------|---------|
| `trustedProxyHops` | Number of appending reverse proxies you run in front of OneUptime. `0` ignores `X-Forwarded-For` entirely and uses the connecting address. | `1` |

## Locations in security emails

Security emails - a password reset, a changed password, wrong two factor
codes, a backup code used - tell the account's owner when the request came,
from which IP address and on which device and browser, so they can tell their
own request from somebody else's. They can also say roughly where it came from
("Berlin, Germany"), but only from your CDN or load balancer: OneUptime has no
IP location database of its own. Name the request headers it writes the
visitor's country, region and city into, and the emails show them.

Name only headers a proxy in front of OneUptime always writes itself,
replacing whatever the visitor sent. Any other header is the visitor's own
writing: whoever asks for someone's password reset could choose the place
their email shows. With no header named, the emails show no location.

| CDN | `country` | `region` | `city` |
|-----|-----------|----------|--------|
| Cloudflare, with *Add visitor location headers* turned on in its Managed Transforms | `cf-ipcountry` | `cf-region` | `cf-ipcity` |
| Amazon CloudFront, with the headers forwarded to the origin | `cloudfront-viewer-country` | `cloudfront-viewer-country-region-name` | `cloudfront-viewer-city` |
| Vercel | `x-vercel-ip-country` | `x-vercel-ip-country-region` | `x-vercel-ip-city` |

```yaml
trustedGeoHeaders:
  country: cf-ipcountry
  region: cf-region
  city: cf-ipcity
```

| Parameter                   | Description                                                            | Default |
|-----------------------------|------------------------------------------------------------------------|---------|
| `trustedGeoHeaders.country` | Request header your CDN writes the visitor's country into, as a two-letter code or a name. | `""` |
| `trustedGeoHeaders.region`  | Request header your CDN writes the visitor's region or state into.    | `""` |
| `trustedGeoHeaders.city`    | Request header your CDN writes the visitor's city into.                | `""` |

## Visitor addresses

OneUptime counts each visitor by the address its gateway accepted the
connection from: the sign-in limits, the other limits per address, and the IP
allowlists of status pages and dashboards all read it. With the chart's
gateway behind a `LoadBalancer` or `NodePort` Service, Kubernetes decides
whether that address is the visitor's own:

| `nginx.service.externalTrafficPolicy` | What OneUptime sees |
|---------------------------------------|---------------------|
| empty (the default), or `Cluster` | The address of the node a visitor came through. kube-proxy hands the gateway every visitor from it, so everyone who comes through one node is one visitor to OneUptime: one person's failed sign-ins can lock out the others. |
| `Local` | Each visitor's own address, when your load balancer passes it through. |

While the value is empty, `helm install` and `helm upgrade` say so. Set it to
`Cluster` to keep Kubernetes' default and stop the note.

**Load balancers that pass the visitor's address through** - MetalLB, and the
network load balancers of Google Cloud, Azure and AWS (a Network Load
Balancer) - keep it with `Local`:

```yaml
nginx:
  service:
    externalTrafficPolicy: Local
```

Under `Local`, Kubernetes sends visitors only to nodes that run a gateway pod,
and gives the Service a `healthCheckNodePort` that tells the load balancer
which nodes those are. When you switch a live install, a node without a gateway
pod refuses visitors until the load balancer's health check catches up, from
seconds to about a minute depending on its interval, so switch at a quiet time.
Spreading the gateway's replicas across nodes
(`nginx.topologySpreadConstraints`) keeps more nodes serving.

**Load balancers that end the connection themselves** - an AWS Classic Load
Balancer, and the load balancers of DigitalOcean, Hetzner and Linode, among
others - show the gateway their own address whatever the policy. There, put an
ingress controller of your own in front that takes the visitor's address from
the load balancer (most read the PROXY protocol, which these load balancers
can send), make the gateway's Service internal (`nginx.service.type:
ClusterIP`), and set `trustedProxyHops: 2`.

Do not raise `trustedProxyHops` to make up for a shared address: past the
proxies a visitor really passes through, it reads an entry the visitor writes.

The Admin Dashboard's **OneUptime Health** page says when several people sign
in from one private network address, which is what a hidden visitor address
looks like.

## HTTPS

Set `httpProtocol: https` once people reach OneUptime over HTTPS, whether TLS
ends at the chart's nginx (`ssl.provision: true`) or at a proxy, load balancer
or CDN in front of it. Besides building `https://` links, OneUptime then:

- keeps sign-in cookies on HTTPS (`Secure`), so a browser never sends a
  session over plain HTTP;
- sends `Strict-Transport-Security: max-age=31536000` for `host`, so a browser
  that has been there reaches that name over HTTPS only, on every port, for a
  year. Status pages and dashboards on custom domains never get this header,
  and neither does a `host` that is `localhost` (or a name under it) or an IP
  address.

Cookies are also `Secure` whenever a visitor's own connection is HTTPS, on any
domain: the chart's nginx tells the app so when it ends TLS itself, or when the
proxy in front of it sends `X-Forwarded-Proto: https`. Make sure yours does, or
the sign-in cookies of status pages and dashboards on custom domains it serves
are not kept on HTTPS. A plain-HTTP install (`httpProtocol: http`, no TLS in
front) sets its cookies as before, so people can still sign in.

To change how long browsers keep to HTTPS, set `HSTS_MAX_AGE_SECONDS` through
`extraEnv`. `0` makes browsers forget the rule at their next HTTPS visit: set it
a while before `host` has to answer over plain HTTP again.

```yaml
extraEnv:
  - name: HSTS_MAX_AGE_SECONDS
    value: "0"
```

## Web push notifications

Browsers receive OneUptime's notifications through Web Push, signed with a
VAPID key pair. Generate one once with `npx web-push generate-vapid-keys` and
keep it: browsers that subscribed with one key pair stop receiving pushes when
it changes. See
[Push Notifications](https://oneuptime.com/docs/self-hosted/push-notifications).

| Parameter                            | Description                                                                      | Default                        |
|--------------------------------------|----------------------------------------------------------------------------------|--------------------------------|
| `vapid.publicKey`                    | The public half of the key pair (`VAPID_PUBLIC_KEY`). Every browser is given it. | `nil`                          |
| `vapid.privateKey`                   | The private half (`VAPID_PRIVATE_KEY`), which signs every web push. Leave it empty when you use `vapid.existingSecret`. | `nil` |
| `vapid.subject`                      | A contact address the browser push services can reach you on (`VAPID_SUBJECT`).  | `mailto:support@oneuptime.com` |
| `vapid.existingSecret.name`          | Read the private key from a Secret you manage instead of `vapid.privateKey`.     | `nil`                          |
| `vapid.existingSecret.privateKeyKey` | The key of that Secret that holds the private key.                               | `privateKey`                   |

`vapid.privateKey` keeps the key in the release's values, which Helm stores with
every revision. To keep it out of them, put the key in a Secret in the
release's namespace and name that Secret instead:

```console
kubectl create secret generic oneuptime-vapid -n oneuptime --from-literal=privateKey=<private key>
```

```yaml
vapid:
  publicKey: <public key>
  existingSecret:
    name: oneuptime-vapid
```

Every pod that is given `VAPID_PRIVATE_KEY` (app, worker, telemetry writer,
nginx, home, test server and the migrate Job) then reads it from that Secret,
and the chart writes no copy of it. Set `vapid.privateKey` or
`vapid.existingSecret.name`, not both: the chart refuses the two together and
says which to clear. The public key stays in `vapid.publicKey`.

Pods read the private key when they start: after you change it in the Secret,
restart them (`kubectl rollout restart deployment -n oneuptime` restarts every
Deployment in the namespace).

## On-call calendar feeds

People can subscribe Google Calendar, Outlook or Apple Calendar to their
on-call shifts through a secret `.ics` URL of the form
`https://<host>/api/on-call-calendar/user/<token>/shifts.ics` (schedule-wide
and project-wide feeds live under `/schedule/` and `/project/`). The token in
the path is the whole credential, so treat those URLs like passwords: the
chart's own nginx does not write them to its access log, but any proxy, WAF or
CDN you put in front will log the URI unless you tell it not to.

`onCallCalendarFeed.disabled: true` switches every feed URL off. Clients get a
`503` with `Retry-After: 3600`, keep the copy they already have and try again in
an hour; nothing is deleted, and flipping it back resumes the feeds.

The rate limits bound those public routes. `perTokenPerWindow` is the budget one
subscribed calendar gets (keyed on token + client address); `perIpPerWindow` is
the ceiling that survives a caller rotating tokens. Calendar clients poll about
hourly -- Apple Calendar every five minutes at most -- so the defaults leave
plenty of room for a whole team's clients behind one office address. The client
address is the one `trustedProxyHops` selects, so a deployment behind an extra
load balancer needs that set correctly for the per-address limit to mean
anything. The limiter fails open when the cache is unreachable: it is load control,
not the only thing guarding the token.

| Parameter                                    | Description                                                                             | Default |
|----------------------------------------------|-----------------------------------------------------------------------------------------|---------|
| `onCallCalendarFeed.disabled`                | Set to `true` to answer every feed URL with `503` + `Retry-After: 3600`.                | `false` |
| `onCallCalendarFeed.rateLimit.windowSeconds` | Length of the fixed rate-limit window.                                                  | `60`    |
| `onCallCalendarFeed.rateLimit.perTokenPerWindow` | Requests one token may make from one client address per window.                     | `60`    |
| `onCallCalendarFeed.rateLimit.perIpPerWindow` | Requests one client address may make across all tokens per window.                    | `3000`  |

## Other

| Parameter                          | Description                              | Default |
|------------------------------------|------------------------------------------|---------|
| `extraTemplates`                   | Extra templates to add to the deployment.| `[]`    |
| `script.workflowScriptTimeoutInMs` | Timeout for workflow scripts.            | `5000`  |
| `script.workflowTimeoutInMs`       | Wall-clock timeout for a workflow execution attempt. | `120000` |
| `dnsConfig`                        | Chart-wide fallback pod `dnsConfig` used by services that support DNS overrides (currently the probes) when they don't set their own. Ships an `ndots:1` + fallback-nameservers default to avoid `getaddrinfo EAI_AGAIN` — see [Probes](#probes). | `ndots:1` + `8.8.8.8`/`1.1.1.1` |
| `dnsPolicy`                        | Chart-wide fallback pod `dnsPolicy`. Left unset so Kubernetes uses `ClusterFirst` (in-cluster API keeps resolving). | `nil`   |

## Related pages

- [Databases](databases.md) — PostgreSQL, Valkey, and ClickHouse (built-in, external, and HA operators).
- [Custom domains](custom-domains.md) — status page domains and Let's Encrypt.
- [Production checklist](production-checklist.md) — hardening for real deployments.
