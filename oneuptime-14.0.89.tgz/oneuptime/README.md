<!-- markdownlint-disable MD033 -->
<h1 align="center"><img alt="oneuptime logo" width=50% src="https://oneuptime.com/img/OneUptimePNG/7.png"/></h1>
<!-- markdownlint-enable MD033 -->

# OneUptime Helm Chart

OneUptime is an open-source observability platform. It checks that your
websites, APIs and servers work, collects the logs, metrics and traces your apps
send, pages whoever is on call when something breaks, and tells your customers
on a status page. This Helm chart runs all of OneUptime on Kubernetes.

- **Website:** [oneuptime.com](https://oneuptime.com)
- **Video tutorial:** [youtu.be/Ho5WyPHExTU](https://youtu.be/Ho5WyPHExTU)

## Quick Start

1. **Create a `values.yaml`** and set your host, the domain name or IP
   address people will use to open OneUptime, without `http://`:

   ```yaml
   host: oneuptime.example.com
   ```

   Keep `httpProtocol: http`, the chart's default, until people reach
   OneUptime over HTTPS, then set `httpProtocol: https`. The chart uses your
   cluster's default storage class; set `global.storageClass` only when it
   has none (`kubectl get storageclass` lists them).

2. **Install the chart:**

   ```console
   helm repo add oneuptime https://helm-chart.oneuptime.com/
   helm install my-oneuptime oneuptime/oneuptime -f values.yaml
   ```

3. **Open OneUptime** at the address `helm install` prints, once the pods are
   running, and sign up. The first account becomes the admin of this
   OneUptime.

That's the whole happy path. For details, prerequisites, and upgrades, see the
[Installation guide](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/installation.md).

## Documentation

The docs are split into focused guides:

| Guide | What's inside |
|-------|---------------|
| [Installation & Upgrades](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/installation.md) | Prerequisites, install, upgrade, and uninstall. |
| [Configuration reference](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/configuration.md) | Every `values.yaml` setting, grouped by topic. |
| [Databases](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/databases.md) | PostgreSQL, Valkey, and ClickHouse — built-in, external, and HA operators. |
| [Local AI with vLLM](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/ai-vllm.md) | Run local LLMs in-cluster for OneUptime's AI features. |
| [Custom domains](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/custom-domains.md) | Custom status page domains and Let's Encrypt. |
| [Production checklist](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/production-checklist.md) | Harden your install for production. |
| [Troubleshooting](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/troubleshooting.md) | Diagnose performance and health issues. |
| [Releases & upgrade notes](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/upgrade-notes.md) | Release cadence, breaking changes, and chart dependencies. |

### Database migration runbooks

- [PostgreSQL: Standalone → CloudNativePG operator](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Docs/MigratePostgresStandaloneToOperator.md)
- [ClickHouse: Standalone → Altinity operator](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Docs/MigrateClickhouseStandaloneToOperator.md)

## Community vs. Enterprise

| Edition            | Best for                                             | Included                                                                                             | Requirements  |
|--------------------|-------------------------------------------------------|------------------------------------------------------------------------------------------------------|---------------|
| Community Edition  | Getting started, small self-hosted deployments        | The OneUptime platform, including SAML and OIDC single sign-on, Apache-2.0 licensed.                 | None          |
| Enterprise Edition | Regulated industries, teams with strict compliance    | Everything in the Community Edition plus the enterprise features (SCIM, audit logs, team compliance, instance health dashboards), licensed under the OneUptime Enterprise License; custom features and roadmap input; a dedicated engineer with 1-hour priority phone support; custom data residency and retention; private cloud or SaaS with annual invoicing. | Valid license |

Select the edition with `image.type` (`community-edition` or
`enterprise-edition`) — see the [Configuration reference](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/configuration.md#images).
`enterprise-edition` runs the Enterprise Edition images: the same tags with an
`enterprise-` prefix. Production use of the Enterprise Edition requires a
subscription under the OneUptime Enterprise License. An install with no
license, or one holding a license whose expiry was never recorded, runs as a
14-day trial, which is for evaluation. After the trial (or 30 days after a
license expires), until a license is activated, SCIM and audit logging stop:
your identity provider's SCIM requests are refused and audit logging stops
recording. Enterprise configuration becomes read-only and the enterprise admin
dashboards are locked too. Single sign-on (SAML, OIDC and "Require SSO for
login") is part of both editions and does not depend on the license.
Everything resumes, without a restart, as soon as a license is activated, and
core monitoring is never affected.

## Uninstalling

```console
helm uninstall my-oneuptime
```

See [Installation & Upgrades](https://github.com/OneUptime/oneuptime/blob/master/HelmChart/Public/oneuptime/docs/installation.md#uninstalling) for caveats
(especially if you enabled a bundled database operator).

## Contributing

We <3 contributions big and small.
[github.com/OneUptime/helm-chart](https://github.com/OneUptime/helm-chart) is the
read-only release repository. Please direct contributions to
[github.com/OneUptime/oneuptime](https://github.com/OneUptime/oneuptime).
